### F-{{nn}} — {{Title: the fact, then the consequence}}

| | |
|---|---|
| **Severity** | {{Critical / High / Medium / Low / Informational}} — {{one-line justification; what it depends on in the threat model}} |
| **Confidence** | {{Confirmed / Probable / Needs review}} — {{what the evidence is; which library version it was tested on}} |
| **Class** | {{plain name of the flaw class}} · {{CWE-nnn}} |
| **Location(s)** | `{{path/file:line}}`, `{{path/other:line}}` ({{commit}}) |

**What is wrong.**
{{Two to five sentences: what the code or design does and why that is a problem. Name the precondition that makes it exploitable and say that it is present.}}

**Trace.**
1. `{{file:line}}` — {{where the value (key, nonce, error, input) originates}}
2. `{{file:line}}` — {{how it reaches the cryptographic call}}
3. ⇒ {{the consequence, in one line}}

**Evidence.**
```
{{The command and the few lines of output that show it, with no secrets. Name the attached test; do not paste whole logs.}}
```

**Impact.**
{{Confidentiality / integrity / authenticity / key recovery; scale; what an attacker needs.}}

**Fix.**
```{{language}}
{{before: the affected line(s)}}
{{after: the corrected line(s), in the project's own library}}
```
{{Any migration the fix implies (re-encrypt, rotate), and the regression test to keep.}}

**References.** {{standard and section, paper, CWE}}

**Status.** {{Open / Fixed in <commit> / Risk accepted by <owner> on <date>}}
