# Cryptographic implementation audit — {{project}}

**Date:** {{date}} · **Scope:** {{scope}} · **Commit/version:** {{commit}} · **Auditor:** {{auditor}}

## 1. Executive summary

{{Five to ten lines: what was audited, overall posture, the most consequential findings, the verdict.}}

| # | Finding | Severity | Confidence |
|---|---|---|---|
| F-01 | {{title}} | Critical | Confirmed |
| F-02 | … | … | … |

**Fix first:** 1) {{…}} 2) {{…}} 3) {{…}}

## 2. Scope, threat model and limitations

- **Target:** {{repos / services / files / documents}}
- **Languages & libraries:** {{from inventory}}
- **Dependency versions:** {{pinned in the project}} · **tested on:** {{versions the tests actually ran on; say where they differ or where nothing is pinned}}
- **Threat model assumed:** {{remote attacker; who can submit ciphertexts/tokens; who sees errors; physical access?; compliance regime}}. {{If code has no callers in the audited tree: "severity assumes each function is used for what its name says".}}
- **Not covered:** {{runtime infrastructure, third-party internals, live scanning, …}}
- **Standards:** status as of {{standards_date}} {{re-verified on … / not re-verified}}

## 3. Specification vs. implementation

| Claim (source) | Observed in code | Status |
|---|---|---|
| "{{claim}}" ({{doc:line}}) | {{what the code does}} ({{file:line}}) | Matches / **Matches, but the claim itself is unsound (→ F-xx)** / **Diverges (→ F-xx)** / Not verifiable |

**Left unspecified by the documentation:** {{what a reader cannot determine and an implementer has to guess — nonce source, what the MAC covers, who can create a valid message, error behaviour, key lifecycle, versioning — each with proposed wording}}

## 4. Critical and High findings

{{One block per finding from templates/finding.md, ordered by severity then confidence. One finding per root cause; list every affected location inside it. Finding IDs are the ones assigned at triage; they need not be consecutive here.}}

## 5. Medium, Low and Informational findings

| # | Severity · Confidence | Location | What is wrong | Fix |
|---|---|---|---|---|
| F-0x | Medium · Confirmed | `{{file:line}}` | {{one sentence}} | {{one sentence or one line of code}} |

## 6. Candidates investigated and closed

| Location | Pattern | Why closed |
|---|---|---|
| `{{file:line}}` | {{MD5}} | {{cache key, not security-relevant}} |

## 7. Evidence and attachments

| File | Supports | How to re-run | Result |
|---|---|---|---|
| `tests/crypto/test_nonce_unique.py` | F-01 | `pytest tests/crypto -k nonce` | fails: nonce repeats after a restart |
| `inventory.md` | whole report | — | attached, not pasted |

{{Re-run instructions must work for the client with the attached files alone. The leak-scan result goes in your delivery message, not in the report.}}

## 8. Recommendations beyond the findings

{{Only what is not already a finding: key versioning and rotation, crypto-agility, PQC readiness when in scope, which regression tests to keep.}}
