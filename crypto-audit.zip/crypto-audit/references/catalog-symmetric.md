# Catalog — Symmetric cryptography (S-01 … S-27)

Each entry: what the flaw is and when it is exploitable → how it looks in code → what to trace → how to confirm (property test, never exploit) → typical false positives → severity → fix → references. Basis tags: [E] standard, [L] demonstrated in literature, [P] best practice/consensus.

Contents: S-01 obsolete algorithms · S-02 short/string keys · S-03 ECB · S-04 CBC IV · S-05 unauthenticated encryption · S-06 keystream reuse · S-07 GCM nonce reuse · S-08 GCM parameters · S-09 counters/multi-instance · S-10 ChaCha20-Poly1305 · S-11 CCM · S-12 XTS · S-13 SIV expectations · S-14 non-crypto RNG · S-15 seeds/fork/snapshots · S-16 MtE/E&M · S-17 key reuse, incomplete MAC · S-18 non-constant compare · S-19 plaintext before tag check · S-20 AAD misuse · S-21 key commitment · S-22 padding oracle · S-23 length extension · S-24 MD5/SHA-1/CRC · S-25 password hashing · S-26 HKDF misuse · S-27 one key in several modes/primitives (cross-mode oracle)

---

## S-01 Obsolete / weak algorithms (DES, 3DES, RC4, Blowfish, 64-bit blocks — Sweet32)

- **Flaw.** DES (56-bit key) falls to brute force. Any 64-bit-block cipher (3DES, Blowfish, CAST5, IDEA) leaks plaintext XORs after ~2^32 blocks under one key (birthday bound) — Sweet32 needs a lot of traffic under the same key but is practical over long-lived TLS/VPN sessions. RC4 has keystream biases exploitable on repeated plaintexts (cookies).
- **Code.** Java `Cipher.getInstance("DESede/CBC/PKCS5Padding")`, `"DES"`, `"Blowfish"`, `"ARCFOUR"`; OpenSSL `EVP_des_ede3_cbc()`, `EVP_rc4()`, `EVP_bf_cbc()`; .NET `TripleDES.Create()`, `DES.Create()`, `RC2`; PyCryptodome `DES3.new`, `ARC4.new`, `Blowfish.new`; Node `createCipheriv('des-ede3-cbc'…)`; Go `crypto/des`, `crypto/rc4`, `golang.org/x/crypto/blowfish`. Config: cipher suites containing `3DES`, `RC4`, `DES-CBC3`; sshd `3des-cbc`, `arcfour`.
- **Trace.** Algorithm strings are often built from variables/constants/config — follow them to `getInstance`/`Create`. MASC showed CryptoGuard missed lowercase `"des"`; match case-insensitively.
- **Confirm.** Print the effective algorithm at runtime (`cipher.getAlgorithm()`); for TLS, `testssl.sh`/`sslyze` against a running instance.
- **FP.** Decrypting legacy data (read-only path) with a documented migration; bcrypt internally uses Blowfish (fine); 3DES in HSM/PIN-block contexts governed by other standards (note it, don't flag Critical).
- **Severity.** High (DES, RC4); Medium (3DES, Blowfish) — High if long-lived keys with large traffic.
- **Fix.** AES-GCM / ChaCha20-Poly1305 (AEAD). Rotate keys; plan data re-encryption.
- **Refs.** [E] NIST SP 800-131A Rev. 2 (TDEA encryption disallowed after 2023); RFC 7465 (RC4 prohibited in TLS); BSI TR-02102-1. [L] Bhargavan & Leurent, "On the Practical (In-)Security of 64-bit Block Ciphers" (CCS 2016). CVE-2016-2183 (Sweet32). CWE-327, CWE-326.

## S-02 Short keys or keys derived from strings

- **Flaw.** `SecretKeySpec("MySecretKey12345".getBytes(), "AES")`, `key = sha256("app-secret")`, keys truncated from passwords: entropy is far below the nominal key length; offline brute force or dictionary.
- **Code.** String literals or config strings flowing into `SecretKeySpec`, `AES.new(key…)`, `createCipheriv(alg, key…)`, `aes.NewCipher([]byte(cfg.Key))`; `.getBytes()` on a literal; `key[:16]`; MD5/SHA of a passphrase used directly as key.
- **Trace.** Key variable → origin. Acceptable origins: CSPRNG, KMS/HSM, HKDF from a high-entropy secret, password KDF (S-25 parameters) if a password is the only option.
- **Confirm.** Compute the entropy of the source (a 16-char ASCII string ≈ 95 bits at best, usually much less); check lengths programmatically.
- **FP.** Test keys in `tests/`; a hex/base64 string that decodes to 32 random bytes loaded from a secret manager (still check C-07 for hard-coding).
- **Severity.** High; Critical if the string is a dictionary word or short.
- **Fix.** Random keys from a CSPRNG stored in a KMS; derive sub-keys with HKDF; for passwords, Argon2id/scrypt/PBKDF2 with proper parameters.
- **Refs.** [E] SP 800-57 Pt.1 Rev.5 (key strength), SP 800-132. CWE-326, CWE-321.

## S-03 ECB mode

- **Flaw.** Deterministic per block: equal plaintext blocks → equal ciphertext blocks. Leaks structure (the "penguin"), enables block cut-and-paste, and is a precondition for chosen-plaintext block-by-block recovery when the attacker controls a prefix.
- **Code.** **Java/Kotlin `Cipher.getInstance("AES")` is `AES/ECB/PKCS5Padding` in SunJCE** — this is the single most common way ECB enters a codebase. Also `"AES/ECB/…"`, .NET `CipherMode.ECB` (and `Aes.Create()` defaults to CBC, but `TripleDES`/`DES` defaults vary), PyCryptodome `AES.MODE_ECB`, PyCA `modes.ECB()`, OpenSSL `EVP_aes_128_ecb()`, Node `'aes-128-ecb'`, Go — no built-in ECB, hand-rolled loops over `block.Encrypt` are the tell. PHP `openssl_encrypt($d, 'aes-128-ecb'…)`, `mcrypt` with `MCRYPT_MODE_ECB`.
- **Trace.** What is encrypted? Single random block (e.g., key wrapping with a random key)? Structured/attacker-influenced data? The latter is the real problem.
- **Confirm.** Encrypt two identical 16-byte blocks; outputs equal ⇒ ECB.
- **FP.** `RSA/ECB/OAEPWith…` — nominal, not block mode. ECB as a building block inside a correct construction (AES-CMAC, AES-KW implementations). Encrypting exactly one block of uniformly random data (e.g., a DEK) — still note it, AES-KW/KWP is the right tool.
- **Severity.** Medium; High when structured or attacker-influenced data (tokens, records, session data).
- **Fix.** AEAD (GCM/ChaCha20-Poly1305). For key wrapping: AES-KW (RFC 3394) / KWP (SP 800-38F).
- **Refs.** [E] SP 800-38A; SP 800-131A Rev.3 draft (ECB withdrawal proposed). [L] MASC (Ami et al., IEEE S&P 2022) — OWASP Benchmark treated ECB as secure until 2020. CWE-327.

## S-04 CBC IV predictable, static, zero, or equal to the key

- **Flaw.** SP 800-38A requires an unpredictable IV. Fixed IV ⇒ deterministic encryption (first-block equality leaks); predictable IV ⇒ chosen-plaintext attacks on the first block (BEAST pattern); IV == key with a decryption oracle ⇒ key recovery (first two blocks reveal the key).
- **Code.** `new IvParameterSpec(new byte[16])`; `iv = key` or `iv = key[:16]`; `IvParameterSpec("1234567890123456".getBytes())`; .NET `aes.IV = new byte[16]`; PyCryptodome `AES.new(key, AES.MODE_CBC, iv=b'\0'*16)`; Node's deprecated `crypto.createCipher` (derives key and IV from password with MD5, IV fixed per password); counters or timestamps used as CBC IV; IV derived from a hash of the plaintext.
- **Trace.** IV variable → origin, and whether it is stored/transmitted (a random IV that is never transmitted means someone will "fix" it with a constant).
- **Confirm.** Encrypt the same plaintext twice; equal ciphertexts ⇒ fixed IV. Encrypt, then check `iv == key`.
- **FP.** IV produced by encrypting a nonce under the same key (SP 800-38A App. C — acceptable); CBC-MAC with zero IV (correct for the MAC, not for encryption).
- **Severity.** Medium; High if IV == key or predictable with attacker-chosen plaintext.
- **Fix.** Fresh CSPRNG IV per message, prepended to ciphertext — and really, move to AEAD.
- **Refs.** [E] SP 800-38A §6.2, App. C. CWE-329, CWE-1204.

## S-05 Unauthenticated encryption (malleability, bit-flipping)

- **Flaw.** CTR/OFB/CFB: flipping ciphertext bit i flips plaintext bit i. CBC: modifying C_{i-1} controls P_i (and garbles P_{i-1}). Exploitable whenever the attacker can alter ciphertext that will later be decrypted and acted on (cookies, tokens, stored records, URL parameters). Also the precondition for S-22.
- **Code.** `AES/CBC/PKCS5Padding`, `AES/CTR/NoPadding`, `modes.CBC`, `modes.CTR`, `cipher.NewCTR`, `aes-256-cbc` **without** a MAC computed over the ciphertext and verified before decryption. WebCrypto `AES-CBC`/`AES-CTR` are the classic web case.
- **Trace.** Decrypt call sites → is a MAC/signature verified over (IV‖ciphertext‖header) before decrypt? Who can supply the ciphertext?
- **Confirm.** Flip one byte of a ciphertext → decrypt must fail/raise. If it returns garbled-but-accepted plaintext, confirmed.
- **FP.** Ciphertext only ever travels inside an authenticated channel and is never stored (rare; still fragile). Disk encryption (XTS by design). Data whose integrity is separately signed (verify the signature covers the ciphertext and is checked first).
- **Severity.** High (Critical when a flipped field grants privilege: `role=user`→`admin`).
- **Fix.** AEAD. If a MAC must be added: Encrypt-then-MAC with an independent key, MAC over IV‖CT‖AAD, constant-time compare, verify before decrypt. Libraries: `Fernet`, libsodium `secretbox`, Tink.
- **Refs.** [E] RFC 5116 (AEAD); [P] OWASP Cryptographic Storage Cheat Sheet. CWE-353, CWE-649.

## S-06 Keystream reuse (CTR / OFB / CFB / stream ciphers)

- **Flaw.** Same (key, nonce/IV) twice ⇒ C1⊕C2 = P1⊕P2; crib-dragging recovers both plaintexts. Also applies to RC4/ChaCha20 raw, and to CTR implementations that start the counter at 0 for every message.
- **Code.** `modes.CTR(b'\0'*16)`, `cipher.NewCTR(block, iv)` with constant iv, `AES.new(key, AES.MODE_CTR, nonce=b'')`, `chacha20.NewUnauthenticatedCipher(key, nonce)` with fixed nonce; counter-mode "nonce" built from a message ID that repeats across tenants/keys.
- **Trace.** Nonce → uniqueness scope. Across processes? Replicas? Restarts? Is the counter space exhausted (CTR 32-bit block counter with large messages)?
- **Confirm.** Encrypt two messages; capture nonces; equality ⇒ confirmed. Statistical: `scripts/nonce_audit.py` on collected IVs.
- **FP.** One-time key (ephemeral per message, derived via HKDF with a unique salt/info).
- **Severity.** High (Critical if many messages).
- **Fix.** Unique nonce per message under a key (counter with persistence, or random 96-bit with rotation), or AEAD with nonce-misuse resistance.
- **Refs.** [E] SP 800-38A App. B (counter construction). CWE-323.

## S-07 AES-GCM nonce reuse ("forbidden attack")

- **Flaw.** With one repeated 96-bit nonce under a key, an attacker gets P1⊕P2 *and* can solve for the GHASH subkey H from the two tags (polynomial over GF(2^128)); with H they forge tags for any ciphertext under that key. Two messages suffice. This is the most consequential symmetric misuse in practice (Böck et al. found it on live HTTPS endpoints of financial institutions).
- **Code.** `new GCMParameterSpec(128, fixedIv)` reused across `init` calls; nonce from `AtomicLong` counter in memory (resets per process); nonce = timestamp (collides under concurrency); nonce = user ID/record ID when multiple tenants/instances share the key; `AESGCM(key).encrypt(nonce, …)` with `nonce` hoisted out of the loop; Go `gcm.Seal(nil, nonce, …)` with `nonce := make([]byte, 12)` never filled; Node `createCipheriv('aes-256-gcm', key, iv)` with iv from config; WebCrypto `iv` reused across `encrypt` calls; .NET `AesGcm.Encrypt(nonce…)` with a static nonce. Java (SunJCE) only detects reuse within one `Cipher` object: re-`init` with the same key and IV throws `InvalidAlgorithmParameterException` ("Cannot reuse iv for GCM encryption") and a second `doFinal` without re-`init` throws `IllegalStateException`. A new `Cipher` object with the same key and IV encrypts without complaint, and that is how the bug ships (measured on JDK 21).
- **Trace.** Nonce origin → scope → persistence. Key scope: one key per tenant? per instance? global? Write the trace as a table: *nonce source / unique per key? / survives restart? / unique across replicas?*
- **Confirm.** Property test: encrypt N messages through the real code path (including process restart or two instances if feasible); collect nonces; assert all unique. Check SP 800-38D limit: random nonces ⇒ at most 2^32 encryptions per key (and practically far fewer for comfortable margin).
- **FP.** Key used exactly once (single-shot HPKE, per-message key from HKDF with a unique salt); AES-GCM-SIV (still leaks message equality on reuse).
- **Severity.** Critical.
- **Fix.** Deterministic nonce (SP 800-38D §8.2.1: fixed field ‖ invocation counter, persisted and per instance), or random 96-bit nonce with key rotation well before 2^32 messages, or AES-GCM-SIV / XChaCha20-Poly1305 for the random-nonce case, or derive a fresh key per message (HKDF with random salt, "DNDK"-style).
- **Refs.** [E] SP 800-38D §8. [L] Joux, "Authentication Failures in NIST version of GCM" (2006); Böck, Zauner, Devlin, Somorovsky, Jovanovic, "Nonce-Disrespecting Adversaries" (USENIX WOOT 2016). CVE-2016-0270 (IBM Domino; NVD lists related IDs CVE-2016-10213, -10212, CVE-2017-5933). CWE-323.

## S-08 GCM: non-96-bit nonce, truncated tags, per-key usage limits

- **Flaw.** A nonce ≠ 96 bits is hashed through GHASH, which weakens the security bound and creates nonce-collision risks across lengths. Tags of 32/64 bits allow forgery with modest effort (SP 800-38D App. C; NIST announced removal of sub-96-bit tags in the 38D revision). Per-key limits: plaintext ≤ 2^39−256 bits per invocation; total invocations bounded (RFC 8446 §5.5 gives TLS limits; ~2^24.5 full-size records for AES-GCM at 2^-57 margin).
- **Code.** Go `cipher.NewGCMWithNonceSize(b, 16)` (any nonce size is accepted), `cipher.NewGCMWithTagSize(b, 12…15)` — Go accepts tag sizes 12–16 only, so `NewGCMWithTagSize(b, 8)` returns an error, and when that error is discarded the AEAD is nil and `Seal` panics (T-02; measured on Go 1.24). Java `GCMParameterSpec(96…120, iv)` — SunJCE accepts only {96, 104, 112, 120, 128} and throws `InvalidAlgorithmParameterException` for 32/64 (measured on JDK 21); Bouncy Castle accepts shorter tags, so check which provider is in use. WebCrypto `tagLength: 32`/`64`/`96`; Node: `createDecipheriv('aes-…-gcm', key, iv)` without the `authTagLength` option accepts whatever tag length `setAuthTag` is given — 4, 8, 12 or 16 bytes (measured on Node 22); with `{ authTagLength: 16 }` shorter tags are rejected. So a Node decrypt path that takes the tag from the message and does not pin its length lets the sender truncate the tag to 32 bits; modern Node validates for GCM, but applications must still pass `authTagLength` for CCM/OCB and should reject short tags explicitly); OpenSSL `EVP_CTRL_GCM_SET_TAG` with len < 12.
- **Trace.** Who controls tag length/IV length at decrypt time? Is the tag length negotiated from the message (attacker-chosen)?
- **Confirm.** Decrypt with a 4-byte tag must fail. Encrypt with a 16-byte nonce must be rejected or documented.
- **FP.** 128-bit nonces in a protocol that mandates them with a documented analysis.
- **Severity.** Medium; High if the attacker can truncate the tag or choose IV length.
- **Fix.** 96-bit nonce, 128-bit tag, key rotation by message count/bytes.
- **Refs.** [E] SP 800-38D App. C; NIST "GCM and GMAC revision" announcement (2024); NIST IR 8459 (block cipher modes review); RFC 8446 §5.5. CWE-327.

## S-09 Non-persistent counters, multi-instance, concurrency, random-nonce collision

- **Flaw.** Counter-based nonces that reset (process restart, VM snapshot restore, failover, container scale-out) or are shared across instances without coordination repeat. Concurrent increment without atomicity repeats. Random 96-bit nonces collide with probability ≈ n²/2^97 (≈ 2^-33 at 2^32 messages; NIST caps at 2^32).
- **Code.** `static long counter = 0;` as nonce; `nonce = int(time.time())`; Redis `INCR` without binding to key ID; counters stored only in memory; `nonce = os.urandom(12)` with a long-lived global key and high message volume.
- **Trace.** Where is the counter stored? Per key? What happens on restart/clone/scale? How many messages per key over its lifetime?
- **Confirm.** Restart test (encrypt, restart, encrypt, compare nonces). Concurrency test (two threads). Volume estimate from logs/metrics vs. 2^32.
- **FP.** Key is per instance (derived with instance ID) and rotated; nonce counter persisted transactionally with the key.
- **Severity.** High–Critical (it *is* S-07 once it happens).
- **Fix.** `instance_id ‖ counter` layout (SP 800-38D §8.2.1), per-instance keys via HKDF, or misuse-resistant AEAD; enforce rotation thresholds.
- **Refs.** [E] SP 800-38D §8.2–8.3. [P] Ericsson comments to NIST on SP 800-38D (2025). CWE-323.

## S-10 ChaCha20-Poly1305 / XChaCha20 misuse

- **Flaw.** Nonce reuse ⇒ Poly1305 key reuse ⇒ forgery + plaintext XOR. 96-bit nonce (IETF variant) must not be random under a long-lived key at scale (same birthday maths as GCM). Raw ChaCha20 without Poly1305 treated as "authenticated". Counter is 32-bit: 256 GiB per (key, nonce). XChaCha20 (192-bit nonce) is safe with random nonces but its IETF draft never became an RFC — fine to use (libsodium), document it.
- **Code.** `crypto_aead_chacha20poly1305_ietf_encrypt(... nonce ...)` with nonce from config; `chacha20poly1305.New(key)` with `nonce := make([]byte, 12)`; PyCA `ChaCha20Poly1305(key).encrypt(nonce…)` with reused nonce; `ChaCha20` (no Poly1305) in Node/PyCA used for integrity-sensitive data.
- **Trace / Confirm / FP.** As S-07.
- **Severity.** Critical on reuse.
- **Fix.** XChaCha20-Poly1305 with random 24-byte nonces, or counter nonces with persistence.
- **Refs.** [E] RFC 8439. CWE-323.

## S-11 CCM misparameterized

- **Flaw.** Tag length 4/8 bytes (forgery), wrong L/nonce relationship (nonce length 15−L), nonce reuse (same as CTR + CBC-MAC leak).
- **Code.** PyCA `AESCCM(key, tag_length=4)`; Node `createCipheriv('aes-128-ccm', key, iv, {authTagLength: 4})`; OpenSSL `EVP_CTRL_CCM_SET_TAG` short.
- **Confirm.** Wycheproof `aes_ccm_test.json`.
- **Severity.** Medium.
- **Fix.** 16-byte tag, 13-byte nonce for short messages (L=2) or per SP 800-38C.
- **Refs.** [E] SP 800-38C; RFC 3610.

## S-12 XTS outside storage encryption

- **Flaw.** XTS is deterministic per (key, sector) and provides no integrity; used for messages/files-in-transit it leaks equality and allows block-granular malleability (randomization of 16-byte blocks).
- **Code.** `AES/XTS`, `modes.XTS(tweak)`, `xts.NewCipher` used in an application protocol.
- **Severity.** Medium.
- **Fix.** AEAD. XTS only for sector-based storage.
- **Refs.** [E] SP 800-38E (storage only); IEEE 1619.

## S-13 Wrong expectations of SIV / AES-GCM-SIV

- **Flaw.** Nonce-misuse-resistant modes degrade gracefully (only leak message equality on reuse) but are still not key-committing (see S-21), and GCM-SIV has per-key limits too. Teams sometimes read "misuse-resistant" as "no nonce needed".
- **Code.** `AESSIV`, `AESGCMSIV` with constant nonce *and* an assumption that equality is not sensitive; use as a committing AEAD.
- **Severity.** Low–Medium.
- **Refs.** [E] RFC 8452 (AES-GCM-SIV), RFC 5297 (SIV).

## S-14 Non-cryptographic RNG for keys, IVs, salts, tokens, session IDs

- **Flaw.** Mersenne Twister, LCGs, xorshift: internal state is recoverable from a few outputs (624 outputs for MT19937), so every past and future value is predictable. Reset tokens, session IDs, CSRF tokens, IVs, salts and keys generated this way are guessable.
- **Code (vulnerable → correct).**
  - Python: `random.random/randint/choice/getrandbits/bytes` → `secrets.token_bytes/token_urlsafe`, `os.urandom`
  - Java: `java.util.Random`, `Math.random()`, `ThreadLocalRandom` → `SecureRandom` (and not `SecureRandom(seed)` with a fixed seed)
  - JS/Node: `Math.random()` → `crypto.randomBytes`, `crypto.randomUUID`, `crypto.getRandomValues` (browser)
  - Go: `math/rand`, `math/rand/v2` → `crypto/rand`
  - C/C++: `rand()`, `random()`, `std::mt19937`, `std::default_random_engine` → `getrandom(2)`, `arc4random_buf`, `RAND_bytes` (check return == 1), `BCryptGenRandom`
  - C#/.NET: `System.Random`, `Guid.NewGuid()` for secrets → `RandomNumberGenerator.GetBytes/Fill`
  - Rust: `rand::rngs::SmallRng`, `StdRng::seed_from_u64(const)` → `OsRng`, `rand::thread_rng()` (CSPRNG), `getrandom`
  - PHP: `rand`, `mt_rand`, `uniqid`, `lcg_value` → `random_bytes`, `random_int`
  - Ruby: `rand`, `Random.new` → `SecureRandom`
- **Trace.** Taint from the RNG call to: key constructors, IV/nonce params, salts, `token`, `session`, `reset`, `otp`, `nonce` identifiers.
- **Confirm.** Static trace is usually enough; dynamically, generate 1000 tokens and check that they are reproducible from a known seed if the seed is derivable.
- **FP.** Simulations, sampling, shuffling non-security data, jitter/backoff. `Guid.NewGuid()`/`uuid4` for *identifiers* (not secrets). Rust `thread_rng` is a CSPRNG.
- **Severity.** High for tokens, session identifiers, salts and IVs; Critical when it generates encryption or signing keys.
- **Refs.** [E] SP 800-90A Rev.1, 800-90B, 800-90C. [L] Egele et al., "An Empirical Study of Cryptographic Misuse in Android Applications" (CCS 2013). CWE-338, CWE-330.

## S-15 Weak seeding, fork-safety, VM snapshots, low boot entropy

- **Flaw.** `srand(time(NULL))` / PID seeds give ~2^20 possibilities; a DRBG not reseeded after `fork()` produces identical streams in parent and child; VM snapshot/clone restores RNG state so two clones emit the same "random" keys/nonces; embedded devices generate host keys at first boot with no entropy (shared RSA factors across devices).
- **Code.** `srand(time(0))`, `random.seed(time.time())`, `new SecureRandom(fixedSeed)` (SHA1PRNG with seed is fully deterministic!), `SecureRandom.setSeed` before first `nextBytes` on Sun providers, userland DRBG in a prefork server without `pthread_atfork` reseed, OpenSSL < 1.1.1 `RAND` in fork without reseed, Go/Rust custom RNG wrappers caching state.
- **Trace.** Who seeds? When relative to fork/clone? Does the app generate long-lived keys at first boot on devices?
- **Confirm.** Fork test: parent and child draw; outputs differ. Batch-GCD across a fleet's RSA keys (`scripts/key_analyzer.py --gcd`).
- **FP.** Seeding a *non-crypto* PRNG for reproducible tests.
- **Severity.** High.
- **Fix.** Use the OS CSPRNG (`getrandom`, `/dev/urandom`, `BCryptGenRandom`) directly; regenerate device keys on first boot *after* entropy is available; virtio-rng for VMs.
- **Refs.** [L] Ristenpart & Yilek, "When Good Randomness Goes Bad" (NDSS 2010); Heninger, Durumeric, Wustrow, Halderman, "Mining Your Ps and Qs" (USENIX Security 2012). CVE-2008-0166 (Debian OpenSSL). CWE-337, CWE-335.

## S-16 MAC-then-Encrypt and Encrypt-and-MAC

- **Flaw.** MtE (`Enc(k, m‖MAC(m))`) forces padding removal *before* MAC verification → padding/timing oracles (Lucky13, POODLE). E&M (`Enc(k1,m) ‖ MAC(k2,m)`) leaks plaintext equality via the MAC and is not generically secure.
- **Code.** HMAC computed over plaintext then encrypted; `HMAC(key, plaintext)` sent alongside ciphertext; `hmac.compare_digest(mac, hmac(plaintext))` after decrypt.
- **Trace.** Order of operations on the decrypt path: decrypt → unpad → verify (bad) vs verify → decrypt (good).
- **Confirm.** Submit ciphertext with bad padding vs bad MAC; any observable difference (exception type, message, timing) ⇒ confirmed oracle.
- **Severity.** High with CBC; Medium with CTR (E&M leak).
- **Fix.** Encrypt-then-MAC over IV‖CT‖AAD, independent keys, verify first. Or AEAD.
- **Refs.** [L] Bellare & Namprempre (ASIACRYPT 2000); Krawczyk, "The Order of Encryption and Authentication" (CRYPTO 2001). CWE-327.

## S-17 Same key for encryption and MAC; MAC that omits IV/header/AAD; ambiguous concatenation

(For one key used in two *encryption* modes or protocols, see S-27.)

- **Flaw.** Key reuse across primitives breaks independence assumptions (concrete breaks exist for CBC+CBC-MAC with the same key). A MAC that does not cover the IV lets the attacker change the first plaintext block (CBC) or shift the keystream; omitting headers/algorithm identifiers enables downgrade; `MAC(a‖b)` without length encoding allows boundary-moving collisions.
- **Code.** One `key` variable passed to both `AES.new` and `hmac.new`; `hmac(key, ciphertext)` where `iv` is prepended *after* MAC; `mac = HMAC(k, user + role)` (concatenation ambiguity).
- **Trace.** Key variable fan-out; what exactly is the MAC input?
- **Confirm.** Modify IV/header; verification should fail. For concatenation: construct two field splits with the same concatenation.
- **Severity.** Same key for encryption and MAC: Low with HMAC over CBC/CTR ciphertext (no known break, a margin issue); High when both uses are block-cipher based on that key (CBC with CBC-MAC/CMAC — see S-27). MAC that omits the IV, header or algorithm identifier: Medium, High when the unauthenticated part steers a security decision. Ambiguous concatenation: Medium–High depending on what can be shifted.
- **Fix.** HKDF sub-keys with distinct `info`; MAC over length-prefixed fields; AEAD with AAD for headers.
- **Refs.** [E] SP 800-57 Pt.1 Rev.5 §5.2 (key separation); SP 800-108 Rev.1. CWE-323.

## S-18 Non-constant-time tag/MAC/password comparison

- **Flaw.** `==`, `memcmp`, `Arrays.equals`, `String.equals`, `strcmp` exit on the first mismatching byte; remote timing lets an attacker recover a valid tag byte-by-byte (Lawson/Nelson style). Also applies to API key / password hash comparisons.
- **Code (vulnerable → correct).** Python `mac == expected` → `hmac.compare_digest`; Java `Arrays.equals`/`equals` → `MessageDigest.isEqual`; Node `===`/`Buffer.equals` → `crypto.timingSafeEqual` (lengths must match first); Go `bytes.Equal` → `hmac.Equal` / `subtle.ConstantTimeCompare`; C `memcmp` → `CRYPTO_memcmp`, `sodium_memcmp`; .NET `SequenceEqual` → `CryptographicOperations.FixedTimeEquals`; Rust `==` on `[u8]` → `subtle::ConstantTimeEq`; PHP `==`/`===` → `hash_equals`; Ruby `==` → `ActiveSupport::SecurityUtils.secure_compare` / `OpenSSL.fixed_length_secure_compare`.
- **Trace.** Both operands: is one secret-derived (tag, HMAC, password hash, API key) and the other attacker-supplied?
- **Confirm.** `scripts/timing_check.py` with inputs differing at byte 0 vs byte N; or by reading.
- **FP.** Comparing two public values; comparing lengths before a constant-time compare (fine).
- **Severity.** Medium; High if remotely reachable with many attempts and no rate limit.
- **Refs.** [L] Kocher (CRYPTO 1996); Reparaz, Balasch, Verbauwhede, "Dude, is my code constant time?" (DATE 2017). CWE-208.

## S-19 Plaintext released before tag verification

- **Flaw.** Streaming APIs yield plaintext from `update()` before `final()` verifies the tag; code acts on it (writes to disk, parses, starts a transaction) and then "handles" the exception. Attacker-modified ciphertext thus has side effects even though it is rejected.
- **Code.** Java `cipher.update(...)` output consumed before `doFinal()` (Java buffers GCM plaintext internally until doFinal — but only for GCM; check provider); OpenSSL `EVP_DecryptUpdate` output used before checking `EVP_DecryptFinal_ex` return; Node `decipher.update()` chunks piped to a file before `final()`; Go — `gcm.Open` is all-at-once (fine), but hand-rolled CTR+HMAC streaming is not.
- **Trace.** Does any side effect happen between update and final?
- **Confirm.** Tampered ciphertext; assert no partial file/DB write occurred.
- **Severity.** Medium–High.
- **Fix.** Buffer until verified, or chunked AEAD (libsodium `secretstream`, Tink streaming AEAD, age/STREAM construction).
- **Refs.** [E] SP 800-38D (tag must be verified before plaintext release); RFC 5116. Wycheproof C2SP chunked-encryption vectors. CWE-354.

## S-20 AAD misuse

- **Flaw.** Context that binds a ciphertext to its use (record ID, user ID, field name, version, algorithm) is not in the AAD, so an attacker can move a valid ciphertext from one record/user/field to another ("ciphertext swapping"). Inverse error: secrets put in AAD believing AAD is encrypted (it is not).
- **Code.** `AESGCM.encrypt(nonce, pt, None)` for multi-tenant records; `aad = user_password`.
- **Confirm.** Swap two users' ciphertext blobs; decryption must fail.
- **Severity.** Medium (High when swapping grants access).
- **Fix.** AAD = canonical encoding of all binding context; never secrets.
- **Refs.** [E] RFC 5116. CWE-345.

## S-21 No key commitment (partitioning oracles, invisible salamanders)

- **Flaw.** AES-GCM, ChaCha20-Poly1305, AES-GCM-SIV are not key-committing: one ciphertext can decrypt validly under multiple keys. With password-derived keys and an oracle that reveals success/failure, each query tests many passwords at once (partitioning oracle). In messaging with content moderation/franking, allows one message to show different content to different recipients.
- **Trace.** Password KDF → AEAD key, with observable decrypt success; multi-recipient/abuse-reporting designs.
- **Severity.** Medium–High in those designs; otherwise informational.
- **Fix.** Add a commitment (e.g., include `HMAC(key, "commit")` or derive `(K_enc, K_commit)` via HKDF and send `K_commit` hash), use a committing AEAD construction (CTX, or "padding fix" with a block of zeros for GCM), or HPKE/ Signal-style designs that already commit.
- **Refs.** [L] Len, Grubbs, Ristenpart, "Partitioning Oracle Attacks" (USENIX Security 2021); Dodis, Grubbs, Ristenpart, Woodage (CRYPTO 2018); Albertini et al., "How to Abuse and Fix Authenticated Encryption Without Key Commitment" (USENIX Security 2022).

## S-22 Padding oracle (Vaudenay), Lucky13, POODLE

- **Flaw.** If the receiver reveals whether CBC padding was valid — distinct error message, HTTP status, exception type, log line, or timing — an attacker decrypts any ciphertext with ~128 queries per byte and can encrypt chosen plaintexts, without the key. Lucky13 is the timing variant inside TLS MtE; POODLE is the SSLv3 variant.
- **Code.** `catch (BadPaddingException e) { return 400; } catch (MacException e) { return 403; }`; `PKCS7` unpadding that raises before MAC check; `openssl_decrypt` returning `false` (padding) vs garbage (MAC later); any CBC + "decrypt then validate" flow exposed to clients (cookies, tokens, API blobs, SAML/XML Enc `cbc` without integrity — CVE-2011-1096-style). Also `.NET` `CryptographicException` surfaced in responses (ASP.NET MS10-070).
- **Trace.** Decrypt path exposed to untrusted input → all error-handling branches → anything observable.
- **Confirm (no exploit).** Build two ciphertexts: one with a corrupted last byte (bad padding) and one with a corrupted middle byte (valid padding likely, bad MAC/content). Compare response code, body, headers, and timing distribution (`scripts/timing_check.py` style). Any distinguishable difference ⇒ Confirmed. For TLS: `testssl.sh --padding-oracle`-style scanners / tlsfuzzer.
- **FP.** Error is identical in every way and the MAC is verified before unpadding (Encrypt-then-MAC with uniform failure).
- **Severity.** High (Critical for session tokens or when encryption of chosen plaintext matters).
- **Fix.** AEAD; or EtM with single uniform failure path and constant-time behaviour.
- **Refs.** [L] Vaudenay (EUROCRYPT 2002); AlFardan & Paterson, "Lucky Thirteen" (IEEE S&P 2013); Möller, Duong, Kotowicz, "This POODLE Bites" (2014). CVE-2013-0169 (Lucky13), CVE-2014-3566 (POODLE), CVE-2010-3332 (ASP.NET). CWE-209, CWE-208.

## S-23 Length extension with H(key ‖ message)

- **Flaw.** Merkle–Damgård hashes (MD5, SHA-1, SHA-256, SHA-512) let anyone compute H(k‖m‖pad‖m′) from H(k‖m) and |k|, without k. Any "signature = sha256(secret + payload)" API is forgeable.
- **Code.** `hashlib.sha256(secret + body)`, `MessageDigest` fed secret then data, `crypto.createHash('sha256').update(secret).update(data)`, PHP `md5($secret . $data)`.
- **Confirm.** Static is conclusive; optionally demonstrate with a library (hashpump) on a test vector — not needed.
- **FP.** SHA-3/Keccak, BLAKE2/BLAKE3 keyed modes, SHA-512/256 (truncated outputs resist extension), H(m‖k) (not extendable but still not HMAC — flag as Low).
- **Severity.** High.
- **Fix.** HMAC (or KMAC/BLAKE2 keyed).
- **Refs.** [E] FIPS 198-1; RFC 2104. CWE-328.

## S-24 MD5 / SHA-1 for integrity or signatures; CRC as integrity

- **Flaw.** Practical collisions (MD5 chosen-prefix since 2009; SHA-1 chosen-prefix 2020 at ~$45k). Signatures over MD5/SHA-1 and file-integrity checks are forgeable by collision. CRC32/Adler are not cryptographic at all.
- **Code.** `Signature.getInstance("SHA1withRSA")`, `hashes.SHA1()` in signatures/certs, `md5sum` for downloads, `zlib.crc32` as "checksum" of security-relevant data, HMAC-MD5 (still OK as MAC, flag Low/informational).
- **Trace.** Context! Cache keys, ETags, dedup, Git-style content addressing without security claims: not findings. Integrity/signature/password: findings.
- **Severity.** High (signatures/code signing); Medium (integrity); Low (HMAC-SHA1/MD5).
- **Fix.** SHA-256+ / SHA-3; HMAC for keyed integrity.
- **Refs.** [E] SP 800-131A Rev.2 (SHA-1 for digital signatures disallowed); [L] Stevens et al., "SHAttered" (CRYPTO 2017); Leurent & Peyrin, "SHA-1 is a Shambles" (USENIX Security 2020). CWE-328.

## S-25 Password hashing: fast hash, no salt, weak parameters

- **Flaw.** SHA-256/MD5 (even salted) run at billions/second on GPUs; PBKDF2 with 1,000 iterations, bcrypt cost < 10, scrypt N < 2^14, Argon2 with tiny memory. Missing or global salt enables rainbow tables and multi-target attacks. Truncation (bcrypt 72-byte input, "null byte" issues).
- **Code.** `hashlib.sha256(salt + pw)`; `Rfc2898DeriveBytes(pw, salt)` (legacy ctor: SHA-1, 1,000 it.); `PBEKeySpec(pw, salt, 1000, 256)`; `bcrypt.gensalt(4)`; `argon2.PasswordHasher(memory_cost=1024)`; `crypto.pbkdf2Sync(pw, salt, 1000, 32, 'sha1')`; `password_hash($p, PASSWORD_BCRYPT, ['cost'=>4])`; PHC strings in the DB with `$2b$04$`, `$argon2id$v=19$m=1024,t=1`.
- **Trace.** Password → primitive → parameters (read actual numbers; config may override). Also check: hashes exposed in APIs/logs; "pepper" handling.
- **Confirm.** Compute the parameters programmatically from stored hashes (PHC string parsing); benchmark the hash (should be ≥ ~100 ms server-side as a rule of thumb).
- **FP.** High-entropy random tokens hashed with SHA-256 (fine); API keys (fine with SHA-256 + salt if ≥128 bits random).
- **Severity.** High.
- **Fix (OWASP, 2025–2026 guidance).** Argon2id m=19 MiB, t=2, p=1 minimum (prefer 47 MiB/t=1 or 19/t=2); scrypt N=2^17, r=8, p=1; bcrypt cost ≥10 only for legacy; FIPS-constrained: PBKDF2-HMAC-SHA256 ≥ 600,000 iterations. Per-user random salt ≥16 bytes; optional pepper via HMAC pre-hash.
- **Refs.** [P] OWASP Password Storage Cheat Sheet; [E] NIST SP 800-63B-4, SP 800-132, RFC 9106 (Argon2). CWE-916, CWE-759, CWE-760.

## S-26 HKDF / KDF misuse

- **Flaw.** HKDF applied to low-entropy passwords (not a password KDF); empty/reused `info` so sub-keys for different purposes are identical; only HKDF-Expand on a non-uniform IKM; salt misuse; hand-rolled KDF (`sha256(secret + "enc")`) with ambiguous inputs; truncating a shared secret as a key.
- **Code.** `HKDF(…, info=b'')` for multiple keys; `HKDFExpand(…)` directly on a DH output; `derive(password)`.
- **Confirm.** Derive two "different" keys; equality ⇒ confirmed.
- **Severity.** Medium (High if sub-keys collide across purposes).
- **Fix.** HKDF-Extract on the raw secret, Expand with distinct, versioned `info` per purpose; SP 800-108 KDFs for symmetric master keys; Argon2/PBKDF2 for passwords.
- **Refs.** [E] RFC 5869; SP 800-56C Rev.2; SP 800-108 Rev.1; SP 800-133.

## S-27 One key used in several modes, primitives or protocols (cross-mode oracle)

- **Flaw.** A block-cipher key is safe only inside the one construction it was generated for. Used in two, each construction can act as an oracle against the other. The classic case: the same AES key drives AES-GCM for live data and AES-CBC with a fixed/zero IV (or ECB, or raw block calls) for a "legacy", "export" or "migration" path. CBC with a zero IV applied to a single chosen block returns the raw block-cipher output `E_K(block)`. Anyone who can feed chosen plaintext to that path and read the result can therefore compute `E_K(0^128)` (the GHASH subkey H) and `E_K(nonce ‖ counter)` (the GCM keystream and tag mask), which is everything needed to decrypt and forge the GCM-protected data — without ever learning the key. The same reasoning applies to AES-CMAC or CBC-MAC sharing a key with CBC/CTR encryption, to a KEK also used as a DEK, to one RSA key in two padding schemes (A-12), and to one secret used both as an HMAC key and as a password/token.
- **Why audits miss it.** Each use looks like a separate, lesser finding ("legacy CBC, Medium" and "GCM, fine"). The severity only appears when the *key* is traced rather than the call.
- **Code.** One key variable (`MASTER_KEY`, `KEY`, `self.key`, a single env var) reaching more than one of: `AESGCM(...)`, `modes.CBC/CTR/ECB`, `Cipher.getInstance("AES/…")` with different transformations, `CMAC`, `hmac.new`, `Fernet`; "v1/v2" format handlers that kept the key and changed the mode; export/backup/migration jobs; a debug or test endpoint that encrypts caller-supplied data with the production key.
- **Trace.** For every key: list every call site that uses it, with mode and IV source. Then ask of each path: who controls the plaintext, and who sees the ciphertext? A path with attacker-influenced plaintext and visible output is an oracle for every other path on that key.
- **Confirm.** Reading is usually conclusive: show the two call sites and the shared key. A property test may show the structural fact — encrypting a single block through the legacy path equals the raw block-cipher output for that block — but stop there; do not build the decryption or forgery.
- **FP.** Sub-keys derived per purpose with HKDF and distinct `info` (then the "same key" is only the root). Libraries that derive internal sub-keys themselves (Fernet splits its key; AES-GCM-SIV and AES-SIV derive per-message or per-purpose keys). Decrypt-only legacy paths that take no new plaintext (still S-04/S-05 on their own, but not an encryption oracle).
- **Severity.** Critical when the weaker path accepts attacker-influenced plaintext and returns ciphertext; High when it is reachable only by trusted jobs (one compromised job away); the individual findings (S-03/S-04/S-05) keep their own severity.
- **Fix.** One key, one algorithm, one purpose. Derive `K_gcm`, `K_legacy`, `K_mac` from the root with HKDF and distinct, versioned `info`; rotate the shared key and re-encrypt, because data written while the oracle existed must be treated as exposed. Retire the legacy path.
- **Refs.** [E] NIST SP 800-57 Pt.1 Rev.5 §5.2 (a key shall be used for one purpose); SP 800-38D §8.1 (GCM key not used with other modes); SP 800-108 Rev.1 (deriving separate keys). [P] key-separation principle. CWE-323, CWE-320.
