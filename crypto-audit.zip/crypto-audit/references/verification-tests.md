# Verification test recipes

Property tests that turn a `Probable` finding into `Confirmed` without writing exploit code. Each recipe states the property, gives a minimal test (Python/pytest unless noted — adapt to the project's language and harness), and says what the outcome means. Commit the tests to the client's repo under `tests/crypto/` when possible, so the fix is regression-tested.

Principle: **test the real code path** (the project's `encrypt()`/`verify()`/API endpoint), not a re-implementation. If you must stub (no network, no KMS), say so in the finding.

Contents: T0 pinned versions · T1 determinism/IV · T2 nonce uniqueness · T3 malleability · T4 tag truncation · T5 plaintext-before-tag · T6 AAD binding · T7 padding/MAC oracle distinguishability · T8 timing of comparisons · T9 RNG provenance · T10 password KDF parameters · T11 length extension · T12 RSA key sanity · T13 RSA decrypt oracle (error/timing) · T14 signature validation edge cases (r=s=0, malleability, explicit params) · T15 point/public-key validation · T16 X25519 small order · T17 JWT acceptance tests · T18 TLS client validation · T19 ML-KEM input checks & implicit rejection · T20 LMS/XMSS state · T21 hybrid combiner · T22 spec-vs-code claims · T23 shared key across modes · T24 failure paths

---

## T0 — Run every behaviour test on the pinned dependency versions
What a library accepts changes between releases, so a result on whatever happens to be installed proves little about the project. Install the pinned versions into an isolated directory (never modify the project's or the system's packages) and run the tests against that:
```bash
SCRATCH=$(mktemp -d)
pip install --quiet --target "$SCRATCH/pinned" -r requirements.txt        # or: 'PyJWT==1.7.1'
PYTHONPATH="$SCRATCH/pinned" python -c "import jwt; print(jwt.__version__)" # confirm what is being tested
PYTHONPATH="$SCRATCH/pinned" pytest tests/crypto -q
# Node: copy package.json + package-lock.json to "$SCRATCH/js" && (cd "$SCRATCH/js" && npm ci)
# Go:   the module's go.sum already pins; run `go test` inside the module
# Java: mvn -o dependency:build-classpath, or put the pinned jar on the test classpath
```
Practicalities:
- `pip install --target` may print "dependency conflict" errors about *other* installed packages. They are harmless here: nothing outside the scratch directory is changed.
- Keep the target tree untouched: `PYTHONDONTWRITEBYTECODE=1` and `pytest -p no:cacheprovider` stop Python and pytest writing `__pycache__`/`.pytest_cache` into it.
- Modules that open files relative to the working directory at import time (key files, config) must be imported with the project root as the working directory.
- Keep local paths out of attachments: run tools on a relative path (`.`), and run pytest with `-q -p no:cacheprovider --rootdir .` so logs do not embed your directory layout.
- Keep secrets out of the test output (rule 10): run pytest with `--assert=plain` so a failing assertion does not print its operands, give assertions explicit messages, and read keys or secrets from the project at run time instead of copying them into the test file. Before attaching anything, run `python3 scripts/leak_scan.py <target> <outputs>`.
- **Nothing is pinned** (no lockfile, no `go.mod`, no `pom.xml`), or the pin is a range: the project can end up on any version, so one test on whatever is installed can hide a finding. Test on the installed version *and* on an older release the project could plausibly resolve to — in particular on both sides of any behaviour change the catalog mentions (for example `cryptography` 41 vs 42 for PKCS#1 v1.5 errors, PyJWT 2.8 vs 2.15 for empty keys). Name each version in the evidence and mark results `Confirmed` *for that version*. Report the missing pin itself as a finding (Informational, or higher when behaviour differs between versions you tried).

Write the tested version into the evidence ("PyJWT 2.8.0, pinned"). If the pinned version cannot be installed (offline, no-network instruction, private registry), keep the finding `Probable` and include the command above so the client can confirm it. Running the same test on the installed version *as well* is useful: a difference between the two is itself worth reporting (the project is one upgrade or downgrade away from changing behaviour).

## T1 — Determinism / fixed IV (S-03, S-04)
Property: encrypting the same plaintext twice must give different ciphertexts.
```python
def test_encrypt_not_deterministic(enc):
    pt = b"A" * 64
    assert enc(pt) != enc(pt)
def test_ecb_pattern(enc):
    ct = enc(b"\x00" * 32)
    body = ct[-32:]           # adjust if IV/tag are prepended/appended
    assert body[:16] != body[16:32], "identical blocks => ECB"
```
Fails ⇒ deterministic encryption (ECB or fixed IV): Confirmed.

## T2 — Nonce/IV uniqueness across calls, processes, restarts (S-06, S-07, S-09, S-10)
Property: nonces under one key never repeat.
```python
import subprocess, json
def collect(n):  # call the real code path n times, return nonces (parse from ciphertext format)
    ...
def test_nonce_unique_in_process():
    ns = collect(10_000); assert len(set(ns)) == len(ns)
def test_nonce_unique_across_restart(tmp_path):
    a = json.loads(subprocess.check_output(["python", "-m", "app.encrypt_demo", "5"]))
    b = json.loads(subprocess.check_output(["python", "-m", "app.encrypt_demo", "5"]))
    assert not set(a) & set(b), "nonce repeated after restart"
def test_nonce_unique_concurrent():
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(16) as ex: ns = sum(ex.map(lambda _: collect(500), range(16)), [])
    assert len(set(ns)) == len(ns)
```
Then run `scripts/nonce_audit.py nonces.txt` for length/entropy/sequence analysis. Any duplicate ⇒ Confirmed Critical for AEAD/CTR.

## T3 — Malleability / missing authentication (S-05)
Property: any modification of ciphertext is rejected.
```python
import pytest
def test_bitflip_rejected(enc, dec):
    ct = bytearray(enc(b"role=user;id=42"))
    ct[len(ct)//2] ^= 0x01
    with pytest.raises(Exception):
        dec(bytes(ct))
```
If `dec` returns (garbled or, worse, meaningful) plaintext ⇒ Confirmed. Extend: flip the byte that lands on `user` and check whether `admin`-style edits survive (CBC/CTR bit-flipping) — the structural demonstration is enough, no need to craft a privilege escalation.

## T4 — Tag truncation (S-08, S-11)
Property: a decryptor rejects tags shorter than 128 bits.
```python
def test_short_tag_rejected(dec, ct_with_16B_tag):
    ct, tag = ct_with_16B_tag
    with pytest.raises(Exception):
        dec(ct, tag[:4])
```

## T5 — Plaintext released before tag verification (S-19)
Property: a tampered stream produces no side effect.
```python
def test_no_partial_output_on_tamper(stream_dec, tmp_path, tampered_stream):
    out = tmp_path / "out.bin"
    with pytest.raises(Exception):
        stream_dec(tampered_stream, out)
    assert not out.exists() or out.stat().st_size == 0
```

## T6 — AAD / context binding (S-20)
Property: a ciphertext for record A cannot be decrypted as record B.
```python
def test_ciphertext_not_transplantable(enc, dec):
    ct = enc(record_id=1, data=b"x")
    with pytest.raises(Exception):
        dec(record_id=2, ct=ct)
```

## T7 — Padding / MAC oracle distinguishability (S-16, S-22) — no decryption attempted
Property: responses to "bad padding" and "bad MAC/content" are indistinguishable (status, body, headers, timing).
```python
import time, statistics, requests
def probe(ct):
    t0 = time.perf_counter(); r = requests.post(URL, data={"blob": ct}); dt = time.perf_counter() - t0
    return r.status_code, r.text.strip(), dt
def test_padding_vs_mac_indistinguishable(valid_ct):
    bad_pad = valid_ct[:-1] + bytes([valid_ct[-1] ^ 0xFF])    # corrupt last byte: padding likely invalid
    bad_mid = valid_ct[:16] + bytes([valid_ct[16] ^ 0xFF]) + valid_ct[17:]  # middle: padding likely fine, content/MAC bad
    A = [probe(bad_pad) for _ in range(200)]; B = [probe(bad_mid) for _ in range(200)]
    assert {a[0] for a in A} == {b[0] for b in B}, "status differs"
    assert {a[1] for a in A} == {b[1] for b in B}, "body differs"
    # timing: use scripts/timing_check.py --stats on the dt columns (Welch t-test; |t| > 4.5 is a leak)
```
Any stable difference ⇒ Confirmed oracle. For TLS endpoints use `testssl.sh` (padding oracle checks) or tlsfuzzer.

**The same property for a function rather than an HTTP endpoint.** Random byte flips are unreliable probes (a flip in the last block usually breaks the padding *and* the content). Build the two cases deterministically: encrypt a plaintext whose length is a multiple of the block size and at least two blocks, so the final block is pure padding. Probe A flips the last byte of the second-to-last ciphertext block: the padding becomes invalid. Probe B flips the first byte of the *first* ciphertext block: the padding block is untouched, only content (and therefore the MAC) is wrong.
```python
def outcome(fn, *args):
    try: fn(*args); return "accepted"
    except Exception as e: return f"{type(e).__name__}: {e}"

def test_padding_and_mac_failures_look_the_same(encrypt, decrypt_with_ct):
    ct = bytearray(encrypt(b"A" * 32))                 # adjust: take the raw CBC ciphertext out of the project's format
    a = bytearray(ct); a[-17] ^= 0xFF                  # last byte of the second-to-last block -> invalid padding
    b = bytearray(ct); b[0] ^= 0xFF                    # first block -> padding intact, content/MAC wrong
    assert outcome(decrypt_with_ct, bytes(a)) == outcome(decrypt_with_ct, bytes(b)), "padding and MAC failures are distinguishable"
```
Two different outcomes also prove the order of operations: the MAC cannot have been verified first (S-16), with no need to instrument the code.

## T8 — Timing of comparisons (S-18, T-01)
For a comparison written with `==`, `memcmp`, `Arrays.equals`, `bytes.Equal` or `===` on a secret-derived value, **the code is the finding**; no measurement is needed, and a measurement that shows nothing does not clear it (a few nanoseconds are below what an interpreter-level timer resolves). Use `scripts/timing_check.py` when there is a large difference worth demonstrating: an early-exit loop, a password hash computed only for users that exist, distinct padding/MAC error paths.
```bash
cd <project root>
python3 <skill>/scripts/timing_check.py --module app.auth --func check_mac \
  --input-a 'b"\xff"+b"\x00"*31' --input-b 'b"\x00"*31+b"\xff"'            # mismatch at first byte vs last byte
python3 <skill>/scripts/timing_check.py --module app.auth --func verify_payload --star \
  --input-a '(b"payload", "0"*64)' --input-b '(b"payload", "f"+"0"*63)'       # several arguments: tuples + --star
```
The tool runs several independent rounds and reports a leak only when the rounds agree in direction, most exceed |t| > 4.5, and the median difference is above a minimum effect size (20 ns or 2% of the run time by default). Otherwise it says "no practical difference", "inconclusive" or "no evidence". Quote its per-round table in the evidence, and never upgrade an "inconclusive" to a finding.

## T9 — RNG provenance (S-14, S-15)
Static trace is primary. Dynamic sanity for "is the seed derivable":
```python
def test_tokens_not_reproducible():
    import random
    random.seed(1234); a = app.make_token()
    random.seed(1234); b = app.make_token()
    assert a != b, "token depends on random.seed => non-CSPRNG"
```
Fork test (C/Python wrappers of userland DRBGs): fork, draw 32 bytes in parent and child, assert different.

## T10 — Password KDF parameters (S-25)
```python
import re
def test_stored_hash_params(sample_hash):
    m = re.match(r"\$argon2id\$v=19\$m=(\d+),t=(\d+),p=(\d+)\$", sample_hash)
    if m: assert int(m[1]) >= 19456 and int(m[2]) >= 2; return
    m = re.match(r"\$2[aby]\$(\d\d)\$", sample_hash)
    if m: assert int(m[1]) >= 10; return
    m = re.match(r"pbkdf2_sha256\$(\d+)\$", sample_hash)   # Django style
    if m: assert int(m[1]) >= 600_000; return
    pytest.fail("unrecognised or fast hash: " + sample_hash[:12])
def test_hash_is_slow():
    import time; t0=time.perf_counter(); app.hash_password("correct horse"); assert time.perf_counter()-t0 > 0.05
```

## T11 — Length extension susceptibility (S-23)
Static: `H(secret||data)` with MD5/SHA-1/SHA-256/SHA-512 ⇒ Confirmed by construction. No dynamic test needed; cite the construction and the line.

## T12 — RSA key sanity (A-01, A-03, A-08, A-09)
```bash
python3 scripts/key_analyzer.py path/to/keys_or_certs/ --gcd --roca --wiener --fermat 10000 --json keys.json
```
Flags: size < 2048, e < 65537, shared factors across the set, ROCA fingerprint, small-d (Wiener continued fractions), near primes (Fermat few iterations). Any positive on `--gcd/--roca/--wiener/--fermat` ⇒ Critical, Confirmed (the key is factorable; do not factor client keys beyond what the check itself does).

## T13 — RSA PKCS#1 v1.5 decryption oracle (A-04, A-05) — no plaintext recovery
Property: well-formed and malformed ciphertexts produce identical errors and timing.
```python
def test_rsa_decrypt_uniform(decrypt_api, pub):
    from cryptography.hazmat.primitives.asymmetric import padding
    good = pub.encrypt(b"session-key", padding.PKCS1v15())
    bad  = good[:-1] + bytes([good[-1] ^ 1])      # change the low byte: flipping the top byte can push the value above the modulus, which fails for a different reason
    resp_good = [decrypt_api(good) for _ in range(300)]; resp_bad = [decrypt_api(bad) for _ in range(300)]
    # compare error classes/messages; timing via timing_check.py --stats
```
Also: version check against CVE list in A-04; for TLS, tlsfuzzer `test-bleichenbacher-timing-pregenerate.py` (reports only; it doesn't decrypt).
Read the result with the library build in mind: on OpenSSL 3.2+ (and distribution backports, e.g. Ubuntu's 3.0.13) bad padding yields a pseudo-random plaintext instead of an error, so identical "errors" are expected and say nothing about whether v1.5 is still in use. On such builds test the *caller* instead: does it treat a garbage plaintext (wrong length, wrong format) differently from a valid one in any observable way?

## T14 — Signature verification edge cases (A-06, A-20, A-21, A-22)
```python
def test_ecdsa_zero_signature_rejected(verify, pub, msg):
    from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature
    for r, s in [(0, 0), (0, 1), (1, 0)]:
        assert not verify(pub, msg, encode_dss_signature(r, s))
def test_ecdsa_out_of_range_rejected(verify, pub, msg, n):
    assert not verify(pub, msg, encode_dss_signature(n, n))
def test_rsa_pkcs1_lax_padding_rejected():  # use Wycheproof rsa_signature_2048_sha256_test.json
    ...
def test_explicit_curve_params_cert_rejected(load_and_verify, explicit_params_cert_pem):
    with pytest.raises(Exception): load_and_verify(explicit_params_cert_pem)
```
Wycheproof: iterate `testvectors_v1/*.json`, assert `result == "valid"` ⇔ verifier accepts (treat `acceptable` per project policy).

## T15 — Public-key / point validation (A-15, A-18)
```python
def test_offcurve_point_rejected(ecdh, priv):
    # P-256: pick x on curve, use y+1
    with pytest.raises(Exception): ecdh(priv, peer_point(x, y + 1))
def test_dh_degenerate_rejected(dh, priv, p):
    for y in (0, 1, p - 1): 
        with pytest.raises(Exception): dh(priv, y)
```
Wycheproof `ecdh_*`, `dh_test.json`.

## T16 — X25519 small-order inputs (A-24)
```python
SMALL_ORDER = [bytes(32), b"\x01"+bytes(31), bytes.fromhex("e0eb7a7c3b41b8ae1656e3faf19fc46ada098deb9c32b1fd866205165f49b800")]
def test_x25519_small_order_aborts(kex, priv):
    for pk in SMALL_ORDER:
        with pytest.raises(Exception): kex(priv, pk)
```

## T17 — JWT acceptance tests (C-02…C-05)
```python
import base64, json
def b64(x): return base64.urlsafe_b64encode(x).rstrip(b"=")
def tok(header, payload, sig=b""): return b".".join([b64(json.dumps(header).encode()), b64(json.dumps(payload).encode()), b64(sig)]).decode()
def test_alg_none_rejected(api, claims):
    for alg in ("none", "None", "NONE", "nOnE"):
        assert api(tok({"alg": alg, "typ": "JWT"}, claims)).status_code == 401
def test_empty_or_default_secret_rejected(api, claims, monkeypatch):
    # C-04: run with the secret variable unset, then sign with the fallback value the code would use
    import hmac, hashlib
    h = {"alg": "HS256", "typ": "JWT"}; body = b".".join([b64(json.dumps(h).encode()), b64(json.dumps(claims).encode())])
    for fallback in (b"", b"secret", b"changeme"):   # use the literal default found in the code
        sig = hmac.new(fallback, body, hashlib.sha256).digest()
        assert api(body.decode() + "." + b64(sig).decode()).status_code == 401
def test_hs256_with_public_key_rejected(api, claims, public_pem):
    import hmac, hashlib
    h = {"alg": "HS256", "typ": "JWT"}; body = b".".join([b64(json.dumps(h).encode()), b64(json.dumps(claims).encode())])
    sig = hmac.new(public_pem, body, hashlib.sha256).digest()
    assert api(body.decode() + "." + b64(sig).decode()).status_code == 401
def test_missing_exp_and_wrong_aud_rejected(api, sign):
    assert api(sign({"sub": "u1"})).status_code == 401
    assert api(sign({"sub": "u1", "exp": 4102444800, "aud": "other"})).status_code == 401
def test_embedded_jwk_ignored(api, sign_with_fresh_key):
    assert api(sign_with_fresh_key(embed_jwk=True)).status_code == 401
def test_kid_traversal_rejected(api, claims):
    assert api(tok({"alg": "HS256", "kid": "../../../../dev/null"}, claims, b"")).status_code == 401
```
`scripts/jwt_inspect.py sample.jwt` lists header/claim issues for tokens captured during the audit.

## T18 — TLS client validation (C-01, C-06)
```bash
# self-signed server: python3 -m http.server? no TLS. Use openssl:
openssl req -x509 -newkey rsa:2048 -nodes -keyout k.pem -out c.pem -subj /CN=wrong.example -days 1
openssl s_server -accept 8443 -cert c.pem -key k.pem -www &
# point the client under test at https://localhost:8443 ; it MUST fail (chain) — and with a CA-signed cert for a different name it MUST fail (hostname)
```
Server side: `testssl.sh --full host:port` or `sslyze`; assert no TLS1.0/1.1, no CBC/RSA-kex suites, FS everywhere, DH ≥2048.

Without those scanners, two `openssl` checks cover most of it, and they show what a configuration means *on this build* (C-06):
```bash
openssl ciphers -v 'HIGH:MEDIUM:3DES:RC4:!aNULL' | awk '{print $1, $2, $3, $5}'   # which suites the string really selects
openssl s_server -accept 8443 -cert c.pem -key k.pem -tls1 -www &                  # loopback server forced to one version
openssl s_client -connect localhost:8443 -tls1 </dev/null 2>&1 | grep -E 'Protocol|Cipher|alert'
```
Record the OpenSSL version next to the result: the same configuration negotiates differently on another build.

## T19 — ML-KEM input checks and implicit rejection (P-03, P-04)
```python
def test_ek_modulus_check(encaps, ek):
    bad = bytearray(ek); bad[0:2] = (3329).to_bytes(2, "little")  # coefficient >= q (adjust to ByteEncode12 layout)
    with pytest.raises(Exception): encaps(bytes(bad))
def test_decaps_implicit_rejection(decaps, dk, ct):
    bad = bytes([ct[0] ^ 1]) + ct[1:]
    k1 = decaps(dk, bad); k2 = decaps(dk, bad)
    assert len(k1) == 32 and k1 == k2        # deterministic pseudorandom key, no exception
    assert k1 != decaps(dk, ct)
```
Timing: `timing_check.py` over valid vs tampered ciphertexts (dudect |t| < 4.5 expected).

## T20 — LMS/XMSS state (P-07)
Property: no OTS index is ever reused. Test: sign, kill the process before state persistence, restart, sign again, compare indices (they must differ); restore from a backup taken before signing ⇒ signer must refuse or use a reserved sub-tree.

## T21 — Hybrid combiner (P-08)
Property: failure of either component fails the whole; secrets are combined with a KDF in the specified order.
```python
def test_hybrid_requires_both(hybrid_decaps, dk, ct_ok):
    ct_bad_mlkem = tamper(ct_ok, part="mlkem"); ct_bad_x25519 = tamper(ct_ok, part="x25519")
    assert hybrid_decaps(dk, ct_bad_mlkem) != hybrid_decaps(dk, ct_ok)
    assert hybrid_decaps(dk, ct_bad_x25519) != hybrid_decaps(dk, ct_ok)
```
Interop: negotiate `X25519MLKEM768` with OpenSSL ≥3.5 (`openssl s_client -groups X25519MLKEM768`) and confirm the group ID in the capture.

## T22 — Spec-vs-code claims
For each claim extracted from documentation, write one assertion that would fail if the code diverged:
| Claim | Test |
|---|---|
| "AES-256-GCM" | key length == 32 and cipher name/ctor is GCM (T1 + inspect) |
| "random 96-bit nonce" | nonce length == 12 and T2 passes |
| "passwords with Argon2id" | T10 on a stored hash |
| "TLS 1.2+" | T18 server scan |
| "keys rotated every 90 days" | key metadata/`kid` timestamps < 90 days; rotation job exists |


## T23 — One key in several modes (S-27)
Reading is normally conclusive: cite both call sites and the shared key. If a structural demonstration helps the reader, show only that the weaker path exposes the raw block cipher:
```python
def test_legacy_path_is_a_raw_block_oracle(legacy_encrypt, key):
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    block = bytes(range(16))
    raw = Cipher(algorithms.AES(key), modes.ECB()).encryptor().update(block)   # test-only reference value
    assert legacy_encrypt(block)[:16] != raw, "legacy path returns E_K(block): it is an oracle for every other mode on this key"
```
Stop there. Do not go on to compute GCM keystream or tags from it.

## T24 — Failure paths (T-02)
Property: every failure of a cryptographic call ends in a clean rejection, never in acceptance, plaintext output, a crash or a weaker fallback.
```python
import pytest
@pytest.mark.parametrize("bad", [b"", b"\x00" * 4, b"\xff" * 256])
def test_malformed_signature_rejected(verify, message, bad):
    assert verify(message, bad) is False            # not True, not an exception that a caller swallows
def test_wrong_length_key_fails_closed(encrypt):
    with pytest.raises(Exception):
        encrypt(b"data", key=b"short")              # must not return the input unchanged
```
For C, compile the function with a stub that makes the library call return its error value (-1) and assert the wrapper reports failure. For Go, call the function and assert it returns an error rather than panicking.

## T25 — What the MAC or signature covers (S-17, S-20, C-11)
Property: changing *any* part of the stored or transmitted object is detected — not only the ciphertext.
```python
import copy, pytest
FIELDS = ["iv", "ct", "mac", "keys", "version", "alg"]           # every field of the project's format

@pytest.mark.parametrize("field", FIELDS)
def test_every_field_is_authenticated(make_message, restore, field):
    msg = make_message(b"payload")
    if field not in msg: pytest.skip("not in format")
    bad = copy.deepcopy(msg); bad[field] = mutate(bad[field])     # flip a byte, drop or add a recipient, change the version
    with pytest.raises(Exception):
        restore(bad)
```
A field whose mutation is accepted is outside the integrity check. Then ask the C-11 question separately: can the test build a message the receiver accepts using only public inputs (the recipient's public key and the project's own encrypt function)? If yes, the format is unauthenticated regardless of what the MAC covers.
