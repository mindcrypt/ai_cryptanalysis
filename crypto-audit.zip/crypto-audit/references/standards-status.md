# Standards status snapshot

**Last verified: 2026-11-20.** Rows marked *(primary, 2026-11-20)* were read on the issuing body's own site on that date. Items marked **verify** come from secondary sources or are in flux: re-check the primary source before quoting them in a client-facing report. Re-validate this whole file every ~6 months; standards in the PQC transition move quickly. **If you cannot reach the primary sources** (offline, no web access), cite a row as "per the skill's standards snapshot of 2026-11-20, not re-verified" rather than as current fact.

## NIST

| Document | Status (as verified) | What it decides for an audit |
|---|---|---|
| **NIST IR 8547** — Transition to PQC Standards | Final, Oct 27, 2026 *(primary, 2026-11-20: csrc.nist.gov/pubs/ir/8547/final)* | Tables 2 and 4: ECDSA, EdDSA, RSA, finite-field and elliptic-curve DH/MQV are **deprecated after 2030 and disallowed after 2035**, regardless of key size ("NIST will deprecate all quantum-vulnerable cryptography after 2030"). High-value assets and high-impact systems: PQC key establishment by Dec 31, 2030 and PQC signatures by Dec 31, 2031. §4.1.2: "NIST recommends using ML-KEM-768 as the default parameter set." §3.2: hybrid key establishment via SP 800-56C (Z‖T, order fixed by the protocol); dual signatures require **all** component signatures to verify. |
| **SP 800-131A Rev. 2** — Transitioning algorithms and key lengths | Final (2019). Rev. 3 draft (Oct 2024) not final. | Rev. 2: TDEA encryption disallowed after 2023; SHA-1 for signatures disallowed; RSA/DH ≥2048, ECC ≥224 ("112-bit security") through 2030. Rev. 3 draft proposes withdrawing ECB, DSA, SHA-1 and 224-bit hashes (**verify** final text). |
| **SP 800-57 Pt.1 Rev.5** — Key management | Final (2020) | Cryptoperiods, key separation, security-strength table. |
| **SP 800-38A / 38C / 38D / 38E / 38F** — Modes | 38A final (2001, addendum 2010); 38C (CCM); 38D (GCM, 2007) — revision announced March 2024 to remove tags < 96 bits and clarify IV construction (**verify** whether Rev. 1 is published); 38E (XTS, storage only); 38F (key wrap). | IV/nonce rules, tag lengths, per-key limits. |
| **SP 800-90A Rev.1 / 90B / 90C** — DRBGs, entropy sources, RBG constructions | 90A Rev.1 final; 90B final; 90C final (2024/2025, **verify** edition) | What counts as an approved RNG; reseeding. |
| **SP 800-56A Rev.3 / 56B Rev.2 / 56C Rev.2** — Pair-wise key establishment / KDFs | Final | Public-key validation requirements (A-15, A-18), hybrid Z‖T. |
| **SP 800-108 Rev.1** — KDFs from pseudorandom functions | Final (2022) | Symmetric key derivation. |
| **SP 800-132** — Password-based key derivation | Final (2010) | PBKDF2 structure; iteration counts are dated — use OWASP numbers. |
| **SP 800-186** — Elliptic curve recommendations | Final (2023) | Approved curves (P-256/384/521, Curve25519/448, brainpool not approved). |
| **SP 800-208** — Stateful hash-based signatures | Final (2020) | LMS/XMSS only in hardware modules with non-exportable keys; state management. |
| **SP 800-227** — Recommendations for KEMs | Final (Sept 2025) | KEM usage, implicit rejection, combiners, key checks, ephemeral vs static. |
| **FIPS 186-5** — Digital Signature Standard | Final (2023) | ECDSA/EdDSA approved; RSA e range; deterministic/hedged ECDSA; DSA removed for new keys. |
| **FIPS 203 / 204 / 205** — ML-KEM / ML-DSA / SLH-DSA | Final Aug 13, 2024 | Mandatory input checks (203 §7), hedged default (204). |
| **FIPS 206** — FN-DSA (Falcon) | Not published. IR 8547 (Oct 2026) says NIST "is developing a FIPS that specifies a digital signature algorithm derived from FALCON" *(primary, 2026-11-20)* | Pre-standard; flag production use. |
| **HQC** | Selected March 11, 2025. IR 8547: "A FIPS that specifies HQC-KEM is under development" *(primary, 2026-11-20)*; no FIPS number assigned | Pre-standard. |
| **SP 800-52 Rev.2** — TLS guidance | Final (2019) | TLS 1.2 minimum, TLS 1.3 support; federal TLS 1.3 by Jan 2030 per EO 14306 (**verify**). |
| **SP 800-63B-4** — Authentication | Final (2024/2025, **verify** edition) | Password storage: salted, memory-hard KDF. |
| **NIST IR 8459** — Block cipher modes review | Final (2024) | Context for GCM/CBC limits. |

## IETF

| Document | Status | Relevance |
|---|---|---|
| RFC 8017 (PKCS#1 v2.2) | Standard | OAEP, PSS, notes on v1.5. |
| RFC 7748 / RFC 8032 | Standard | X25519/X448; Ed25519/Ed448 (zero-check §6.1; S<L; strict verification). |
| RFC 6979 | Informational | Deterministic (EC)DSA nonces. |
| RFC 7919 | Standard | Named FFDH groups (ffdhe2048…). |
| RFC 8446 (TLS 1.3) / RFC 8996 (deprecate TLS 1.0/1.1) / RFC 7465 (no RC4) | Standard / BCP | TLS requirements; AEAD limits §5.5. |
| RFC 9180 (HPKE) | Standard | KEM-DEM composition. |
| RFC 8439 (ChaCha20-Poly1305), RFC 8452 (AES-GCM-SIV), RFC 5297 (SIV) | Standard / Informational | AEAD definitions and limits. |
| RFC 5869 (HKDF), RFC 9106 (Argon2), RFC 2104 (HMAC), FIPS 198-1 | Standard / Informational | KDF/MAC. |
| RFC 7518 (JWA), RFC 8725 (JWT BCP), RFC 9068 (JWT access tokens) | Standard / BCP | JOSE rules. **draft-ietf-oauth-rfc8725bis-10** (Aug 21, 2026) is in the RFC Editor queue, not yet an RFC *(primary, 2026-11-20: datatracker)*; it will obsolete RFC 8725 and update RFC 7519. Cite RFC 8725 as the standard in force and 8725bis as approved-pending. |
| RFC 8554 (LMS/HSS), RFC 8391 (XMSS) | Informational | Stateful signatures. |
| **RFC 10024** — Post-quantum hybrid ECDHE-MLKEM key agreement for TLS 1.3 | Proposed Standard, Aug 2026 *(primary, 2026-11-20: datatracker)* | X25519MLKEM768 = 0x11EC (Recommended: Y), SecP256r1MLKEM768 = 0x11EB, SecP384r1MLKEM1024 = 0x11ED. Obsoletes the pre-standard code points X25519Kyber768Draft00 (0x6399) and SecP256r1Kyber768Draft00 (0x639A). Shared-secret ordering is fixed by the RFC. |
| RFC 5280 / RFC 6125 / RFC 7468 / X.690 | Standard | X.509, hostname matching, PEM, DER. |

## BSI (Germany)

| Document | Status | Relevance |
|---|---|---|
| **TR-02102-1** (2026-01, Jan 23, 2026) | Current | ≥120-bit security: RSA/DH ≥3000 bits, ECC ≥250 bits, AES ≥128; classical-only key agreement no longer recommended from 2031 (**verify**); Classic McEliece not recommended for new developments. |
| TR-02102-2 (TLS) | Current (check yearly) | TLS 1.2 with restricted suites / TLS 1.3; hybrid PQ groups. |
| TR-02102-3/-4 (IPsec, SSH) | Current | Protocol-specific parameters. |

## Other

- **OWASP** Password Storage Cheat Sheet (2025–2026): Argon2id 19 MiB / t=2 / p=1 minimum; scrypt N=2^17; bcrypt cost ≥10; PBKDF2-HMAC-SHA256 ≥600,000. OWASP ASVS 5.0 chapters V6 (cryptography) and V8 (data protection).
- **Mozilla SSL Configuration Generator** "modern"/"intermediate" profiles for concrete cipher lists.
- **CISA KEV** — CVE-2020-0601 (CurveBall) and others listed; useful for "this is exploited in the wild" severity arguments.
- **Project Wycheproof** (now under C2SP, `testvectors_v1`) — canonical negative test vectors; **x509-limbo** for certificate validation; **ACVP** vectors are valid-input only; **tlsfuzzer** scripts for Marvin/Bleichenbacher timing in TLS.

## Known-uncertain items to re-check before citing

1. Whether SP 800-131A Rev. 3 and the SP 800-38D revision are final.
2. FIPS 206 (FN-DSA) and the HQC FIPS: publication and numbers.
3. The RFC number of rfc8725bis once it leaves the RFC Editor queue.
4. BSI's exact date for ending classical-only key-agreement recommendations, and the current TR-02102-2 TLS profile.
5. Editions of SP 800-90C and SP 800-63B-4, and the federal TLS 1.3 date.
6. CVE identifiers in the catalogs. Checked against NVD or the vendor advisory when the catalog was compiled (2026-11): CVE-2016-2183, CVE-2016-0270, CVE-2022-4304, CVE-2023-0361, CVE-2023-49092, CVE-2024-30171, CVE-2023-46809, CVE-2024-2236, CVE-2020-25659, CVE-2024-20952, CVE-2017-15361, CVE-2020-1968, CVE-2024-31497, CVE-2019-11090, CVE-2019-16863, CVE-2022-21449, CVE-2020-0601. **Every other CVE identifier in the catalogs is cited from memory** (among them CVE-2013-0169, CVE-2014-3566, CVE-2015-4000, CVE-2008-0166, CVE-2006-4339, CVE-2014-1568, CVE-2015-9235, CVE-2022-0778, CVE-2010-3332, CVE-2016-0701, CVE-2017-11424, CVE-2022-29217, CVE-2022-23540, CVE-2014-1266, CVE-2014-0092): confirm it in NVD before it goes into a client report, or leave it out.
7. Library-behaviour statements in the catalogs marked "measured" were measured on the versions named there (PyJWT 1.7.1 / 2.8.0 / 2.15.0, JDK 21 SunJCE, Go 1.24). Other versions: test (recipe T0).
