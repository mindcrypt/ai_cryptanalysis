# Catalog — Post-quantum cryptography (P-01 … P-09)

Scope: NIST PQC standards (ML-KEM / FIPS 203, ML-DSA / FIPS 204, SLH-DSA / FIPS 205, FN-DSA / FIPS 206 in development, HQC selected 2025), stateful hash-based signatures (LMS/XMSS, SP 800-208), hybrid combiners, and the migration posture of a codebase. Status dates: see `standards-status.md` (verify before quoting in a client report).

Why audit PQC code differently: the primitives are new, reference code was written for correctness not side-channel safety, most libraries are young, and the standards contain *mandatory input checks* that conformance test vectors (ACVP) do not exercise because they only feed valid inputs. So: (1) check library provenance and version, (2) check every input validation the FIPS requires, (3) check constant-time properties of the hot paths, (4) check the combiner logic in hybrids, (5) check state management for LMS/XMSS.

Contents: P-01 standard status & pre-standard use · P-02 KyberSlash / timing · P-03 FIPS 203 input checks · P-04 implicit rejection · P-05 seeds, formats, randomness · P-06 ML-DSA/SLH-DSA deterministic vs hedged, context, pre-hash · P-07 LMS/XMSS state · P-08 hybrid combiners · P-09 FN-DSA pre-standard

---

## P-01 Standard status; pre-standard or non-final algorithm in production

- **Flaw.** Shipping Kyber/Dilithium *round-3* variants (not ML-KEM/ML-DSA — they differ in the KDF/hash steps and are not interoperable), FN-DSA/Falcon before FIPS 206 is final, HQC before its FIPS, or "Classic McEliece" in a context expecting a NIST standard. Also: ML-KEM-512 where the organisation's policy/BSI requires ≥ Level 3.
- **Code.** Library/algorithm identifiers: `kyber768` vs `ml-kem-768`, `dilithium3` vs `ml-dsa-65`, `falcon-512`, `hqc-128`; `liboqs` alg strings (`OQS_KEM_alg_kyber_768` is round-3, `OQS_KEM_alg_ml_kem_768` is FIPS 203); `pqcrypto` Rust crates (`pqcrypto-kyber` vs `pqcrypto-mlkem`); Bouncy Castle `MLKEMParameterSpec` vs `KyberParameterSpec`; OpenSSL ≥3.5 `ML-KEM-768`; Go `crypto/mlkem` (≥1.24); TLS group IDs (0x11EC X25519MLKEM768 final vs 0x6399 X25519Kyber768Draft00).
- **Trace.** Which identifiers does the code negotiate? What does the peer expect? Is the parameter set consistent with the security target (IR 8547 §4.1.2 recommends ML-KEM-768 as the default; BSI expects Level 3+)?
- **Confirm.** Interop test against a second implementation with known FIPS 203/204 KATs (`ML-KEM-768` KAT from NIST/ACVP).
- **Severity.** Medium (interop/compliance), High if a draft algorithm with known weaknesses is used.
- **Fix.** Use FIPS-final identifiers; mark draft/pre-standard use explicitly in docs; plan re-keying.
- **Refs.** [E] FIPS 203/204/205 (final Aug 13, 2024); NIST IR 8547 (final Oct 27, 2026; §4.1.2 recommends ML-KEM-768 as the default parameter set); SP 800-227 (KEM recommendations, Sept 2025); BSI TR-02102-1 2026-01.

## P-02 KyberSlash and other timing leaks in ML-KEM/ML-DSA implementations

- **Flaw.** Divisions by q=3329 on secret-dependent values in `poly_tomsg`/`poly_compress` compiled to variable-time division instructions (KyberSlash 1 & 2); secret-dependent branches in the implicit-rejection comparison (`if (memcmp(c, c') != 0)` instead of constant-time select); non-constant-time rejection sampling or NTT in ports; compiler re-introducing divisions under `-Os`. Demonstrated full key recovery on Cortex-M4 / Raspberry Pi via timing.
- **Code.** Any `/ KYBER_Q`, `% KYBER_Q`, `/ 3329` on values derived from secrets; `if` on the result of ciphertext comparison in decaps; ports of reference code (JS/WASM/Java/Go/Python) without the Barrett-reduction fixes; vendored `kyber` snapshots older than Dec 2023 (fix commits dda29cc, 272125f in pq-crystals/kyber); libraries listed at kyberslash.cr.yp.to.
- **Trace.** Library + version + whether the vendored copy includes the fixes; build flags.
- **Confirm.** Run the implementation under `valgrind` with TIMECOP/ctgrind-style secret marking, dudect, or `SILENT`; grep for `/` and `%` in polynomial compress/decompress and message encode paths.
- **Severity.** High–Critical (device-local or co-tenant attacker), Medium (cloud behind TLS with noisy network).
- **Fix.** Update library; use constant-time arithmetic (Barrett), `cmov`; compile with checks that no `div`/`idiv` is emitted in the hot path.
- **Refs.** [L] Bernstein, Bhargavan, Bhasin, et al., "KyberSlash: Exploiting secret-dependent division timings in Kyber implementations" (IACR TCHES 2025(2)). CWE-208, CWE-385.

## P-03 Missing FIPS 203 input checks

- **Flaw.** FIPS 203 §7 *requires*: (a) **encapsulation key check** — length check and *modulus check* (every coefficient of the decoded ek is < q; i.e., `ByteEncode12(ByteDecode12(ek)) == ek`); (b) **decapsulation key check** — length check and *hash check* (`H(ek) == stored h` inside dk), plus optional pair-wise consistency; (c) ciphertext length check. Skipping them allows malformed-key attacks, key-mismatch oracles, and interop surprises. ACVP valid-input tests do not exercise failures.
- **Code.** `mlkem_encaps(ek, …)` reading `ek` from the network with no checks; `ByteDecode` without the re-encode comparison; libraries exposing "unsafe" or "unchecked" constructors; JS/WASM ports.
- **Confirm.** Test: an `ek` with one coefficient set to 3329 or larger must be rejected; a `dk` with corrupted embedded hash must be rejected; a ciphertext of wrong length must be rejected. ACVP `encapsulationKeyCheck` / `decapsulationKeyCheck` test groups.
- **FP.** Keys generated and stored inside the same module (SP 800-227 allows skipping checks on module-internal keys) — note it anyway.
- **Severity.** Medium–High.
- **Refs.** [E] FIPS 203 §7.2–7.3; SP 800-227 §5.

## P-04 Implicit rejection broken (ML-KEM decapsulation)

- **Flaw.** FIPS 203 decapsulation never fails: on a ciphertext mismatch it returns a pseudorandom key `J(z ‖ c)` derived from the secret `z`. Implementations that throw an exception, return an error code, return zeros, or take a different amount of time on mismatch create a *key-mismatch oracle* that leaks the private key over many queries (and break the IND-CCA proof).
- **Code.** `raise DecapsulationError`, `return NULL`, `if (!equal) { log("bad ct"); ... }`, early return before the KDF, constant-time violation in the comparison/select.
- **Confirm.** Modify one byte of a ciphertext → decaps must return 32 deterministic bytes (same for repeated calls) with no error and with timing statistically indistinguishable from the valid case.
- **Severity.** High.
- **Fix.** Follow Algorithm 18 exactly; constant-time compare + select.
- **Refs.** [E] FIPS 203 Alg. 17/18; SP 800-227 §3.3.

## P-05 Seeds, key formats, and randomness

- **Flaw.** ML-KEM keys are fully determined by seeds (d, z); ML-DSA by ξ. Storing or transmitting the *seed* with less protection than the expanded key; ambiguity between seed-only, expanded-only and seed+expanded formats (a real interop and security issue — different libraries pick different encodings; the IETF LAMPS drafts settled on seed-preferred); using an RBG with less than the required security strength (FIPS 203 §3.3: strength ≥ parameter set level — e.g., 256-bit DRBG for ML-KEM-1024); reusing the encapsulation randomness `m`; deriving `m` from a hash of something predictable.
- **Code.** `seed = sha256(user_id)`; `random.getrandbits`; private key serialized as `(dk, seed)` with the seed in a less-protected field; key import that accepts expanded keys without the hash check (see P-03).
- **Confirm.** Review RNG provenance (S-14/S-15); round-trip serialization tests between libraries.
- **Severity.** High.
- **Refs.** [E] FIPS 203 §3.3, §6.1; FIPS 204 §3.6; SP 800-90A; draft-ietf-lamps-kyber-certificates (key format).

## P-06 ML-DSA / SLH-DSA: deterministic vs hedged, context strings, pre-hash variants

- **Flaw.** FIPS 204 defines *hedged* signing (default, mixes fresh randomness) and *deterministic* signing (only randomness-free). Deterministic signing on devices exposed to fault injection/side channels is riskier (differential fault analysis on Dilithium is published). Context strings (`ctx`, ≤255 bytes) must be consistent between signer and verifier; silently defaulting to empty on one side causes verification failures or domain-separation loss. Mixing ML-DSA and HashML-DSA (pre-hash) variants: a signature from one is not valid for the other, and HashML-DSA with a weaker hash than the parameter set's level lowers security. SLH-DSA is stateless (no index to manage; the per-key limit is 2^64 signatures), so the only pitfalls are parameter-set confusion between `-s` (small) and `-f` (fast) variants, which is an interop issue, and the same `ctx`/pre-hash consistency as ML-DSA.
- **Code.** `ml_dsa.sign(sk, msg, deterministic=True)` on an HSM/embedded path; `ctx` hard-coded on one side; `HashML-DSA` with SHA-256 for ML-DSA-87.
- **Confirm.** Cross-library verification tests with context strings; review threat model for faults.
- **Severity.** Medium.
- **Refs.** [E] FIPS 204 §3.4, §5.2 (hedged default), §5.4 (pre-hash); FIPS 205.

## P-07 Stateful hash-based signatures (LMS, XMSS, HSS/XMSS^MT): state management

- **Flaw.** Each one-time-signature (OTS) key index must be used **once**. Reuse (restore from backup, VM clone, replica fail-over, crash between signing and persisting the index, two processes sharing a key) allows forgery of signatures. This is a catastrophic, well-understood failure mode, which is why SP 800-208 restricts these schemes to hardware modules that do not export private keys and persist state before releasing a signature.
- **Code.** Key stored in a file/DB with the index updated *after* the signature is returned; keys exported for backup; multiple signing instances; no reservation/"advance-then-sign" logic; firmware signing pipelines using LMS (common in secure boot).
- **Confirm.** Simulate crash between sign and persist; check that restore-from-backup refuses to sign (or the design uses sub-tree reservation per instance). Review for any key export path.
- **Severity.** Critical.
- **Fix.** HSM-resident keys; reserve a batch of indices and persist *before* signing; one signer per key; prefer stateless SLH-DSA/ML-DSA unless signature size/perf forces stateful schemes.
- **Refs.** [E] SP 800-208; RFC 8554 (LMS/HSS); RFC 8391 (XMSS); NIST IR 8547 §2.1.1.

## P-08 Hybrid combiners (X25519MLKEM768, SecP256r1MLKEM768, composite signatures)

- **Flaw.** (1) Combining shared secrets with XOR or truncation instead of a KDF over the concatenation (ordering is defined: in X25519MLKEM768 the ML-KEM secret comes **first**, then X25519; in SecP256r1MLKEM768 the ECDH secret comes first — per the IETF TLS spec; libraries that swap the order don't interoperate and may lose the proof). (2) Validating only one component's public key (e.g., checking the X25519 output for zero but not the ML-KEM ek modulus check). (3) Silent fallback to classical-only when the peer doesn't support hybrid, without policy control or logging (downgrade). (4) Composite/dual signatures where verification succeeds if *either* component verifies (must be AND). (5) Using the same randomness for both components.
- **Code.** `shared = x25519_ss ^ mlkem_ss`; `secret = x25519_ss[:16] + mlkem_ss[:16]`; `if not peer_supports_hybrid: use x25519` with no audit log; `verify_composite = v1 or v2`; TLS group lists with hybrid absent or ordered after classical groups on a server that is supposed to require it.
- **Confirm.** Interop with OpenSSL ≥3.5 / BoringSSL / Go ≥1.24 (which implement X25519MLKEM768 per the final spec); unit test that each component failing causes overall failure; wire-capture to confirm the negotiated group (0x11EC).
- **Severity.** High.
- **Fix.** Follow the IETF TLS hybrid design (concatenate ML-KEM‖X25519 secrets into HKDF per TLS 1.3 schedule); SP 800-56C Rev.2 "Z‖T" hybrid KDF for non-TLS; SP 800-227 §4.6; IR 8547 §3.2 (all components must verify for signatures).
- **Refs.** [E] RFC 10024 (Aug 2026; X25519MLKEM768 0x11EC, SecP256r1MLKEM768 0x11EB, SecP384r1MLKEM1024 0x11ED); SP 800-56C Rev.2; SP 800-227; NIST IR 8547.

## P-09 FN-DSA (Falcon) pre-standard; floating-point Gaussian sampling

- **Flaw.** FIPS 206 was still "in development" at the last check. Falcon's signer uses floating-point Gaussian sampling that is hard to make constant-time and portable (FPU behaviour differs across platforms; emulated FP on MCUs leaks); known timing attacks on the sampler; implementations may diverge from the final FIPS 206 text. Verification is simple and fine; the risk is on the signing side.
- **Code.** `falcon-512`/`falcon-1024` signing on devices; pure-software FP emulation; "fn-dsa" libraries pre-dating FIPS 206.
- **Severity.** Medium (High for signing on exposed devices).
- **Fix.** Prefer ML-DSA for signing where size permits; if FN-DSA is required, use constant-time, well-reviewed implementations and plan a re-key when FIPS 206 is final.
- **Refs.** [E] NIST FIPS 206 (draft/in development — check status); [L] Karabulut & Aysu, "Falcon Down" (DAC 2021).

---

## Migration posture checklist (for the report's "PQC readiness" section when in scope)

- Cryptographic inventory exists (algorithms, key sizes, locations, owners, expiry) — IR 8547 and most regulators now expect one.
- Long-lived confidentiality data (harvest-now-decrypt-later) identified; TLS/VPN/messaging on hybrid KEM where available.
- Signatures: code signing, firmware, PKI — plan for ML-DSA/SLH-DSA; certificates and HSM support verified.
- Crypto-agility: algorithm identifiers are negotiable and not hard-coded; key sizes/formats not assumed (ML-KEM-768 ek is 1184 bytes; ML-DSA-65 signature is 3309 bytes — buffers, DB columns, MTU).
- Timeline: quantum-vulnerable public-key algorithms deprecated after 2030 and disallowed after 2035 under NIST IR 8547; BSI stops recommending classical-only key agreement from 2031 (the BSI date is marked verify in `standards-status.md`).
