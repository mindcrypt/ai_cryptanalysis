# Catalog — Configuration, protocols, key management, cross-cutting (C-01 … C-11, T-01, T-02)

Contents: C-01 certificate/hostname validation · C-02 JWT accepted unsigned · C-03 JWT algorithm confusion · C-04 weak/empty/defaulted HMAC secrets · C-05 `kid`/`jku`/`jwk`/format confusion · C-06 TLS versions and suites · C-07 keys in the repository · C-08 key storage, rotation, separation · C-09 ASN.1/PEM parsing · C-10 KEM-DEM / HPKE · C-11 public-key encryption mistaken for authentication · T-01 timing side channels visible in code · T-02 unchecked or discarded crypto errors (fail-open)

---

## C-01 Certificate validation or hostname verification disabled

- **Flaw.** Any TLS client that does not validate the chain *and* the hostname is MITM-able by anyone on the path. Georgiev et al. (2012) called this "the most dangerous code in the world" because it is everywhere: SDK wrappers, "fix for the self-signed dev cert" that shipped, mobile apps, IoT. Also: trusting all certs in a custom `TrustManager`, pinning disabled in release, accepting expired certs, ignoring revocation where policy requires it, trusting a system store on devices with user-installable CAs.
- **Code (vulnerable → fix).**
  - Python `requests.get(url, verify=False)`, `ssl._create_unverified_context()`, `ctx.check_hostname = False`, `ctx.verify_mode = ssl.CERT_NONE`, `urllib3.disable_warnings(InsecureRequestWarning)` (a tell) → defaults, `verify=ca_bundle`.
  - Java `X509TrustManager` with empty `checkServerTrusted`, `HostnameVerifier` returning `true`, `ALLOW_ALL_HOSTNAME_VERIFIER`, OkHttp `.hostnameVerifier((h, s) -> true)`, `sslSocketFactory` with trust-all → default trust, `CertificatePinner`. (`SSLContext.getInstance("SSL")` alone is not a trust-all: it is a protocol-family name, see C-06.)
  - Node `rejectUnauthorized: false`, `NODE_TLS_REJECT_UNAUTHORIZED=0`, `checkServerIdentity: () => undefined` → defaults.
  - Go `tls.Config{InsecureSkipVerify: true}` (also skips hostname) → `RootCAs`, `ServerName`; `VerifyPeerCertificate` custom funcs that return nil.
  - C/OpenSSL `SSL_CTX_set_verify(ctx, SSL_VERIFY_NONE, …)`, no `SSL_set1_host`/`X509_VERIFY_PARAM_set1_host`, ignoring `SSL_get_verify_result` → `SSL_VERIFY_PEER` + host check. libcurl `CURLOPT_SSL_VERIFYPEER 0`, `CURLOPT_SSL_VERIFYHOST 0`.
  - .NET `ServerCertificateCustomValidationCallback = (…) => true`, `ServicePointManager.ServerCertificateValidationCallback += … true` → remove.
  - Rust `danger_accept_invalid_certs(true)`, `danger_accept_invalid_hostnames(true)`, custom `ServerCertVerifier` → rustls defaults.
  - PHP `CURLOPT_SSL_VERIFYPEER => false`, `verify_peer => false` in stream contexts; Ruby `verify_mode = OpenSSL::SSL::VERIFY_NONE`.
  - Android: `network_security_config.xml` with `<trust-anchors><certificates src="user"/>` in release, `cleartextTrafficPermitted="true"`.
- **Trace.** Is the insecure setting reachable in production builds (feature flag, env var, debug-only)? Env-var overrides (`NODE_TLS_REJECT_UNAUTHORIZED`) are production bugs waiting to happen.
- **Confirm.** Connect the client to a test server with a self-signed cert / wrong hostname; it must fail. `x509-limbo` test suite for verifiers.
- **FP.** Explicit, documented internal CA pinning (verify the pin check is real); test-only code.
- **Severity.** Critical.
- **Refs.** [L] Georgiev et al. (CCS 2012); Fahl et al., "Why Eve and Mallory Love Android" (CCS 2012). CVE-2014-1266 (Apple "goto fail"), CVE-2014-0092 (GnuTLS). CWE-295, CWE-297, CWE-599.

## C-02 JWT accepted without a verified signature (`alg: none`, verification switched off)

- **Flaw.** The verifier accepts an unsigned token: the header says `alg: none` (also `None`, `nOnE`) and the library honours it, or the code calls a *decode* function that never verifies, or verification is disabled by an option. Full authentication bypass.
- **Code.** Verification switched off: PyJWT `options={"verify_signature": False}` / `verify=False`; `jsonwebtoken` (Node) `jwt.decode()` used where `jwt.verify()` is needed; jjwt `Jwts.parser().parse(token)` / `parseClaimsJwt` (accept unsecured JWTs) instead of `parseClaimsJws` / `parseSignedClaims`; auth0 `JWT.decode` without `JWTVerifier`; golang-jwt `ParseUnverified`, or a key function returning `jwt.UnsafeAllowNoneSignatureType`; .NET `RequireSignedTokens = false`; Rust `insecure_disable_signature_validation()`; ruby-jwt `JWT.decode(token, key, false)`. Library honours `none`: `jsonwebtoken` ≤ 8.5.1 when the secret/key argument is falsy and no `algorithms` are given (CVE-2022-23540); hand-written verifiers with `if alg == "none": return payload`; libraries configured with `none` in the allowed list.
- **Version facts (measured 2026-11; re-measure on the project's pin).** PyJWT 1.7.1 rejects an `alg: none` token in every form tried — `decode(tok)`, `decode(tok, None)`, `decode(tok, "")`, `decode(tok, None, algorithms=["none"])` all raise; only `verify=False` accepts it. Without `algorithms`, 1.7.1 does trust the *signing* algorithm named in the token, which is a confusion candidate (C-03), not an alg-none finding. PyJWT ≥ 2.0: `decode()` without `algorithms` raises `DecodeError`. Do not report "PyJWT accepts none" for any pin without a test on that version showing acceptance.
- **Trace.** What is passed as the key on every call path (can it be `None`, empty, or a default)? Is the result of a non-verifying decode used for an authorization decision, or only to pick a key (`kid`) before a real verify?
- **Confirm.** Against the project's verifier on its pinned library version: a token with `alg: none` (and casing variants) and an empty signature must be rejected (T17).
- **FP.** `jwt.get_unverified_header()` / `decode` used only to read `kid` or `alg` before calling a verifying function with a pinned algorithm.
- **Severity.** Critical when confirmed; High as `Probable`.
- **Fix.** Verifying API only, with exactly one allowed algorithm per key; upgrade the library; follow RFC 8725 / 8725bis.
- **Refs.** [E] RFC 8725 §3.1; draft-ietf-oauth-rfc8725bis. CVE-2022-23540 (jsonwebtoken). CWE-347, CWE-287.

## C-03 JWT algorithm confusion (RS256 → HS256) and algorithm taken from the token

- **Flaw.** The verifier lets the token choose the algorithm (no allow-list, or an allow-list mixing HMAC and asymmetric algorithms for one key). If the configured key is an RSA/EC *public* key, an attacker signs with HMAC using the public key bytes as the secret and the verifier accepts. Also `ES256`↔`HS256`, and key-type confusion in JWK handling (`kty` ignored).
- **Code.** `jwt.decode(token, public_key, algorithms=["RS256", "HS256"])` (two families, one key); PyJWT 1.x `jwt.decode(token, key)` with no `algorithms`; `jsonwebtoken` `verify(token, publicKey)` without `{algorithms}`; golang-jwt `jwt.Parse(token, keyFunc)` where `keyFunc` does not check `token.Method` and no `WithValidMethods` is given; `python-jose` without `algorithms`; custom `switch (header.alg)`; an `if header.alg == "HS256"` dispatch in front of two `decode()` calls that each still list both algorithms (the dispatch is then the only protection, and it disappears when someone deletes the legacy branch).
- **What decides exploitability.** The *form* of the key the HMAC code receives. Libraries added guards that refuse keys that look like PEM/SSH public keys as HMAC secrets (PyJWT from its 1.x line; bypasses for other key encodings were fixed later: CVE-2017-11424, CVE-2022-29217), and a key passed as a key *object* typically raises a type error instead of verifying. Raw DER bytes, JWK JSON, or a PEM with unusual framing may still get through on older versions. So: read how the key is loaded, then test on the pinned version; do not assert exploitability from the pattern alone.
- **Confirm.** Against the project's verifier and pinned library: an `HS256` token signed with the public key bytes (PEM as distributed, and DER) must be rejected (T17). Record which encodings were tried.
- **Severity.** Critical when the test is accepted; Medium as a latent hazard when the current code path or library version blocks it (state exactly what blocks it).
- **Fix.** "Each key MUST be used with exactly one algorithm" (8725bis): bind the algorithm to the key at configuration time, pass a one-element `algorithms` list on every call, never read it from the token.
- **Refs.** [E] RFC 8725 §3.1–3.2; 8725bis. CVE-2015-9235 (node-jsonwebtoken), CVE-2017-11424 and CVE-2022-29217 (PyJWT). CWE-347.

## C-04 Weak, empty or defaulted HMAC secrets for JWT / session signing

- **Flaw.** (a) Short or dictionary secrets (`"secret"`, `"changeme"`, a 10-character word) let an attacker crack the secret offline from one token and mint tokens; RFC 7518 requires ≥ 256-bit keys for HS256. (b) **Fail-open defaults**: the secret is read with a fallback — `os.environ.get("JWT_SECRET", "")`, `process.env.JWT_SECRET || "dev-secret"`, `getenv("KEY", "changeme")`, `config.get("secret", "")` — so a deployment that forgets the variable runs with an empty or publicly known key instead of failing to start. HMAC with an empty key is a valid HMAC; anyone can compute it.
- **Version facts (measured 2026-11; re-measure on the project's pin).** PyJWT 1.7.1 and 2.8.0 accept an HS256 token signed with an empty key when the verifier's secret is `""`; PyJWT 2.15.0 rejects it ("HMAC key must not be empty"). A project is safe here only if its *pinned* version refuses the key, and even then the code should not depend on that.
- **Code.** `JWT_SECRET = "secret"`; the fallback forms above; secrets from `.env.example` that ship; Rails `secret_key_base` in the repo; Django `SECRET_KEY` default; Express `cookie-session` `keys: ['key']`; Flask `app.secret_key = "dev"`.
- **Trace.** Where is the secret read, what happens when the variable is absent, and which deployments will lack it (new environments, partner services, CI, the day someone removes a "legacy" variable but not the code path)?
- **Confirm.** With the variable unset, an HS256 token signed with the fallback value (empty string or the literal default) must be rejected by the project's verifier on the pinned library (T17). For weak-but-set secrets: measure length/entropy; never try to crack production secrets without authorization.
- **Severity.** Critical when the fallback is reachable in any real deployment or the secret is a dictionary word; High as a latent misconfiguration when every deployment provably sets a strong value.
- **Fix.** No default: read with a call that fails at start-up when the variable is missing (`os.environ["JWT_SECRET"]`), enforce a minimum length (≥ 32 random bytes from a CSPRNG), store in a secret manager; prefer asymmetric algorithms (ES256/EdDSA) when more than one party verifies; rotate with `kid`.
- **Refs.** [E] RFC 7518 §3.2; RFC 8725 §3.5. CWE-326, CWE-798, CWE-1188 (insecure default initialization), CWE-636 (not failing securely).

## C-05 `kid`, `jku`, `x5u`, `jwk` headers; serialization/format confusion; missing claims

- **Flaw.** `kid` used unsanitized in a file path / SQL / LDAP lookup (injection, or pointing to a predictable file such as `/dev/null` as a key); `jku`/`x5u` fetched without an allow-list (SSRF, attacker-hosted keys); embedded `jwk` header trusted as the verification key (self-signed token); JWE accepted where a JWS is expected (and vice versa); JWS JSON serialization with multiple signatures where one valid signature suffices; `typ`/`cty` ignored enabling cross-purpose token replay (an ID token used as an access token); missing `exp`/`nbf`/`aud`/`iss` checks; clock skew too large; refresh/ID/access token confusion.
- **Code.** `key = load(f"keys/{header['kid']}.pem")`; `requests.get(header['jku'])`; `jwk = header['jwk']; verify(token, jwk)`; `verify(token, key)` without `audience=`/`issuer=`; `exp` optional.
- **Confirm.** Tokens with `kid: "../../etc/passwd"`, with a `jwk` header and matching self-signature, without `exp`, with wrong `aud` ⇒ all must be rejected. `scripts/jwt_inspect.py` flags these headers in sample tokens.
- **Severity.** Critical (jwk/jku trust, kid injection); High (missing aud/exp).
- **Fix.** Resolve keys only from a configured key set by `kid` with strict matching; never fetch keys from URLs in the token unless on an allow-list and over TLS with pinning; validate all standard claims; check `typ` ("at+jwt" for access tokens, RFC 9068).
- **Refs.** [E] RFC 8725 §3.10–3.12, RFC 9068; 8725bis. CWE-347, CWE-918, CWE-22.

## C-06 TLS versions and cipher suites

- **Flaw.** SSLv3/TLS 1.0/1.1 enabled (RFC 8996 deprecates 1.0/1.1); suites without forward secrecy (`TLS_RSA_*`), CBC suites (Lucky13 surface), 3DES/RC4/EXPORT/NULL/anon; DH < 2048; compression (CRIME); renegotiation insecure; session ticket keys never rotated (forward-secrecy loss); OCSP stapling absent where required; weak signature algorithms (SHA-1 certs); missing hybrid PQ group where policy requires.
- **Code / config.** nginx `ssl_protocols TLSv1 TLSv1.1 …`, `ssl_ciphers` with `3DES`/`RC4`/`!…` lists that re-enable weak suites; Apache `SSLProtocol all`, `SSLCipherSuite`; HAProxy `ssl-default-bind-options`; Java `jdk.tls.disabledAlgorithms` edits; Go `tls.Config{MinVersion: tls.VersionTLS10, CipherSuites: […RC4…]}`; Node `secureProtocol: 'TLSv1_method'`, `ciphers`; OpenSSL `SSL_CTX_set_min_proto_version`, `SSL_OP_NO_TLSv1_2`; Python `ssl.PROTOCOL_TLSv1`, `ctx.set_ciphers('ALL')`; Kubernetes/ingress annotations; AWS ELB policies (`ELBSecurityPolicy-2016-08` allows TLS 1.0), CloudFront `TLSv1`; Postgres `ssl_min_protocol_version`.
- **What the configuration really enables depends on the TLS library build.** A cipher string or protocol list is a *request*; the linked OpenSSL decides. Measured on OpenSSL 3.0.13: the keywords `RC4` and `3DES` in a cipher string match no suite at all, and TLS 1.0/1.1 are refused at the default security level even when the server lists them. The same nginx line on an older or differently built OpenSSL does enable them. Report the configuration as the finding, and state which build (if any) you checked it against.
- **Confirm.** Static expansion: `openssl ciphers -v '<cipher string>'` shows exactly which suites the string selects on that build. Live: `testssl.sh` / `sslyze` when available, otherwise a loopback `openssl s_server` + `openssl s_client -tls1` / `-tls1_1` / `-cipher …` handshake (recipe T18).
- **Severity.** Medium–High (High when TLS 1.0 or `TLS_RSA_*` is actually negotiable on the deployed build with long-lived keys; Medium when the configuration asks for it but the checked build refuses, because the next base-image change can re-enable it).
- **Fix.** TLS 1.3 preferred, TLS 1.2 with AEAD + ECDHE only; `X25519MLKEM768` enabled where supported; rotate ticket keys; SHA-256 certs. Standards: NIST SP 800-52 Rev.2; BSI TR-02102-2; Mozilla "modern/intermediate".
- **Refs.** [E] RFC 8446, RFC 8996, SP 800-52 Rev.2, BSI TR-02102-2. CWE-327, CWE-757.

## C-07 Keys, secrets and certificates in the repository

- **Flaw.** Private keys, API secrets, JWT secrets, KMS credentials committed (including in history, in `.env`, in test fixtures that are also used in prod, in Docker images, in CI logs). A committed key is compromised regardless of later removal.
- **Code / artefacts.** `-----BEGIN (RSA |EC |OPENSSH |PGP )?PRIVATE KEY-----`, `.pem`/`.p12`/`.pfx`/`.jks`/`.keystore` files, `AKIA[0-9A-Z]{16}`, `xox[bp]-`, `ghp_`, `sk_live_`, hard-coded `SECRET_KEY`/`JWT_SECRET`/`ENCRYPTION_KEY`, base64 blobs assigned to `key` variables, `keystore password` literals, `"password"` next to `ssl`.
- **Confirm.** Run `gitleaks`/`trufflehog` over history (`git log -p`), not just HEAD; the inventory script flags PEM headers and obvious tokens. Verify whether a key is live (ask the client; do not use it).
- **FP.** Public keys/certs (fine), clearly-labelled test keys that are only used in tests (still recommend separation), example files with placeholders.
- **Severity.** Critical (live key); High (unknown status).
- **Fix.** Rotate immediately; move to a secret manager/KMS; purge history (`git filter-repo`) *after* rotation; pre-commit secret scanning.
- **Refs.** CWE-321, CWE-798, CWE-312.

## C-08 Key storage, rotation, purpose separation, lifecycle

- **Flaw.** Keys at rest in plaintext files/DB columns; KEK and DEK stored together; no cryptoperiod/rotation; no versioning (`kid`) so rotation is impossible without downtime; same key for multiple purposes/environments (dev = prod); keys in logs/exceptions/crash dumps; KMS policies allowing `Decrypt` broadly; key material in client-side code (mobile/JS) protecting server-side secrets; backups with keys in the same bucket as data.
- **Trace.** Key lifecycle map: generation → storage → distribution → use → rotation → destruction. Who/what can read the key? What is logged?
- **Confirm.** Grep logs/log statements for key variables; review KMS IAM; check for `kid`/version fields in ciphertext headers.
- **Severity.** Medium–High (High when KEK/DEK co-located or keys logged).
- **Fix.** Envelope encryption with KMS/HSM; versioned keys; rotation schedule (SP 800-57 cryptoperiods); separate keys per purpose and environment; never log key material.
- **Refs.** [E] SP 800-57 Pt.1 Rev.5; SP 800-130; [P] OWASP ASVS V6/V8, Key Management Cheat Sheet. CWE-320, CWE-312, CWE-532.

## C-09 ASN.1 / DER / PEM / X.509 parsing

- **Flaw.** Hand-written parsers; accepting BER where DER is required (non-canonical encodings enable signature malleability and parser differentials); trailing bytes ignored; integer overflows in length handling; `x509` parsing of certificate extensions (name constraints, basic constraints, key usage, EKU) ignored by custom verifiers; `CN` used instead of `subjectAltName`; wildcard mis-handling; null-byte names.
- **Code.** Custom `parse_der`, `asn1` regexes; `OpenSSL::X509` usage without `verify`; Go `x509.ParseCertificate` then custom chain logic ignoring `Verify`; Python `pyasn1` ad-hoc decoders; `cryptography.x509.load_pem_x509_certificate` followed by home-grown validation.
- **Confirm.** `x509-limbo` suite; Wycheproof signature-encoding cases; fuzzing (go-fuzz/libFuzzer) for custom parsers.
- **Severity.** High.
- **Fix.** Use the platform verifier (`ssl` module, `SecTrust`, `CertPathValidator`, Go `x509.Verify`, rustls-webpki); never hand-roll chain validation.
- **Refs.** [E] ITU-T X.690; RFC 5280; RFC 7468; RFC 6125 (hostname matching). CVE-2022-0778 (OpenSSL BN_mod_sqrt infinite loop on malformed certs). CWE-295, CWE-20.

## C-10 KEM-DEM composition and HPKE usage

(Whether the sender is authenticated at all is C-11; this entry is about using the KEM/DEM pieces correctly.)

- **Flaw.** Hand-rolled "RSA-encrypt-the-AES-key" schemes that use PKCS#1 v1.5 (A-04), don't bind the KEM output to the DEM (no KDF with context), reuse the DEM nonce/sequence, or lack authentication of the sender when required. HPKE misuse: empty `info`, ignoring `psk_id`/`info` for domain separation, exceeding the per-context sequence number, using Base mode where Auth/AuthPSK is needed, assuming HPKE commits to the key, exporter secrets misused as keys without labels.
- **Code.** `rsa_encrypt(aes_key)` + `AES-CBC` without MAC; HPKE `seal` in a loop with a fresh context per message but the same `info` and no sender auth; sequence overflow unchecked in long-lived contexts.
- **Confirm.** RFC 9180 test vectors; interop with a second HPKE implementation; unit tests for the seq-overflow error.
- **Severity.** Medium–High.
- **Fix.** Use HPKE (RFC 9180) or libsodium `sealed_box`; ML-KEM-based HPKE (hybrid) per the IETF drafts when PQ is in scope; SP 800-227 for KEM usage rules.
- **Refs.** [E] RFC 9180; SP 800-227; SP 800-56C Rev.2.

---

## C-11 Public-key (hybrid) encryption mistaken for authentication: anyone can produce a valid message

- **Flaw.** Encrypting to a recipient's public key proves nothing about who encrypted. A design that wraps a fresh data key under the recipient's public key and then "authenticates" the payload with a MAC or AEAD tag keyed by that same fresh key has integrity only against accidental damage: the MAC key was chosen by whoever built the message, so anyone who holds the public key can build a complete, internally valid message — ciphertext, tag and wrapped key — and the recipient's checks all pass. The same holds for sealed boxes, plain HPKE Base mode, "RSA-wrap + AES-GCM" envelopes, and backup/update/config blobs encrypted "to the device key". The consequence is substitution: a forged backup that restores cleanly, a forged update or configuration that decrypts and verifies.
- **Why audits miss it.** Every primitive is used correctly and the MAC "verifies". No pattern rule fires, because the defect is who holds the key, not how it is used. It appears only when asking the design question: *who is able to create something the receiver accepts?*
- **Code / design.** A random key generated by the sender, wrapped with `pub.encrypt(...)` / `crypto_box_seal` / HPKE Base, and used for both encryption and the integrity tag; no signature by the sender and no pre-shared key anywhere in the format; documents that say "integrity is provided by an HMAC" in a public-key scheme; recipients' public keys fetched from a directory (then also ask how *those* are authenticated — an unauthenticated directory lets an attacker substitute the recipient).
- **Trace.** List every key in the format and who knows it at creation time. If everything needed to produce a valid message is public or chosen by the sender, the format is unauthenticated, whatever MACs it contains.
- **Confirm.** A property test with outsider knowledge only: using nothing but the recipient's public key and the project's own encrypt function (or a fresh key pair of the tester's own for the sender side), produce a message; the receiver accepts it. That shows the property; it needs no attack code. State what an attacker additionally needs in practice (write access to where the messages are stored or transported).
- **FP.** Formats where origin does not matter by design (anonymous submission boxes); messages that travel inside an authenticated channel *and* are never stored; a sender signature or a pre-shared key that covers the whole message (check it covers the wrapped keys and headers too).
- **Severity.** High when the receiver acts on the content (restores it, installs it, trusts it); Critical for code or firmware updates and for anything that grants access; Medium when substitution only causes loss of the original data.
- **Fix.** Sign the whole message with a sender key the receiver already trusts (sign-then-encrypt with the recipient identity inside the signed data, or encrypt-then-sign with the signer identity bound to the ciphertext); or use an authenticated mode (HPKE Auth / AuthPSK, `crypto_box` instead of `crypto_box_seal`); or mix a pre-shared secret into the key derivation. Authenticate the public-key directory.
- **Refs.** [E] RFC 9180 §5.1 (the four modes: Base has no sender authentication; Auth and PSK modes add it) and §9.1 (security properties); NIST SP 800-56A/B (key confirmation and entity authentication are separate from key transport). [L] Davis, "Defective Sign & Encrypt in S/MIME, PKCS#7, MOAC, PGP, and XML" (USENIX ATC 2001). CWE-345 (insufficient verification of data authenticity), CWE-306.

## T-01 Timing side channels visible in application code

- **Flaw.** Secret-dependent control flow or memory access in code the auditor can read: early-exit comparisons (S-18), `if (token == expected)`, password-hash comparison with string `==`, user-existence timing (hash computed only if the user exists), `BigInteger` operations on secrets (Java/Python not constant-time), table lookups indexed by key bytes (custom AES/S-box), variable-time padding checks (S-22), different code paths for "user not found" vs "wrong password", rate-limit checks that short-circuit on valid tokens.
- **Code.** Look for: `==`, `equals`, `memcmp`, `strcmp` on secrets; `if secret[i]`, `switch (key[i])`; `return` inside loops over secret data; `BigInteger.modPow` in signing; `if user is None: return error` before `verify_password` (missing dummy hash).
- **Confirm.** `scripts/timing_check.py` (Welch t-test, dudect-style) over two input classes; for compiled code, `ctgrind`/TIMECOP (valgrind with secret marking) or `SILENT`.
- **FP.** Comparisons of public values; length checks before constant-time compare; code behind strong rate limiting *and* no co-tenancy (note it as Low rather than closing).
- **Severity.** Medium (High when the oracle is remotely reachable with many attempts or recovers key material).
- **Fix.** Constant-time primitives (S-18 list), dummy work on the failure path (compute a hash even when the user doesn't exist), constant-time libraries for big-number work.
- **Refs.** [L] Kocher (1996); Reparaz et al. (2017); Bernstein et al. (2025). CWE-208, CWE-385, CWE-203.

## T-02 Unchecked or discarded errors from cryptographic calls (fail-open)

- **Flaw.** A cryptographic operation fails and the program carries on as if it had succeeded. The failure modes differ by language, and each turns a "merely wrong parameter" into something worse:
  - *Verification treated as success.* `if (EVP_VerifyFinal(...))` is true for the error return `-1`, so a malformed signature verifies (A-06). The same shape appears with `X509_verify_cert`, `SSL_get_verify_result` never read, and any API that returns `1 / 0 / -1`.
  - *Randomness not produced.* `RAND_bytes` returning 0 with the buffer left as it was; Go `rand.Read` error ignored; a short read from `/dev/urandom` (S-14).
  - *Tag check ignored.* `EVP_DecryptFinal_ex` return not checked; a `try/except` around `decrypt()` that logs and then uses partial output (S-19).
  - *Constructor failed, object unusable or silently different.* Go `gcm, _ := cipher.NewGCMWithTagSize(block, 8)` returns an error for sizes outside 12–16, `gcm` is nil and the first `Seal` panics (denial of service; measured on Go 1.24); `block, _ := aes.NewCipher(key)` with a key of the wrong length; a Java `catch (GeneralSecurityException e) { return data; }` that returns the *plaintext* when encryption fails.
  - *Fallback to weaker behaviour.* `except Exception: return fallback_decrypt(...)`, `catch { useLegacyCipher() }`, a verifier that returns `True` when the key file is missing.
- **Code.** Go: `_` in the error position of `aes.NewCipher`, `cipher.NewGCM*`, `rand.Read`, `x509.Parse*`, `rsa.*`, `hkdf` readers. C/C++: return values of `EVP_*`, `RAND_bytes`, `SSL_*`, `X509_*` not compared (`== 1`). Java/Kotlin/C#: empty `catch` blocks or catches that return input/`true`/`null` around `Cipher`, `Signature.verify`, `Mac`. Python/JS/Ruby: bare `except`/`catch` around `decrypt`/`verify` that continues; `verify()` results not used.
- **Trace.** For every crypto call that can fail: what value flows onward on failure, and does the caller distinguish it from success?
- **Confirm.** Drive the failure (malformed signature, wrong-length key, invalid tag size, missing key file) through the project's function and observe the result: accepted, plaintext returned, panic, or a clean error. Running the function is the test; `scripts/` are not needed.
- **FP.** Errors propagated by the language's normal mechanism and handled by a caller that fails closed; `_` on calls that cannot fail for the given constant arguments (state why).
- **Severity.** Critical when a verification failure is accepted or plaintext is emitted in place of ciphertext; High for missing randomness; Medium for crashes (availability) and for fallbacks to weaker modes — higher when the fallback path is itself exploitable (S-27).
- **Fix.** Compare against the documented success value (`== 1`); never discard the error return; fail closed; no fallback to weaker algorithms on error.
- **Refs.** CWE-252 (unchecked return value), CWE-253, CWE-390, CWE-636 (not failing securely), CWE-755. OpenSSL manual pages for `EVP_VerifyFinal` / `EVP_DigestVerifyFinal` (return 1, 0 or negative).
