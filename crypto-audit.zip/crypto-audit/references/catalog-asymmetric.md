# Catalog — Asymmetric cryptography (A-01 … A-26)

Same format as the symmetric catalog. Basis tags: [E] standard, [L] literature, [P] practice.

Contents: **RSA** A-01 key size · A-02 textbook · A-03 small e · A-04 PKCS#1 v1.5 decryption (Bleichenbacher/ROBOT/Marvin) · A-05 Manger/OAEP · A-06 lax PKCS#1 v1.5 signature verification · A-07 PSS params · A-08 weak keygen (common modulus, shared primes, ROCA) · A-09 small d · A-10 CRT fault · A-11 no blinding · A-12 same key sign+encrypt — **ElGamal** A-13 — **DH** A-14 weak params/Logjam · A-15 small subgroup/validation · A-16 ephemeral reuse/Raccoon · A-17 unauthenticated / no KDF — **ECC** A-18 invalid curve/twist · A-19 ECDSA nonce reuse/bias · A-20 malleability · A-21 r=s=0 · A-22 explicit curve params · A-23 Ed25519 pitfalls · A-24 X25519 all-zero · A-25 curve choice · A-26 variable-time scalar mult

General rule for this catalog: **asymmetric code must validate every input it did not generate** (public keys, points, ciphertexts, signature components, parameters). Most entries below are a missing validation.

---

## RSA

### A-01 RSA key too small
- **Flaw.** < 2048 bits is below NIST's floor; 2048 is accepted by NIST through 2030 but below BSI's 3000-bit recommendation; 1024-bit factoring is within reach of well-funded actors.
- **Code.** `KeyPairGenerator.initialize(1024)`, `rsa.generate_private_key(public_exponent=65537, key_size=1024)`, `openssl genrsa 1024`, `RSA.Create(1024)`, `rsa.GenerateKey(rand.Reader, 1024)`. Also keys *accepted* from peers/certs without a minimum-size check.
- **Confirm.** `scripts/key_analyzer.py` over all PEM/DER/JWK in the repo and from live endpoints.
- **Severity.** High (<2048), Low–Medium (2048, note the BSI gap and PQC timeline in `standards-status.md`).
- **Fix.** ≥3072 (BSI: ≥3000) for new keys; migration plan per NIST IR 8547.
- **Refs.** [E] SP 800-131A Rev.2; SP 800-57 Pt.1; BSI TR-02102-1; NIST IR 8547. CWE-326.

### A-02 Textbook RSA (no padding)
- **Flaw.** Deterministic, multiplicatively homomorphic (`Enc(a)·Enc(b)=Enc(ab)`), small messages recoverable by e-th root; signatures forgeable by multiplying.
- **Code.** `RSA/ECB/NoPadding`, `RSA_NO_PADDING`, `padding.OAEP` absent (`rsa.encrypt(...)` in PyCA *requires* padding — but `pow(m, e, n)` in handwritten code does not), `RSA_public_encrypt(..., RSA_NO_PADDING)`, JS `node-forge` `publicKey.encrypt(m, 'RAW')`, .NET `RSAEncryptionPadding` absent with `rsa.Encrypt(data, false)` (false = PKCS#1 v1.5, not raw — but note it).
- **Severity.** High.
- **Fix.** OAEP(SHA-256) for encryption (or better, hybrid/KEM), PSS for signatures.
- **Refs.** [E] RFC 8017. CWE-780.

### A-03 Small public exponent (e = 3) with structure
- **Flaw.** With e=3 and unpadded/poorly padded messages: Håstad broadcast (same m to ≥3 recipients), Coppersmith on partially known plaintext, and the A-06 signature forgery is practical. e=3 with proper OAEP/PSS is not broken but removes margin.
- **Code.** `public_exponent=3`, `RSAKeyGenParameterSpec(2048, BigInteger.valueOf(3))`, `-3` in `openssl genrsa`.
- **Severity.** Medium.
- **Fix.** e = 65537 (FIPS 186-5: 2^16 < e < 2^256, odd).
- **Refs.** [L] Håstad (1988); Coppersmith (1996). [E] FIPS 186-5 App. A.1.

### A-04 PKCS#1 v1.5 decryption oracle (Bleichenbacher, ROBOT, Marvin)
- **Flaw.** If the decryptor's behaviour differs in *any* observable way between "padding OK" and "padding bad" (error type, message, TLS alert, timing — including timing inside big-number arithmetic and the padding-check code path), an attacker decrypts any ciphertext (or forges a signature under the same key) with on the order of 10^4–10^6 oracle queries. Marvin (2023) showed that many implementations that "fixed" Bleichenbacher still leak via timing; it affected OpenSSL, GnuTLS, Node.js, Bouncy Castle, python-cryptography, Java's JCE, libgcrypt, the Rust `rsa` crate, among others.
- **Code.** `Cipher.getInstance("RSA/ECB/PKCS1Padding")` on the decrypt side; PyCA `padding.PKCS1v15()` in `private_key.decrypt` (measured: `cryptography` 41.0.7, bundling OpenSSL 3.1, raises on bad padding; 42.0.8, bundling OpenSSL 3.2, and later return a pseudo-random plaintext. PyCA wheels carry their own OpenSSL, so the system `openssl version` says nothing about a Python service); Node `crypto.privateDecrypt({padding: RSA_PKCS1_PADDING})` (CVE-2023-46809; Node ≥ 20.11/21.6 require opt-in `--security-revert`); .NET `RSAEncryptionPadding.Pkcs1`; JWE `alg: RSA1_5` (RFC 8725 recommends against); TLS `TLS_RSA_*` key exchange (static RSA, Bleichenbacher surface in every CBC/AEAD suite with RSA kex); Rust `rsa` crate (RUSTSEC-2023-0071, timing). SAML/XML-Enc `rsa-1_5`.
- **Trace.** Who can submit ciphertexts? What happens on padding failure vs. success (exceptions, logs, fallback random secret — "implicit rejection" is the right behaviour, but it must be constant-time)?
- **Confirm (no exploit).** Timing: submit well-formed vs malformed ciphertexts many times and compare distributions (Marvin's `tlsfuzzer` test scripts for TLS; for APIs, `timing_check.py` pattern). Error-channel: compare responses. Version check for known-vulnerable library versions.
- **Implicit rejection changes what you will observe.** OpenSSL 3.2+ and distributions that backported the change (measured: Ubuntu's OpenSSL 3.0.13 package; `-pkeyopt rsa_pkcs1_implicit_rejection:0` restores the error) no longer fail on bad PKCS#1 v1.5 padding: decryption returns a deterministic, pseudo-random plaintext of plausible length. Three consequences for an audit. (1) An error-comparison test passes on such a build although the code still uses v1.5 — the absence of an error proves nothing. (2) The library-level oracle is closed there. A caller that then rejects the plaintext for its length or format does not by itself reopen it, because a rejected ciphertext also produces a plaintext of pseudo-random length and content, so both cases fail the caller's check alike. What reopens it is anything that still separates "real plaintext" from "synthetic plaintext": a deployment on a library without implicit rejection, a hardware token or HSM that returns a padding error, or a non-constant-time implementation. Trace what the code does with the decrypted bytes, and measure before claiming a distinguishable outcome. (3) The same code on an older or different library (OpenSSL < 3.2 without backport, other languages' RSA) is exposed again, so the finding stays, with severity set by the builds actually deployed: High where no implicit rejection exists or the caller distinguishes outcomes, Medium where it is library-protected today.
- **FP.** Encryption side only (public key) — no oracle on the encryptor. A library with constant-time implicit rejection *and* a caller that treats every result alike is a reduced-severity finding, not a false positive (still recommend OAEP or a KEM).
- **Severity.** High (Critical when the key also protects recorded TLS traffic or signs tokens).
- **Fix.** OAEP or a KEM (ML-KEM/ECDH-based hybrid). Disable `TLS_RSA_*`. Interim, when v1.5 cannot be removed yet: never branch on the unwrap result — on any failure continue with a random key of the expected length so that the later integrity check fails the same way (the TLS countermeasure), and pin a library version with implicit rejection. If v1.5 must remain: implicit rejection per RFC-draft/Marvin guidance in a constant-time library.
- **Refs.** [E] RFC 8017 §7.2 (notes on v1.5); SP 800-131A. [L] Bleichenbacher (CRYPTO 1998); Böck, Somorovsky, Young, "Return Of Bleichenbacher's Oracle Threat (ROBOT)" (USENIX Security 2018); Kario, "Everlasting ROBOT: the Marvin Attack" (IACR ePrint 2023/1442). CVEs: CVE-2022-4304 (OpenSSL), CVE-2023-0361 (GnuTLS), CVE-2023-49092 (Rust rsa), CVE-2024-30171 (Bouncy Castle), CVE-2023-46809 (Node.js), CVE-2024-2236 (libgcrypt), CVE-2020-25659 (python-cryptography), CVE-2024-20952 (Java). CWE-780, CWE-208.

### A-05 Manger's attack on OAEP
- **Flaw.** If the decryptor reveals whether the integer-to-octets conversion found a leading zero (first byte check) separately from the hash/padding check, a 1-bit oracle decrypts in ~log2(n) queries. Usually a timing/exception-ordering issue in OAEP implementations.
- **Code.** Hand-rolled OAEP; old library versions; CVE-2022-4304's fix also covers OAEP in OpenSSL.
- **Confirm.** Wycheproof `rsa_oaep_*` vectors; timing comparison.
- **Severity.** High if the oracle exists.
- **Refs.** [L] Manger (CRYPTO 2001). CWE-208.

### A-06 Lax PKCS#1 v1.5 signature verification (Bleichenbacher 2006, BERserk)
- **Flaw.** Verifier parses `00 01 FF…FF 00 DigestInfo` loosely (doesn't check that the padding fills the block, accepts extra bytes after the hash, tolerates BER length tricks) ⇒ with e=3 an attacker crafts a "signature" that cubes to a block the lax parser accepts. Forgery of any certificate/signature.
- **Code.** `RSA_public_decrypt()` followed by `endswith(hash)` / `memcmp` on a suffix / ASN.1 parsing of the decoded block; custom JWT/SAML verifiers; embedded TLS stacks.
- **Confirm.** Wycheproof `rsa_signature_*` (contains the malformed-padding cases); re-encode the expected EM and compare the *entire* block (RFC 8017 §8.2.2 method).
- **Severity.** Critical.
- **Fix.** Compare the full encoded message; use a maintained library (`Signature.verify`, `public_key.verify`, `rsa.VerifyPKCS1v15`).
- **Refs.** [L] Bleichenbacher (2006, CRYPTO rump session, reported by Finney); Intel ATR "BERserk" (2014). CVE-2006-4339 (OpenSSL), CVE-2014-1568 (NSS). CWE-347.

### A-07 RSA-PSS parameters
- **Flaw.** Verifier accepts whatever salt length / MGF hash the signature announces (algorithm-agility confusion), salt length 0 (deterministic PSS — allowed but loses a property), hash mismatch between MGF1 and message hash.
- **Code.** `PSSParameterSpec` built from attacker-controlled parameters; `salt_length=0`; JOSE `PS256` implemented with wrong MGF.
- **Confirm.** Wycheproof `rsa_pss_*`.
- **Severity.** Low–Medium.
- **Refs.** [E] RFC 8017 §9.1; FIPS 186-5 §5.4 (salt length).

### A-08 Weak key generation: common modulus, shared primes, ROCA
- **Flaw.** Same n with different e for different users ⇒ anyone with one d can factor n. Shared primes across keys (bad entropy at generation) ⇒ batch GCD factors them. ROCA (Infineon RSALib) ⇒ fingerprintable, factorable keys (2048-bit in ~CPU-years, 1024-bit in hours).
- **Code / artefacts.** Key generation on embedded devices at first boot; smart cards/TPMs/YubiKey 4 era; certificates in the repo; "key pool" designs.
- **Confirm.** `scripts/key_analyzer.py --gcd` across all collected moduli; `--roca` fingerprint; cross-check moduli equality.
- **Severity.** Critical.
- **Fix.** Regenerate on a good CSPRNG; firmware update; revoke.
- **Refs.** [L] Lenstra et al., "Ron was wrong, Whit is right" (2012); Heninger et al. (2012); Nemec et al., "ROCA" (CCS 2017). CVE-2017-15361. CWE-331, CWE-338.

### A-09 Small private exponent (Wiener, Boneh–Durfee)
- **Flaw.** d < N^0.25 (Wiener) or < N^0.292 (Boneh–Durfee) ⇒ d recovered from (n, e). Arises from "choose small d for fast decryption" designs.
- **Confirm.** `scripts/key_analyzer.py` runs the continued-fraction sanity check on (n, e); a positive result means the key is broken.
- **Severity.** Critical.
- **Refs.** [E] FIPS 186-5 (d > 2^(nlen/2)). [L] Wiener (1990); Boneh & Durfee (1999).

### A-10 CRT fault attack (Bellcore)
- **Flaw.** One faulty CRT signature (s' wrong mod one prime) ⇒ gcd(s'^e − m, n) reveals a prime. Relevant where faults can be induced (embedded, HSM firmware, DRAM errors) and signatures are released unverified.
- **Code.** CRT signing without verifying `s^e mod n == m` before output (`RSA_FLAG_NO_BLINDING`-style shortcuts, custom bignum code).
- **Severity.** High (embedded/physical), Low (cloud).
- **Fix.** Verify the signature before releasing it; infective countermeasures.
- **Refs.** [L] Boneh, DeMillo, Lipton (EUROCRYPT 1997).

### A-11 RSA without blinding
- **Flaw.** Modular exponentiation time depends on the ciphertext ⇒ remote key recovery (Brumley–Boneh).
- **Code.** `RSA_blinding_off()`, `RSA_FLAG_NO_BLINDING`, custom bignum.
- **Severity.** High if remotely reachable.
- **Refs.** [L] Brumley & Boneh (USENIX Security 2003). CWE-208.

### A-12 Same RSA key for signing and encryption
- **Flaw.** A decryption oracle becomes a signing oracle (and vice versa) — the A-04/A-06 attack surfaces compound; also complicates key lifecycle.
- **Severity.** Medium.
- **Fix.** Separate keys per purpose (SP 800-57 Pt.1 §5.2).

---

## ElGamal

### A-13 ElGamal encryption/signature pitfalls
- **Flaw.** Signature: reusing the ephemeral k ⇒ private key recovery (same algebra as A-19). Encryption: in a group whose order is not prime (e.g., Z_p* with p−1 having small factors), the ciphertext leaks the Legendre symbol of the message (one bit — enough to distinguish); messages must be encoded into the prime-order subgroup. Encryption is multiplicatively malleable (needs authentication). Also "textbook" message encoding.
- **Code.** Legacy PGP/GnuPG-like code, custom implementations, Bouncy Castle `ElGamal` with `DHParameters` of unknown provenance, libraries that pick `p` without a prime-order subgroup.
- **Severity.** High (k reuse), Medium (others).
- **Fix.** Use HPKE/ECIES or an authenticated hybrid scheme.
- **Refs.** [L] Boneh, Joux, Nguyen, "Why Textbook ElGamal and RSA Encryption Are Insecure" (ASIACRYPT 2000).

---

## Diffie–Hellman (finite field)

### A-14 Weak DH parameters (Logjam, small primes, non-safe primes)
- **Flaw.** 512-bit (export) and 1024-bit groups are within reach of precomputation (Logjam); custom primes without a large prime-order subgroup; `DHE_EXPORT` downgrade.
- **Code.** `DHParameterSpec` with 1024-bit p; `openssl dhparam 1024`; Apache `SSLOpenSSLConfCmd DHParameters` small; Java `jdk.tls.ephemeralDHKeySize` < 2048; Go `dh` in custom protocols; non-RFC 7919 groups.
- **Confirm.** Scan with `testssl.sh` (reports DH size/known groups); parse params in config.
- **Severity.** High.
- **Fix.** RFC 7919 `ffdhe2048`+ (BSI ≥3000 bits) or ECDHE; prefer hybrid X25519MLKEM768 in TLS 1.3.
- **Refs.** [E] RFC 7919; SP 800-56A Rev.3. [L] Adrian et al., "Imperfect Forward Secrecy" (CCS 2015). CVE-2015-4000. CWE-326.

### A-15 Small-subgroup attack / missing public-key validation (DH)
- **Flaw.** Accepting peer values Y ∈ {0, 1, p−1} or values in a small subgroup leaks bits of the static private key per handshake (and can force a known shared secret). Needs: static private key and no validation.
- **Code.** `DH_compute_key()` without `DH_check_pub_key()`; Java `KeyAgreement.doPhase` with a `DHPublicKey` built from raw bytes without checks (JDK validates for named groups; verify provider); Go `big.Int.Exp(peer, priv, p)` without range/order checks; custom.
- **Confirm.** Wycheproof `dh_*` vectors; unit test with Y = 1 and Y = p−1 ⇒ must be rejected.
- **Severity.** High with static keys; Low with ephemeral + safe prime.
- **Fix.** Check 2 ≤ Y ≤ p−2 and Y^q ≡ 1 (mod p) (or use safe primes + cofactor check); SP 800-56A §5.6.2.3.
- **Refs.** [E] SP 800-56A Rev.3 §5.6.2.3. [L] Lim & Lee (CRYPTO 1997). CVE-2016-0701 (OpenSSL). CWE-20.

### A-16 Ephemeral key reuse; Raccoon
- **Flaw.** Reusing (EC)DHE keys across sessions removes forward secrecy and enables Raccoon (timing on the leading-zero handling of the premaster secret in TLS ≤1.2) and A-15 surfaces.
- **Code.** Cached `KeyPair` for "performance"; OpenSSL `SSL_OP_SINGLE_DH_USE` missing (pre-1.1.0); server configs reusing DH keys.
- **Severity.** Medium (High for TLS 1.2 DHE with reuse).
- **Fix.** Fresh key per handshake (SP 800-227 for KEMs); TLS 1.3.
- **Refs.** [L] Merget et al., "Raccoon Attack" (USENIX Security 2021). CVE-2020-1968. CWE-323.

### A-17 Unauthenticated DH / shared secret used raw
- **Flaw.** DH without authentication is MITM-able (nothing binds the exchange to identities). Using Z directly as a key (or `Z[:32]`) skips KDF: Z is not uniform, and no transcript binding.
- **Code.** `key = shared_secret[:16]`; `aes.NewCipher(shared.Bytes())`; no signature/MAC over the transcript; custom "secure channel" code.
- **Severity.** High (unauthenticated), Medium (no KDF).
- **Fix.** Authenticate (signatures, PSK, or an established protocol: TLS, Noise, HPKE auth modes); HKDF(Z, salt, info = transcript‖labels).
- **Refs.** [E] SP 800-56C Rev.2; RFC 9180. CWE-322.

---

## Elliptic curves

### A-18 Invalid-curve and twist attacks (missing point validation)
- **Flaw.** A peer sends a point not on the curve (or on the curve's twist, for x-only ladders on weak-twist curves); scalar multiplication proceeds in a weaker group, leaking the static private key modulo small orders, fully recovered via CRT after a few hundred handshakes. Hits static ECDH: TLS ECDH-static, JWE `ECDH-ES`, custom protocols, Bluetooth pairing.
- **Code.** OpenSSL `EC_POINT_oct2point` without `EC_POINT_is_on_curve`; Java `ECPublicKeySpec` from raw coordinates (JDK validates in `KeyAgreement`; older Bouncy Castle did not — check version); Go `elliptic.Unmarshal` (validates), but `crypto/ecdh` is the right API now; Python `ec.EllipticCurvePublicNumbers(x, y, curve).public_key()` — validates on conversion; JOSE libraries building keys from `epk` without validation (Sanso's 2017 "Critical Vulnerability in JSON Web Encryption" affected go-jose, node-jose, jose2go, Nimbus JOSE+JWT and jose4j — look up each library's advisory for the CVE and fixed version); custom curve code; Bluetooth/embedded.
- **Confirm.** Wycheproof `ecdh_*` ("invalid public key" cases); unit test: a point with wrong y must be rejected.
- **FP.** Ephemeral-only ECDH with a fresh key per session (leak is bounded to one session) — still fix. X25519 (cofactor-cleared, twist-secure) is immune to invalid-curve; see A-24 for its own check.
- **Severity.** Critical with static keys.
- **Fix.** Full public-key validation (SP 800-56A §5.6.2.3.3): on curve, not infinity, order check (or cofactor multiply). Use X25519 where possible.
- **Refs.** [E] SP 800-56A Rev.3; RFC 8725 §3.4 (JWE). [L] Biehl, Meyer, Müller (CRYPTO 2000); Jager, Schwenk, Somorovsky, "Practical Invalid Curve Attacks on TLS-ECDH" (ESORICS 2015). CWE-20, CWE-347.

### A-19 ECDSA/DSA nonce reuse or bias (lattices, Minerva, TPM-Fail)
- **Flaw.** Same k for two signatures ⇒ private key by simple algebra (PS3, Bitcoin wallets). Biased k (a few known/zero bits, as in PuTTY's P-521 bug with 9 zero top bits) ⇒ lattice attack (HNP) with tens to hundreds of signatures. Timing leaks in scalar multiplication (Minerva, TPM-Fail) give the same bias remotely.
- **Code.** k from `random.random`/`Math.random`; k derived from a counter; k = hash(message) *without* key (predictable); k reduced from a too-short random (e.g., 512-bit random for P-521 order → top bits zero); custom scalar mult with early-exit; libraries without RFC 6979 in constrained environments; Java `SHA1PRNG` seeded.
- **Confirm.** Collect signatures, check for repeated r values (`scripts/key_analyzer.py --ecdsa-r` on a signature file); Wycheproof `ecdsa_*`; timing on sign.
- **Severity.** Critical.
- **Fix.** RFC 6979 deterministic nonces or "hedged" (RFC 6979 + extra randomness, FIPS 186-5 §6.3); constant-time scalar multiplication; use Ed25519 where possible.
- **Refs.** [E] RFC 6979; FIPS 186-5. [L] Breitner & Heninger, "Biased Nonce Sense" (FC 2019); Jancar et al., "Minerva" (TCHES 2020); Moghimi et al., "TPM-Fail" (USENIX Security 2020). CVE-2024-31497 (PuTTY 0.68–0.80, P-521: first 9 nonce bits zero; ~60 signatures to recover the key; fixed in 0.81 with RFC 6979), CVE-2019-11090 (Intel fTPM), CVE-2019-16863 (STMicro TPM). CWE-330, CWE-208.

### A-20 Signature malleability
- **Flaw.** ECDSA: (r, s) and (r, n−s) both verify; DER vs. raw encodings; non-canonical DER accepted. Ed25519: missing S < L check. A problem when the signature (or its hash) is used as an identifier/transaction ID or for replay protection.
- **Code.** `verify()` without low-s enforcement where tx IDs depend on the signature; custom DER parsing accepting non-minimal lengths.
- **Severity.** Medium (context-dependent; Low if signatures are never used as IDs).
- **Fix.** Enforce low-s / canonical encoding on both sides; use message-derived IDs.
- **Refs.** [E] RFC 8032 §5.1.7; BIP-62/146 for the Bitcoin case. CWE-347.

### A-21 r = 0 / s = 0 accepted ("Psychic Signatures")
- **Flaw.** ECDSA verification requires 1 ≤ r, s ≤ n−1. Without the check, the signature (0, 0) verifies any message under any key. Java 15–18 (before April 2022 CPU) shipped this.
- **Code.** Any custom/embedded ECDSA verify; Java 15–18 without patch; libraries ported from reference code.
- **Confirm.** Unit test with r=s=0 (and r=n, s=n) ⇒ must be rejected. Wycheproof has the vectors.
- **Severity.** Critical.
- **Refs.** CVE-2022-21449. CWE-347.

### A-22 Explicit curve parameters accepted (CurveBall)
- **Flaw.** A certificate carries `ECParameters` with explicit curve/generator instead of a `namedCurve` OID; verifier matches only the public point Q against a trusted key and uses the attacker's generator G′ ⇒ attacker forges a chain that "validates" against a trusted root. Windows CryptoAPI (2020).
- **Code.** X.509 parsing that accepts `explicitCurve`/`implicitCurve`; custom trust matching on `Q` only; embedded TLS stacks.
- **Confirm.** Feed a certificate with explicit parameters ⇒ must be rejected (RFC 5480 §2.1.1 requires `namedCurve` for PKIX).
- **Severity.** Critical.
- **Refs.** CVE-2020-0601 (CVSS 8.1; CISA KEV). CWE-295.

### A-23 Ed25519 pitfalls: small-order points, strict vs. permissive verification, separate public key
- **Flaw.** (1) Verifiers disagree on edge cases (small-order points in A or R, non-canonical encodings, cofactored vs. cofactorless equation) ⇒ consensus splits and signature-validity disagreement across nodes/services. (2) APIs like `sign(msg, sk, pk)` that take the public key as a separate argument and don't check `pk == derive(sk)` ⇒ an attacker who can pass a wrong `pk` obtains two signatures that reveal the private scalar (the "double public key signing function oracle"). (3) Key-substitution/"exclusive ownership" issues when signatures are not bound to keys.
- **Code.** `ed25519.sign(message, secret_key, public_key)` where `public_key` is caller-supplied (older `ed25519-dalek` ≤1.x with `ExpandedSecretKey::sign`; some libsodium wrappers; WASM crypto libs); verify functions ported from reference code with no small-order checks; mixed libraries in one system.
- **Confirm.** Wycheproof `ed25519_test.json` (and `eddsa_test` for the split cases); test signing with a mismatched pk ⇒ must fail or be impossible by API design.
- **Severity.** Critical (separate pk oracle); Medium (verification disagreement).
- **Fix.** Derive pk from sk inside the signer; pick one verification rule (RFC 8032 strict or ZIP-215) and use it everywhere; consider `verify_strict`.
- **Refs.** [E] RFC 8032. [L] Chalkias, Garillot, Nikolaenko, "Taming the Many EdDSAs" (SSR 2020); Brendel et al., "The Provable Security of Ed25519" (IEEE S&P 2021). CWE-347.

### A-24 X25519: all-zero shared secret (small-order peer key)
- **Flaw.** A small-order public key forces the shared secret to 0; an attacker then knows the "secret". Protocols must abort on an all-zero output (RFC 7748 §6.1; TLS 1.3 §7.4.2 mandates abort).
- **Code.** `x25519(priv, peer)` result used without checking for zero; libraries differ (libsodium `crypto_scalarmult` returns −1; Go `curve25519.X25519` returns error; PyCA raises; Noise/WireGuard-style custom code may not).
- **Confirm.** Feed the known small-order points ⇒ must abort.
- **Severity.** Medium (High if the derived key is used for authentication).
- **Refs.** [E] RFC 7748 §6.1; RFC 8446 §7.4.2.

### A-25 Curve choice
- **Flaw.** Curves < 224 bits (secp160, secp192); binary curves (B-/K-); non-standard/custom curves; secp256k1 outside Bitcoin contexts (acceptable but not FIPS); brainpool is fine (BSI) but check library constant-time support.
- **Severity.** Medium.
- **Fix.** P-256/P-384 (FIPS), X25519/Ed25519 (RFC 7748/8032, FIPS 186-5 approved), ≥250 bits per BSI.
- **Refs.** [E] SP 800-186; FIPS 186-5; BSI TR-02102-1.

### A-26 Variable-time scalar multiplication / big-number operations
- **Flaw.** Branching on secret scalar bits, secret-indexed table lookups, `BigInteger.modInverse`/`modPow` (Java) and Python `pow` are not constant-time; early-abort in Montgomery ladders. Leads to A-19-style nonce bias and ECDH key leaks (remote or co-tenant).
- **Code.** Hand-written ECC, `BigInteger` math in signing paths, embedded libs; also Java `ECDSA` in some providers, `java.math.BigInteger` in JWT/HSM-sim code.
- **Confirm.** ctgrind/TIMECOP/dudect on the implementation; code review of branches on secrets.
- **Severity.** High (when network-reachable or multi-tenant).
- **Fix.** Use constant-time libraries (BoringSSL, libsodium, `ring`, Go `crypto/ecdh`, `crypto/ecdsa` with Go ≥1.20 constant-time), never roll your own.
- **Refs.** [L] Jancar et al. (2020); Aranha et al., "LadderLeak" (CCS 2020); Brumley & Tuveri (ESORICS 2011). CWE-385, CWE-208.
