# Severity rubric, confidence levels, and reporting conventions

## Confidence (mandatory on every finding)

| Level | Meaning | Minimum evidence |
|---|---|---|
| **Confirmed** | The vulnerable condition demonstrably exists in the audited code. | Data-flow trace **and** a reproducible check (property test, script output, or an unambiguous static fact such as `random.random()` feeding a key). |
| **Probable** | The trace shows the precondition but it could not be exercised. | Complete trace; explain what blocked testing (no build, external service, secrets). |
| **Needs review** | A pattern consistent with the flaw; trace incomplete. | Say exactly what is missing ("nonce origin is in `vendor-sdk`, source unavailable"). |

**Condition confirmed, reachability unknown.** Helper functions with no callers in the audited tree, library code, or a path whose inputs you cannot see: the flaw is `Confirmed`, but who can reach it is not. State once in the threat model that severity assumes each function is used for what its name says, give the finding a conditional severity ("High; Critical if untrusted users can obtain the function's output"), and say what would settle it.

Never present a `Needs review` item with a Critical headline. Put the severity it *would* have in parentheses: "Needs review (would be Critical)", and list such items after the confirmed and probable findings, in the table of lesser findings, so that they are visible without outranking what is established.

**Stable finding IDs.** Give each finding its ID when it survives triage and keep it. Tests, attachments and notes are named after IDs; renumbering by severity at report time breaks every cross-reference. The report *orders* findings by severity; the IDs need not be consecutive in that order.

## Severity (default threat model: remote, unauthenticated or low-privileged attacker; no physical access)

| Severity | Use when |
|---|---|
| **Critical** | Direct compromise of confidentiality/integrity/authentication at scale with the precondition present: AEAD nonce reuse, cert validation disabled, `alg: none`/confusion, lax signature verification, keys in repo, factorable RSA, ECDSA nonce reuse, LMS state reuse, invalid-curve on static key, one key shared between an AEAD and a path that acts as a block-cipher oracle (S-27), a verification failure treated as success (T-02), a defaulted/empty secret reachable in a real deployment (C-04). |
| **High** | Realistic exploitation requires a common secondary condition (attacker-submitted ciphertexts, many queries, user interaction) or recovers less than everything: padding oracle, PKCS#1 v1.5 decryption, unauthenticated encryption of security-relevant data, fast password hashes, non-CSPRNG tokens, weak DH, length extension, obsolete algorithm on live traffic. |
| **Medium** | Weakens margins or needs an uncommon condition: 2048-bit RSA where a 3000-bit policy or long data lifetime applies (otherwise Low), CBC with random IV but no MAC on non-sensitive data, short GCM tags without attacker control, missing AAD binding, timing leaks behind strong rate limiting, pre-standard PQC algorithms, missing low-s. |
| **Low** | Hygiene/defence-in-depth: HMAC-SHA1, MD5 for non-security checksums near security code, verbose crypto errors in logs, missing `kid` versioning. |
| **Informational** | Observations: library versions approaching EOL, PQC readiness gaps, documentation inaccuracies with no security impact. |

Adjust and **state the adjustment**: an oracle or timing finding where every query costs a deliberate, user-driven operation (a client-side tool, an offline restore) goes one level down from the same flaw on a network service; physical/co-tenant access raises side-channel findings; a purely internal service with authenticated callers lowers oracle findings one level; data classification (health, payments, long-lived secrets) raises confidentiality findings.

Optional: CVSS 3.1/4.0 vector per finding if the client uses it. Map confidence separately; CVSS does not express it.

## Size of the write-up

Match the request (see "Size the job first" in `SKILL.md`). A quick verdict is one page: verdict first, then each finding as severity · confidence · `file:line` · one sentence · fix.

A full audit report is read by people who have to act on it, so its length should track the number of serious findings, not the number of catalog entries that matched:
- **Critical and High**: one full block each (`templates/finding.md`): trace, evidence, impact, corrected code. Keep the block to what a developer needs; five to fifteen lines of evidence, not whole test logs.
- **Medium, Low, Informational**: one table row each — location, what is wrong in one sentence, the fix in one sentence, confidence. Promote a row to a full block only when the fix is not obvious.
- Merge findings that share a root cause or a fix (five trust-all clients are one finding with five locations).
- Evidence lives in the attached files (tests, script output); the report cites them by name. Do not paste definitions, rubric text or the inventory into the report.
- As a yardstick: a target of a few hundred lines with a dozen serious findings is a report of roughly 400–600 lines. Three times that means the report is repeating itself.

In both sizes, severity and confidence appear on every finding.

## Finding fields (see `templates/finding.md`)

ID · Title · Severity · Confidence · Catalog ref · Location(s) (file:line, commit) · Description · Data-flow trace · Evidence (test output / script output / excerpt — redacted) · Impact · Preconditions & threat-model notes · Remediation (with corrected code) · References (CWE, CVE, standard, paper) · Status (open / fixed in commit X / accepted risk).

## How far remediation goes

Remediation is the corrected code for the affected lines, in the project's language and library, plus any data migration the fix implies (re-encrypt, rotate). Run the corrected lines against the same property test when that takes minutes. Do not build and test a replacement module or a new format unless the person asked for one: say what the redesign would be in a few lines and offer it.

## The report is for the client

No references to this skill, its catalog IDs or its scripts in the report: name each finding's class in plain words with its CWE, write "standards status as of <date>", and give re-run instructions the client can follow with the attached tests. Catalog IDs belong in your working notes.

## Writing conventions

- Lead with the fact, then the consequence: "The nonce passed to `Seal` (`seal/seal.go:41`) is a counter held in memory that starts at zero on every start-up, and the key is loaded from the same secret each time. The first message after each restart is therefore encrypted under a (key, nonce) pair that has been used before, which exposes the XOR of the two plaintexts and allows forged tags under that key."
- Quote code minimally; redact key material, tokens and PII in excerpts (`-----BEGIN RSA PRIVATE KEY----- [redacted]`).
- Remediation shows the correct call, not just "use AEAD": give the actual replacement lines in the project's language and library.
- Distinguish [E]/[L]/[P] basis when it matters ("required by FIPS 203 §7.2" vs "best practice per OWASP").
- One finding per root cause; list all affected locations inside it rather than N findings.
- Dismissed candidates go in their own section with one line each: "`utils/cache.py:12` MD5 for cache keys — not security-relevant, closed."
- Date the standards snapshot and name the library versions audited.
- Report language = the person's language; keep attack names, API identifiers, standard names in English.

## Prioritised remediation list

End the executive summary with the three to five changes that remove the most risk per unit of work, usually: (1) stop the bleeding (rotate exposed keys, disable `alg: none`, re-enable cert validation), (2) replace the construction (AEAD/HPKE/Argon2id), (3) add the regression tests from `verification-tests.md`, (4) policy/agility items (rotation, PQC plan).
