# Dangerous defaults and correct APIs, by language

Use this when a candidate hinges on "what does this call actually do by default?". Always confirm against the *installed* library version (`requirements.txt`, `pom.xml`, `package-lock.json`, `go.sum`, `Cargo.lock`, `*.csproj`), because defaults have changed over time. Where a line says "verify", the behaviour is version-dependent.

Each table: *API / pattern* → *what it really does* → *what to use instead* → *catalog ID*.

---

## Python

| Pattern | Reality | Use instead | ID |
|---|---|---|---|
| `random.*` for tokens/keys/IV | Mersenne Twister, predictable | `secrets`, `os.urandom` | S-14 |
| `hashlib.md5/sha1` on secrets/integrity | collisions, no key | SHA-256+, HMAC | S-23, S-24 |
| `hashlib.sha256(salt+pw)` | fast hash for passwords | `argon2-cffi`, `bcrypt`, `hashlib.scrypt`, PBKDF2 ≥600k | S-25 |
| `Crypto.Cipher.AES.new(key, AES.MODE_ECB)` (PyCryptodome) | ECB | `AES.MODE_GCM` / `MODE_OCB` / `MODE_SIV` | S-03 |
| `AES.new(key, AES.MODE_CBC, iv)` | no integrity | GCM, or `Fernet` (PyCA) | S-05 |
| `AES.new(key, AES.MODE_CTR, nonce=…)` nonce fixed | keystream reuse | random/unique nonce | S-06 |
| PyCA `Cipher(algorithms.AES(k), modes.ECB())` | ECB | `AESGCM`, `ChaCha20Poly1305` | S-03 |
| PyCA `AESGCM(k).encrypt(nonce, …)` nonce reused | forbidden attack | unique 96-bit nonce per key | S-07 |
| PyCA `AESCCM(k, tag_length=4)` | 32-bit tag | `tag_length=16` | S-11 |
| PyCA `private_key.decrypt(ct, padding.PKCS1v15())` | Bleichenbacher/Marvin surface. Measured: `cryptography` 41.0.7 (OpenSSL 3.1 bundled) raises `ValueError` on bad padding; 42.0.8 and later (OpenSSL ≥ 3.2 bundled) return a pseudo-random plaintext instead | `padding.OAEP(mgf=MGF1(SHA256()), algorithm=SHA256(), label=None)` | A-04 |
| PyCA `private_key.sign(data, PKCS1v15(), SHA1())` | SHA-1 signature | PSS + SHA-256 | S-24, A-07 |
| `rsa.generate_private_key(public_exponent=3, key_size=1024)` | weak | `65537`, ≥3072 | A-01, A-03 |
| `requests.get(url, verify=False)`; `ssl._create_unverified_context()`; `ctx.check_hostname=False`; `ctx.verify_mode=ssl.CERT_NONE` | no TLS auth | defaults / CA bundle | C-01 |
| `ssl.PROTOCOL_TLSv1`, `PROTOCOL_SSLv23` without `minimum_version` | old TLS | `ssl.create_default_context()`, `minimum_version = TLSv1_2` | C-06 |
| PyJWT 1.x `jwt.decode(t, key)` without `algorithms=` | the token chooses the signing algorithm (confusion candidate). `alg: none` is rejected whatever the key, including `None` (measured on 1.7.1). PyJWT ≥ 2.0 raises without `algorithms` | `algorithms=["ES256"]` (one per key), `audience=`, `issuer=` | C-03 |
| PyJWT `options={"verify_signature": False}` / `verify=False` | no verification at all | remove | C-02 |
| PyJWT `jwt.decode(t, "", algorithms=["HS256"])` (secret empty via a default) | accepted on 1.7.1 and 2.8.0, rejected on 2.15.0 (measured) | no default for secrets; length check at start-up | C-04 |
| `os.environ.get("…SECRET…", "")` / `os.getenv("…KEY…", "changeme")` | fail-open default: runs with an empty or public key | `os.environ["…"]` (fails at start-up) | C-04 |
| `python-jose` `jwt.decode(t, key)` with `algorithms` unset | confusion | set `algorithms` | C-03 |
| `mac == expected` | timing | `hmac.compare_digest` | S-18 |
| `pow(m, e, n)`, `pow(c, d, n)` hand-rolled RSA | textbook, variable-time | library | A-02, A-11 |
| `HKDF(..., info=b"")` for several keys | identical sub-keys | distinct `info` | S-26 |
| `Fernet` | AES-128-CBC + HMAC-SHA256 (EtM), timestamp — fine | — | — |
| `pickle` of key objects, keys in `logging` | exposure | — | C-08 |

## Java / Kotlin (JCA/JCE, Bouncy Castle)

| Pattern | Reality | Use instead | ID |
|---|---|---|---|
| `Cipher.getInstance("AES")` | **`AES/ECB/PKCS5Padding`** in SunJCE | `"AES/GCM/NoPadding"` | S-03 |
| `Cipher.getInstance("RSA")` | `RSA/ECB/PKCS1Padding` (v1.5) | `"RSA/ECB/OAEPWithSHA-256AndMGF1Padding"` + `OAEPParameterSpec` (MGF1 hash defaults to SHA-1 even with that string — set it explicitly) | A-04 |
| `Cipher.getInstance("DESede")`, `"DES"`, `"Blowfish"`, `"ARCFOUR"`, `"RC2"` | obsolete | AES-GCM | S-01 |
| `new IvParameterSpec(new byte[16])` | zero IV | `SecureRandom` IV | S-04 |
| `new GCMParameterSpec(128, iv)` with reused `iv` across `Cipher` objects | reuse undetected across instances | counter/random with rotation | S-07 |
| `new GCMParameterSpec(96…120, …)` | short tag. SunJCE accepts only 96/104/112/120/128 and throws for 32/64 (measured on JDK 21); Bouncy Castle accepts shorter | 128 | S-08 |
| `catch (GeneralSecurityException e) { return input; }` / empty `catch` around `Cipher`/`Signature` | failure falls through as success | fail closed, propagate | T-02 |
| `java.util.Random`, `Math.random()`, `ThreadLocalRandom` | not CSPRNG | `SecureRandom` | S-14 |
| `new SecureRandom(seed)` / `SecureRandom.getInstance("SHA1PRNG")` + `setSeed` before first use | deterministic (SHA1PRNG) | `new SecureRandom()`, `getInstanceStrong()` | S-15 |
| `SecretKeySpec("literal".getBytes(), "AES")` | string key | KMS / `KeyGenerator` | S-02, C-07 |
| `PBEKeySpec(pw, salt, 1000, 256)` with `PBKDF2WithHmacSHA1` | weak KDF | ≥600k iterations SHA-256, or Argon2 (BC `Argon2BytesGenerator`) | S-25 |
| `MessageDigest.getInstance("MD5"/"SHA-1")` on integrity/signature | weak | SHA-256 | S-24 |
| `Arrays.equals(mac, expected)`, `String.equals` | timing | `MessageDigest.isEqual` | S-18 |
| `Signature.getInstance("SHA1withRSA")`, `"MD5withRSA"` | weak | `"SHA256withRSA/PSS"`, `"SHA256withECDSA"`, Ed25519 (JDK 15+) | S-24 |
| `KeyPairGenerator.initialize(1024)` | short | 3072 / EC P-256 / Ed25519 | A-01 |
| `RSAKeyGenParameterSpec(n, BigInteger.valueOf(3))` | e=3 | `F4` | A-03 |
| ECDSA verify on JDK 15–18 unpatched | r=s=0 accepted | upgrade (April 2022 CPU) | A-21 |
| `X509TrustManager` with empty methods; `HostnameVerifier` → `true` | no validation | defaults, `"TLSv1.3"` | C-01, C-06 |
| `SSLContext.getInstance("SSL")` / `("TLSv1")` / `("TLSv1.1")` | legacy protocol-family name; current JDKs still negotiate only TLS 1.2/1.3 for "SSL" (jdk.tls.disabledAlgorithms decides) | `"TLSv1.3"` or `"TLS"` | C-06 |
| `Jwts.parser().parse(token)` (jjwt) | accepts unsigned | `parseClaimsJws` / `parseSignedClaims` | C-02 |
| `JWT.decode(token)` (auth0) without `JWTVerifier` | no verification | `JWT.require(alg).build().verify(token)` | C-02 |
| `KeyAgreement.doPhase(peerKey, true)` with `ECPublicKeySpec` from raw bytes | JDK validates for named curves (verify BC version) | `crypto.ecdh`-style validation | A-18 |
| `BigInteger.modPow/modInverse` in signing code | variable-time | provider implementation | A-26 |
| `javax.crypto.Mac.getInstance("HmacMD5")` | OK as MAC, flag Low | HmacSHA256 | S-24 |
| Android `SharedPreferences` for keys; `KeyStore` without `setUserAuthenticationRequired` when policy requires | storage | `AndroidKeyStore`, `EncryptedSharedPreferences` (deprecated — note) | C-08 |

## JavaScript / TypeScript (Node, WebCrypto, libraries)

| Pattern | Reality | Use instead | ID |
|---|---|---|---|
| `Math.random()` for tokens/IDs | predictable | `crypto.randomBytes`, `crypto.randomUUID`, `crypto.getRandomValues` | S-14 |
| `process.env.JWT_SECRET \|\| "dev-secret"` / `?? ""` | fail-open default secret | throw at start-up when unset | C-04 |
| `crypto.createCipher(alg, password)` (removed in Node 22) | MD5-derived key, fixed IV per password | `createCipheriv` with random IV | S-04, S-25 |
| `createCipheriv('aes-256-cbc', …)` without HMAC | no integrity | `'aes-256-gcm'`, `'chacha20-poly1305'` | S-05 |
| `createCipheriv('aes-256-gcm', key, iv)` iv from constant/config | nonce reuse | `randomBytes(12)` + rotation or counter | S-07 |
| `createDecipheriv('aes-256-gcm', k, iv)` + `decipher.setAuthTag(tag)` with no `authTagLength` option | Node accepts 4-, 8-, 12- and 16-byte tags (measured on Node 22): an attacker who controls the tag can truncate it to 32 bits | `createDecipheriv(alg, k, iv, { authTagLength: 16 })`, and check `tag.length === 16` | S-08 |
| `createHash('md5'/'sha1')` for integrity; `createHash('sha256').update(secret).update(data)` | collision / length extension | `createHmac('sha256', key)` | S-23, S-24 |
| `pbkdf2Sync(pw, salt, 1000, 32, 'sha1')` | weak | `argon2` (npm), `bcrypt` cost ≥10, `scrypt` | S-25 |
| `crypto.privateDecrypt({key, padding: constants.RSA_PKCS1_PADDING}, ct)` | Marvin (CVE-2023-46809; Node ≥20.11 refuses unless `--security-revert`) | `RSA_PKCS1_OAEP_PADDING` with `oaepHash: 'sha256'` | A-04 |
| `a === b` / `Buffer.equals` on MACs | timing | `crypto.timingSafeEqual` (same length) | S-18 |
| `https.request({rejectUnauthorized: false})`; `NODE_TLS_REJECT_UNAUTHORIZED=0`; `checkServerIdentity: () => undefined` | no validation | defaults | C-01 |
| `secureProtocol: 'TLSv1_method'`, `minVersion: 'TLSv1'` | old TLS | `minVersion: 'TLSv1.2'` | C-06 |
| `jsonwebtoken` `jwt.decode(t)` used for auth; `jwt.verify(t, key)` without `{algorithms: [...]}` | `decode` never verifies; without `algorithms` the token's alg is trusted, and ≤ 8.5.1 falls back to `none` when the key is falsy (CVE-2022-23540) | `jwt.verify(t, key, {algorithms: ['ES256'], audience, issuer})` | C-02, C-03 |
| `jose` library (panva) `jwtVerify(t, key)` | safe defaults; still set `algorithms`, `audience` | — | — |
| WebCrypto `AES-CBC`/`AES-CTR` | no integrity | `AES-GCM` with fresh `iv` | S-05 |
| WebCrypto `AES-GCM` `tagLength: 32/64` | short | 128 | S-08 |
| WebCrypto `extractable: true` for long-lived keys | exfiltration risk | `false` | C-08 |
| `node-forge` `publicKey.encrypt(m, 'RAW')` / `'RSAES-PKCS1-V1_5'` | textbook / v1.5 | `'RSA-OAEP'` | A-02, A-04 |
| `crypto-js` `AES.encrypt(msg, "passphrase")` | OpenSSL EVP_BytesToKey (MD5), CBC, no MAC | WebCrypto / libsodium | S-05, S-25 |
| `tweetnacl` `nacl.sign.detached(msg, secretKey)` | fine (pk derived) | — | — |
| `elliptic` (npm) | historical nonce/validation CVEs — pin version | `@noble/curves` | A-19, A-21 |

## Go

| Pattern | Reality | Use instead | ID |
|---|---|---|---|
| `math/rand`, `math/rand/v2` for secrets | predictable (v2 seeds from runtime but not CSPRNG-grade for keys) | `crypto/rand` | S-14 |
| `aes.NewCipher` + manual `block.Encrypt` loop | ECB | `cipher.NewGCM` | S-03 |
| `cipher.NewCBCEncrypter` without HMAC; `cipher.NewCTR` with fixed iv | no integrity / reuse | GCM, `chacha20poly1305` | S-05, S-06 |
| `gcm.Seal(nil, nonce, …)` with `nonce := make([]byte, 12)` unfilled or reused | nonce reuse | `rand.Read(nonce)` + rotation / counter | S-07 |
| `cipher.NewGCMWithNonceSize(b, n)` with n ≠ 12 | non-standard nonce length (any n is accepted) | `cipher.NewGCM` | S-08 |
| `cipher.NewGCMWithTagSize(b, 12…15)` | short tag. Only 12–16 are accepted; other values return an error (measured on Go 1.24) | `cipher.NewGCM` (16) | S-08 |
| `x, _ := aes.NewCipher(k)` / `gcm, _ := cipher.NewGCM…(…)` / `rand.Read(b)` unchecked | error discarded: nil AEAD panics on first use, or buffer not random | check every error | T-02 |
| `bytes.Equal(mac1, mac2)` | timing | `hmac.Equal`, `subtle.ConstantTimeCompare` | S-18 |
| `sha256.Sum256(append(secret, data…))` | length extension | `hmac.New(sha256.New, key)` | S-23 |
| `crypto/md5`, `crypto/sha1` in signatures/integrity; `crypto/des`, `crypto/rc4` | weak | sha256, AES | S-24, S-01 |
| `golang.org/x/crypto/pbkdf2` with 1000 iterations; `bcrypt.GenerateFromPassword(pw, 4)` | weak | `argon2.IDKey`, bcrypt ≥10, pbkdf2 ≥600k | S-25 |
| `rsa.DecryptPKCS1v15` (even `DecryptPKCS1v15SessionKey`) | v1.5 surface (Go's is constant-time by design, but protocol-level oracle may remain) | `rsa.DecryptOAEP` | A-04 |
| `rsa.GenerateKey(rand.Reader, 1024)` | short | 3072 / `ecdsa.GenerateKey(elliptic.P256())` / `ed25519` | A-01 |
| `rsa.SignPKCS1v15(…, crypto.SHA1, …)` | SHA-1 | `rsa.SignPSS` + SHA-256 | S-24 |
| `tls.Config{InsecureSkipVerify: true}` | no validation (chain *and* host) | `RootCAs`, `ServerName`, or `VerifyConnection` with explicit checks | C-01 |
| `tls.Config{MinVersion: tls.VersionTLS10}`, `CipherSuites` with RC4/3DES/CBC | old | `MinVersion: tls.VersionTLS12/13` | C-06 |
| `big.Int.Exp(peer, priv, p)` DH without checks | small subgroup | `crypto/ecdh` (X25519/P-256) | A-15 |
| `elliptic.Unmarshal` then custom scalar mult | validates point, but `elliptic` package is deprecated for ECDH | `crypto/ecdh` | A-18 |
| `ecdsa.Sign` on Go < 1.20 | variable-time in places; ≥1.20 constant-time + RFC6979-style hedging | upgrade | A-19, A-26 |
| `jwt.Parse(token, keyFunc)` (golang-jwt) without `jwt.WithValidMethods` | confusion possible via keyFunc | `WithValidMethods([]string{"ES256"})`, check `token.Method` in keyFunc | C-03 |
| `jwt.ParseUnverified` used for auth | none | `Parse` | C-02 |
| `crypto/mlkem` (Go ≥1.24) | FIPS 203 final; `kyber768` from x/crypto was round-3 | prefer std | P-01 |

## C / C++ (OpenSSL, libsodium, mbedTLS, wolfSSL)

| Pattern | Reality | Use instead | ID |
|---|---|---|---|
| `rand()`, `random()`, `std::mt19937`, `std::default_random_engine`, `srand(time(NULL))` | predictable | `getrandom(2)`, `arc4random_buf`, `RAND_bytes` (check `== 1`), `BCryptGenRandom`, `randombytes_buf` | S-14, S-15 |
| `EVP_aes_*_ecb()`, `AES_encrypt()` (low-level, ECB per block) | ECB | `EVP_aes_256_gcm()`, `EVP_chacha20_poly1305()` | S-03 |
| `EVP_aes_256_cbc()` without HMAC | no integrity | GCM | S-05 |
| `EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, key, iv)` iv static | reuse | random/counter | S-07 |
| `EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, 16, …)`, `SET_TAG` len < 16 | non-standard | 12 / 16 | S-08 |
| ignoring return of `EVP_DecryptFinal_ex` / using `EVP_DecryptUpdate` output first | plaintext before tag | check return, buffer | S-19 |
| `memcmp(tag, …)`, `strcmp` on secrets | timing | `CRYPTO_memcmp`, `sodium_memcmp` | S-18 |
| `EVP_des_ede3_cbc()`, `EVP_rc4()`, `EVP_bf_cbc()`, `EVP_md5()`/`EVP_sha1()` in signatures | obsolete | AES-GCM, SHA-256 | S-01, S-24 |
| `PKCS5_PBKDF2_HMAC_SHA1(…, 1000, …)` | weak | `PKCS5_PBKDF2_HMAC` SHA-256 ≥600k, `crypto_pwhash` (libsodium Argon2id), `EVP_PBE_scrypt` | S-25 |
| `RSA_private_decrypt(…, RSA_PKCS1_PADDING)`, `EVP_PKEY_CTX_set_rsa_padding(ctx, RSA_PKCS1_PADDING)` decrypt | Bleichenbacher/Marvin surface. OpenSSL 3.2+ and distributions that backported it (measured: Ubuntu's 3.0.13) use *implicit rejection*: bad padding returns a deterministic pseudo-random plaintext, not an error — so "the error is never returned" does not mean the code moved off v1.5. Older builds: CVE-2022-4304 timing | `RSA_PKCS1_OAEP_PADDING` + `set_rsa_oaep_md(sha256)` | A-04 |
| `RSA_NO_PADDING` | textbook | OAEP/PSS | A-02 |
| `RSA_blinding_off`, `RSA_FLAG_NO_BLINDING` | timing | default | A-11 |
| `RSA_public_decrypt` + manual DigestInfo compare | lax verification | `EVP_DigestVerify*` | A-06 |
| `EVP_VerifyFinal` return treated as boolean (`if (ret)`) | returns −1 on error ⇒ true! | `ret == 1` | A-06 |
| `DH_compute_key` without `DH_check_pub_key`; `DH_generate_parameters` 1024 | small subgroup / weak | `EVP_PKEY_derive` with validation; ffdhe2048+; X25519 | A-14, A-15 |
| `EC_POINT_oct2point` without `EC_POINT_is_on_curve`/`EC_KEY_check_key`; `EC_GROUP_new_curve_GFp` custom | invalid curve | `EVP_PKEY_derive` (validates), named curves | A-18, A-22 |
| `SSL_CTX_set_verify(ctx, SSL_VERIFY_NONE, …)`; missing `SSL_set1_host`/`X509_VERIFY_PARAM_set1_host`; ignoring `SSL_get_verify_result` | no auth | `SSL_VERIFY_PEER` + host | C-01 |
| `SSL_CTX_set_min_proto_version` absent / `SSLv23_method()` without `SSL_OP_NO_TLSv1*`; `SSL_CTX_set_cipher_list("ALL")` | old | `TLS1_2_VERSION`+; curated list | C-06 |
| libsodium `crypto_aead_chacha20poly1305_ietf_encrypt` with fixed nonce | reuse | `crypto_aead_xchacha20poly1305_ietf_*` + `randombytes_buf` | S-10 |
| libsodium `crypto_scalarmult` result ignored (−1 on small order) | zero secret | check return | A-24 |
| mbedTLS `mbedtls_ssl_conf_authmode(…, MBEDTLS_SSL_VERIFY_NONE/OPTIONAL)` | no auth | `VERIFY_REQUIRED` | C-01 |
| wolfSSL `wolfSSL_CTX_set_verify(ctx, SSL_VERIFY_NONE, 0)` | no auth | `SSL_VERIFY_PEER` | C-01 |
| Kyber reference code vendored before Dec 2023 | KyberSlash | update | P-02 |

## C# / .NET

| Pattern | Reality | Use instead | ID |
|---|---|---|---|
| `new Random()`, `Guid.NewGuid()` as secret | predictable | `RandomNumberGenerator.GetBytes/Fill/GetInt32` | S-14 |
| `aes.Mode = CipherMode.ECB`; `TripleDES.Create()`, `DES.Create()`, `RC2.Create()` | ECB / obsolete | `AesGcm`, `ChaCha20Poly1305` | S-03, S-01 |
| `Aes.Create()` (CBC default) + `CreateEncryptor` without HMAC | no integrity | `AesGcm` | S-05 |
| `aes.IV = new byte[16]` / `aes.Key = Encoding.UTF8.GetBytes("…")` | zero IV / string key | `aes.GenerateIV()`, KMS | S-04, S-02 |
| `AesGcm.Encrypt(nonce, …)` with static nonce | reuse | random/counter | S-07 |
| `new AesGcm(key, tagSizeInBytes: 12)` (.NET 8+) or tag arrays of 12 | shorter tag | 16 | S-08 |
| `MD5.Create()`, `SHA1.Create()` for integrity/signatures | weak | `SHA256` | S-24 |
| `new Rfc2898DeriveBytes(pw, salt)` / `(pw, salt, 1000)` | SHA-1, 1000 iterations | `Rfc2898DeriveBytes.Pbkdf2(pw, salt, 600_000, HashAlgorithmName.SHA256, 32)`, `Konscious.Security.Cryptography.Argon2id`, `BCrypt.Net` | S-25 |
| `rsa.Decrypt(data, RSAEncryptionPadding.Pkcs1)` / `rsa.Decrypt(data, false)` | v1.5 | `RSAEncryptionPadding.OaepSHA256` | A-04 |
| `rsa.SignData(d, HashAlgorithmName.SHA1, RSASignaturePadding.Pkcs1)` | SHA-1 | SHA-256 + `Pss` | S-24 |
| `RSA.Create(1024)` | short | 3072 / `ECDsa.Create(ECCurve.NamedCurves.nistP256)` | A-01 |
| `a.SequenceEqual(b)` on MACs | timing | `CryptographicOperations.FixedTimeEquals` | S-18 |
| `ServerCertificateCustomValidationCallback = (…) => true`; `ServicePointManager.ServerCertificateValidationCallback += …true`; `DangerousAcceptAnyServerCertificateValidator` | no validation | remove | C-01 |
| `SslProtocols.Tls \| Tls11`; `SecurityProtocolType.Ssl3` | old | `SslProtocols.None` (OS default) / `Tls12 \| Tls13` | C-06 |
| `TokenValidationParameters { ValidateAudience = false, ValidateIssuer = false, RequireSignedTokens = false, RequireExpirationTime = false }` | weak JWT | all true; `ValidAlgorithms` | C-02, C-05 |
| `MachineKey`/`ProtectedData` misuse, `DataProtection` keys in repo | storage | Key vault | C-08 |

## Rust

| Pattern | Reality | Use instead | ID |
|---|---|---|---|
| `rand::rngs::SmallRng`, `StdRng::seed_from_u64(const)`, `fastrand` for secrets | predictable | `OsRng`, `rand::thread_rng()` (CSPRNG), `getrandom` | S-14, S-15 |
| `rsa` crate `Pkcs1v15Encrypt` decrypt (< 0.9.x) | Marvin (RUSTSEC-2023-0071, CVE-2023-49092) | `Oaep`, or move to `ring`/hybrid | A-04 |
| `aes` crate + manual block loop; `cbc` crate without `hmac` | ECB / no integrity | `aes-gcm`, `chacha20poly1305` | S-03, S-05 |
| `Aes256Gcm::encrypt(&Nonce::from_slice(&[0u8;12]), …)` | reuse | `Aes256Gcm::generate_nonce(&mut OsRng)` + rotation, or `XChaCha20Poly1305` | S-07, S-10 |
| `a == b` on `[u8]` tags | timing | `subtle::ConstantTimeEq` / `ct_eq` | S-18 |
| `md5`/`sha1` crates for integrity | weak | `sha2` | S-24 |
| `pbkdf2` with 1000 rounds; `bcrypt::hash(pw, 4)` | weak | `argon2` (default params), bcrypt ≥10 | S-25 |
| `reqwest::Client::builder().danger_accept_invalid_certs(true)`, `.danger_accept_invalid_hostnames(true)`; custom `ServerCertVerifier` returning `Ok` | no validation | rustls defaults | C-01 |
| `native-tls` `.danger_accept_invalid_certs(true)` | same | — | C-01 |
| `jsonwebtoken::dangerous_insecure_decode`, `Validation { validate_exp: false, … }`, `insecure_disable_signature_validation()` | weak | `Validation::new(Algorithm::ES256)` + `set_audience` | C-02, C-05 |
| `ed25519-dalek` ≤ 1.x `ExpandedSecretKey::sign(msg, &public_key)` | separate pk oracle | ≥ 2.0 `SigningKey` | A-23 |
| `x25519-dalek` shared secret used without `was_contributory()` check (where required) | zero/low-order | check | A-24 |
| `pqcrypto-kyber` (round 3) vs `pqcrypto-mlkem` / `ml-kem` crate | pre-standard | FIPS 203 crates | P-01 |

## PHP

| Pattern | Reality | Use instead | ID |
|---|---|---|---|
| `rand()`, `mt_rand()`, `uniqid()`, `lcg_value()`, `str_shuffle` for tokens | predictable | `random_bytes`, `random_int`, `bin2hex(random_bytes(32))` | S-14 |
| `md5($pw)`, `sha1($pw)`, `hash('sha256', $pw)`, `crypt()` with DES | weak password hash | `password_hash($pw, PASSWORD_ARGON2ID)` / `PASSWORD_BCRYPT` cost ≥10 | S-25 |
| `mcrypt_*` (removed PHP 7.2) | obsolete, often ECB | `sodium_crypto_secretbox` / `openssl_encrypt` GCM | S-01, S-03 |
| `openssl_encrypt($d, 'aes-128-ecb', …)`; `'aes-256-cbc'` without HMAC | ECB / no integrity | `'aes-256-gcm'` with `$tag`, or libsodium | S-03, S-05 |
| `openssl_encrypt(..., $iv = '')` / static `$iv` | IV reuse | `random_bytes(openssl_cipher_iv_length(...))` | S-04, S-07 |
| `md5($secret . $data)` | length extension | `hash_hmac('sha256', $data, $secret)` | S-23 |
| `$a == $b` / `===` on MACs/tokens | timing (and type juggling with `==`) | `hash_equals` | S-18 |
| `CURLOPT_SSL_VERIFYPEER => false`, `CURLOPT_SSL_VERIFYHOST => 0`; `'verify_peer' => false` | no validation | defaults | C-01 |
| `firebase/php-jwt` `JWT::decode($t, $key)` (< 5.x without `$allowed_algs`) | confusion | `new Key($key, 'ES256')` | C-03 |
| `openssl_private_decrypt($c, $out, $key, OPENSSL_PKCS1_PADDING)` | v1.5 | `OPENSSL_PKCS1_OAEP_PADDING` | A-04 |

## Ruby

| Pattern | Reality | Use instead | ID |
|---|---|---|---|
| `rand`, `Random.new`, `Array#shuffle` for tokens | predictable | `SecureRandom.hex/bytes/uuid` | S-14 |
| `Digest::MD5`/`SHA1` for passwords/integrity | weak | `BCrypt::Password.create(pw, cost: 12)`, Argon2 gem | S-25, S-24 |
| `OpenSSL::Cipher.new('aes-256-ecb')`, `'aes-256-cbc'` without HMAC | ECB / no integrity | `'aes-256-gcm'` with `auth_tag`, `auth_data` | S-03, S-05 |
| `cipher.iv = "\0"*16` / `cipher.random_iv` not called | zero IV | `cipher.random_iv` | S-04 |
| `a == b` on MACs | timing | `ActiveSupport::SecurityUtils.secure_compare`, `OpenSSL.fixed_length_secure_compare` | S-18 |
| `http.verify_mode = OpenSSL::SSL::VERIFY_NONE` | no validation | `VERIFY_PEER` | C-01 |
| `JWT.decode(token, key, false)` / `verify: false` (ruby-jwt) | none | `JWT.decode(token, key, true, { algorithm: 'ES256', verify_aud: true })` | C-02 |
| `OpenSSL::PKey::RSA#private_decrypt(c)` (default PKCS1) | v1.5 | `OpenSSL::PKey::RSA::PKCS1_OAEP_PADDING` | A-04 |
| Rails `secret_key_base` committed; `config.force_ssl = false` | secret exposure / downgrade | credentials, `force_ssl` | C-07, C-06 |

## Configuration files

| Where | Dangerous | Safer | ID |
|---|---|---|---|
| nginx | `ssl_protocols TLSv1 TLSv1.1`; `ssl_ciphers` incl. `3DES`, `RC4`, `MD5`, `aNULL`, `EXPORT`, `kRSA`; `ssl_prefer_server_ciphers off` with weak lists; `ssl_session_tickets on` without key rotation | `ssl_protocols TLSv1.2 TLSv1.3;` Mozilla intermediate list; `ssl_ecdh_curve X25519MLKEM768:X25519:prime256v1` | C-06 |
| Apache | `SSLProtocol all -SSLv2`; `SSLCipherSuite HIGH:MEDIUM`; `SSLHonorCipherOrder off` | `SSLProtocol -all +TLSv1.2 +TLSv1.3` | C-06 |
| HAProxy | `ssl-default-bind-options` without `ssl-min-ver TLSv1.2`; `no-tlsv12` absent on old | `ssl-min-ver TLSv1.2` | C-06 |
| OpenSSH `sshd_config` | `Ciphers 3des-cbc,arcfour`, `MACs hmac-md5`, `KexAlgorithms diffie-hellman-group1-sha1`, `HostKeyAlgorithms ssh-rsa` (SHA-1), `PermitRootLogin yes` (not crypto) | `chacha20-poly1305@openssh.com,aes256-gcm@openssh.com`; `curve25519-sha256`, `sntrup761x25519-sha512`/`mlkem768x25519-sha256` (OpenSSH ≥9.9/10) | C-06, A-14 |
| OpenSSL `openssl.cnf` | `MinProtocol = TLSv1`, `CipherString = DEFAULT@SECLEVEL=0` | `SECLEVEL=2`, `MinProtocol = TLSv1.2` | C-06 |
| Java `java.security` | removing `SSLv3`, `TLSv1`, `MD5withRSA` from `jdk.tls.disabledAlgorithms` / `jdk.certpath.disabledAlgorithms` | leave defaults | C-06 |
| Kubernetes / ingress | `nginx.ingress.kubernetes.io/ssl-ciphers` weak; `--tls-min-version=VersionTLS10` on kube-apiserver; secrets in ConfigMaps | TLS1.2+; Secrets + KMS envelope | C-06, C-08 |
| AWS | ELB `ELBSecurityPolicy-2016-08` (TLS1.0), CloudFront `TLSv1`, S3 bucket policy without `aws:SecureTransport`; KMS key policy `kms:Decrypt` on `*` | `ELBSecurityPolicy-TLS13-1-2-2021-06`, `TLSv1.2_2021`, least-privilege KMS | C-06, C-08 |
| Docker/CI | `ENV JWT_SECRET=…`, private keys in image layers, `--build-arg SECRET` | secret mounts | C-07 |
| Android `network_security_config.xml` | `<certificates src="user"/>` in release; `cleartextTrafficPermitted="true"` | system CAs only; pinning with backup pins | C-01 |
| iOS `Info.plist` | `NSAllowsArbitraryLoads = true` | ATS defaults | C-01 |
