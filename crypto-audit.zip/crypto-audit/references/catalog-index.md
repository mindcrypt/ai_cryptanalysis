# Catalog index

One line per entry. Open only the entries you need: `Read` the file at the given line for the given number of lines,
or `Grep` for the heading (pattern `^#{2,3} S-07`). Regenerate with `python3 scripts/build_index.py` after editing a catalog.

| ID | Entry | File | Line | Lines |
|---|---|---|---|---|
| S-01 | Obsolete / weak algorithms (DES, 3DES, RC4, Blowfish, 64-bit blocks — Sweet32) | `catalog-symmetric.md` | 9 | 11 |
| S-02 | Short keys or keys derived from strings | `catalog-symmetric.md` | 20 | 11 |
| S-03 | ECB mode | `catalog-symmetric.md` | 31 | 11 |
| S-04 | CBC IV predictable, static, zero, or equal to the key | `catalog-symmetric.md` | 42 | 11 |
| S-05 | Unauthenticated encryption (malleability, bit-flipping) | `catalog-symmetric.md` | 53 | 11 |
| S-06 | Keystream reuse (CTR / OFB / CFB / stream ciphers) | `catalog-symmetric.md` | 64 | 11 |
| S-07 | AES-GCM nonce reuse ("forbidden attack") | `catalog-symmetric.md` | 75 | 11 |
| S-08 | GCM: non-96-bit nonce, truncated tags, per-key usage limits | `catalog-symmetric.md` | 86 | 11 |
| S-09 | Non-persistent counters, multi-instance, concurrency, random-nonce collision | `catalog-symmetric.md` | 97 | 11 |
| S-10 | ChaCha20-Poly1305 / XChaCha20 misuse | `catalog-symmetric.md` | 108 | 9 |
| S-11 | CCM misparameterized | `catalog-symmetric.md` | 117 | 9 |
| S-12 | XTS outside storage encryption | `catalog-symmetric.md` | 126 | 8 |
| S-13 | Wrong expectations of SIV / AES-GCM-SIV | `catalog-symmetric.md` | 134 | 7 |
| S-14 | Non-cryptographic RNG for keys, IVs, salts, tokens, session IDs | `catalog-symmetric.md` | 141 | 19 |
| S-15 | Weak seeding, fork-safety, VM snapshots, low boot entropy | `catalog-symmetric.md` | 160 | 11 |
| S-16 | MAC-then-Encrypt and Encrypt-and-MAC | `catalog-symmetric.md` | 171 | 10 |
| S-17 | Same key for encryption and MAC; MAC that omits IV/header/AAD; ambiguous concatenation | `catalog-symmetric.md` | 181 | 12 |
| S-18 | Non-constant-time tag/MAC/password comparison | `catalog-symmetric.md` | 193 | 10 |
| S-19 | Plaintext released before tag verification | `catalog-symmetric.md` | 203 | 10 |
| S-20 | AAD misuse | `catalog-symmetric.md` | 213 | 9 |
| S-21 | No key commitment (partitioning oracles, invisible salamanders) | `catalog-symmetric.md` | 222 | 8 |
| S-22 | Padding oracle (Vaudenay), Lucky13, POODLE | `catalog-symmetric.md` | 230 | 11 |
| S-23 | Length extension with H(key ‖ message) | `catalog-symmetric.md` | 241 | 10 |
| S-24 | MD5 / SHA-1 for integrity or signatures; CRC as integrity | `catalog-symmetric.md` | 251 | 9 |
| S-25 | Password hashing: fast hash, no salt, weak parameters | `catalog-symmetric.md` | 260 | 11 |
| S-26 | HKDF / KDF misuse | `catalog-symmetric.md` | 271 | 9 |
| S-27 | One key used in several modes, primitives or protocols (cross-mode oracle) | `catalog-symmetric.md` | 280 | 12 |
| A-01 | RSA key too small | `catalog-asymmetric.md` | 13 | 8 |
| A-02 | Textbook RSA (no padding) | `catalog-asymmetric.md` | 21 | 7 |
| A-03 | Small public exponent (e = 3) with structure | `catalog-asymmetric.md` | 28 | 7 |
| A-04 | PKCS#1 v1.5 decryption oracle (Bleichenbacher, ROBOT, Marvin) | `catalog-asymmetric.md` | 35 | 11 |
| A-05 | Manger's attack on OAEP | `catalog-asymmetric.md` | 46 | 7 |
| A-06 | Lax PKCS#1 v1.5 signature verification (Bleichenbacher 2006, BERserk) | `catalog-asymmetric.md` | 53 | 8 |
| A-07 | RSA-PSS parameters | `catalog-asymmetric.md` | 61 | 7 |
| A-08 | Weak key generation: common modulus, shared primes, ROCA | `catalog-asymmetric.md` | 68 | 8 |
| A-09 | Small private exponent (Wiener, Boneh–Durfee) | `catalog-asymmetric.md` | 76 | 6 |
| A-10 | CRT fault attack (Bellcore) | `catalog-asymmetric.md` | 82 | 7 |
| A-11 | RSA without blinding | `catalog-asymmetric.md` | 89 | 6 |
| A-12 | Same RSA key for signing and encryption | `catalog-asymmetric.md` | 95 | 5 |
| A-13 | ElGamal encryption/signature pitfalls | `catalog-asymmetric.md` | 104 | 7 |
| A-14 | Weak DH parameters (Logjam, small primes, non-safe primes) | `catalog-asymmetric.md` | 115 | 8 |
| A-15 | Small-subgroup attack / missing public-key validation (DH) | `catalog-asymmetric.md` | 123 | 8 |
| A-16 | Ephemeral key reuse; Raccoon | `catalog-asymmetric.md` | 131 | 7 |
| A-17 | Unauthenticated DH / shared secret used raw | `catalog-asymmetric.md` | 138 | 7 |
| A-18 | Invalid-curve and twist attacks (missing point validation) | `catalog-asymmetric.md` | 149 | 9 |
| A-19 | ECDSA/DSA nonce reuse or bias (lattices, Minerva, TPM-Fail) | `catalog-asymmetric.md` | 158 | 8 |
| A-20 | Signature malleability | `catalog-asymmetric.md` | 166 | 7 |
| A-21 | r = 0 / s = 0 accepted ("Psychic Signatures") | `catalog-asymmetric.md` | 173 | 7 |
| A-22 | Explicit curve parameters accepted (CurveBall) | `catalog-asymmetric.md` | 180 | 7 |
| A-23 | Ed25519 pitfalls: small-order points, strict vs. permissive verification, separate public key | `catalog-asymmetric.md` | 187 | 8 |
| A-24 | X25519: all-zero shared secret (small-order peer key) | `catalog-asymmetric.md` | 195 | 7 |
| A-25 | Curve choice | `catalog-asymmetric.md` | 202 | 6 |
| A-26 | Variable-time scalar multiplication / big-number operations | `catalog-asymmetric.md` | 208 | 8 |
| P-01 | Standard status; pre-standard or non-final algorithm in production | `catalog-pqc.md` | 11 | 10 |
| P-02 | KyberSlash and other timing leaks in ML-KEM/ML-DSA implementations | `catalog-pqc.md` | 21 | 10 |
| P-03 | Missing FIPS 203 input checks | `catalog-pqc.md` | 31 | 9 |
| P-04 | Implicit rejection broken (ML-KEM decapsulation) | `catalog-pqc.md` | 40 | 9 |
| P-05 | Seeds, key formats, and randomness | `catalog-pqc.md` | 49 | 8 |
| P-06 | ML-DSA / SLH-DSA: deterministic vs hedged, context strings, pre-hash variants | `catalog-pqc.md` | 57 | 8 |
| P-07 | Stateful hash-based signatures (LMS, XMSS, HSS/XMSS^MT): state management | `catalog-pqc.md` | 65 | 9 |
| P-08 | Hybrid combiners (X25519MLKEM768, SecP256r1MLKEM768, composite signatures) | `catalog-pqc.md` | 74 | 9 |
| P-09 | FN-DSA (Falcon) pre-standard; floating-point Gaussian sampling | `catalog-pqc.md` | 83 | 8 |
| C-01 | Certificate validation or hostname verification disabled | `catalog-config.md` | 7 | 19 |
| C-02 | JWT accepted without a verified signature (`alg: none`, verification switched off) | `catalog-config.md` | 26 | 12 |
| C-03 | JWT algorithm confusion (RS256 → HS256) and algorithm taken from the token | `catalog-config.md` | 38 | 10 |
| C-04 | Weak, empty or defaulted HMAC secrets for JWT / session signing | `catalog-config.md` | 48 | 11 |
| C-05 | `kid`, `jku`, `x5u`, `jwk` headers; serialization/format confusion; missing claims | `catalog-config.md` | 59 | 9 |
| C-06 | TLS versions and cipher suites | `catalog-config.md` | 68 | 10 |
| C-07 | Keys, secrets and certificates in the repository | `catalog-config.md` | 78 | 10 |
| C-08 | Key storage, rotation, purpose separation, lifecycle | `catalog-config.md` | 88 | 9 |
| C-09 | ASN.1 / DER / PEM / X.509 parsing | `catalog-config.md` | 97 | 9 |
| C-10 | KEM-DEM composition and HPKE usage | `catalog-config.md` | 106 | 11 |
| C-11 | Public-key (hybrid) encryption mistaken for authentication: anyone can produce a valid message | `catalog-config.md` | 119 | 12 |
| T-01 | Timing side channels visible in application code | `catalog-config.md` | 131 | 10 |
| T-02 | Unchecked or discarded errors from cryptographic calls (fail-open) | `catalog-config.md` | 141 | 16 |

## Test recipes (`verification-tests.md`)

| Recipe | What it tests | Line | Lines |
|---|---|---|---|
| T0 | Run every behaviour test on the pinned dependency versions | 11 | 21 |
| T1 | Determinism / fixed IV (S-03, S-04) | 32 | 13 |
| T2 | Nonce/IV uniqueness across calls, processes, restarts (S-06, S-07, S-09, S-10) | 45 | 19 |
| T3 | Malleability / missing authentication (S-05) | 64 | 12 |
| T4 | Tag truncation (S-08, S-11) | 76 | 9 |
| T5 | Plaintext released before tag verification (S-19) | 85 | 10 |
| T6 | AAD / context binding (S-20) | 95 | 9 |
| T7 | Padding / MAC oracle distinguishability (S-16, S-22) — no decryption attempted | 104 | 31 |
| T8 | Timing of comparisons (S-18, T-01) | 135 | 11 |
| T9 | RNG provenance (S-14, S-15) | 146 | 11 |
| T10 | Password KDF parameters (S-25) | 157 | 15 |
| T11 | Length extension susceptibility (S-23) | 172 | 3 |
| T12 | RSA key sanity (A-01, A-03, A-08, A-09) | 175 | 6 |
| T13 | RSA PKCS#1 v1.5 decryption oracle (A-04, A-05) — no plaintext recovery | 181 | 13 |
| T14 | Signature verification edge cases (A-06, A-20, A-21, A-22) | 194 | 15 |
| T15 | Public-key / point validation (A-15, A-18) | 209 | 11 |
| T16 | X25519 small-order inputs (A-24) | 220 | 8 |
| T17 | JWT acceptance tests (C-02…C-05) | 228 | 30 |
| T18 | TLS client validation (C-01, C-06) | 258 | 17 |
| T19 | ML-KEM input checks and implicit rejection (P-03, P-04) | 275 | 13 |
| T20 | LMS/XMSS state (P-07) | 288 | 3 |
| T21 | Hybrid combiner (P-08) | 291 | 10 |
| T22 | Spec-vs-code claims | 301 | 11 |
| T23 | One key in several modes (S-27) | 312 | 11 |
| T24 | Failure paths (T-02) | 323 | 13 |
| T25 | What the MAC or signature covers (S-17, S-20, C-11) | 336 | 16 |
