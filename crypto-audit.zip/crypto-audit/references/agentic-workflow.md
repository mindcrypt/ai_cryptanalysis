# Agentic workflow: parallel sweep + independent verification

Use when the environment can spawn sub-agents (Claude Code, Cowork) and the target is larger than a few files. The design goal is the same as in human audits: the person who argues a finding is not the person who signs it off.

## Topology

```
Orchestrator (you)
├── Inventory (scripts, deterministic — run yourself)
├── Sweep agents, one per component / language slice   ← each gets ONE catalog slice + apis-by-language
│     return: candidates with traces (JSON)
├── Verifier agent(s)                                  ← gets findings text + repo, NOT the sweep reasoning
│     return: Confirmed / Probable / Needs review / Closed, with evidence
└── Report (you)
```

Split by *component* (service, package, module), not by catalog area, so each sweep agent reads whole data flows. Give each agent only the catalog file(s) relevant to the primitives in its slice (from the inventory) to keep context focused.

## Sweep agent prompt (template)

```
You are auditing the cryptography in <component path> of <repo>. Read <path>/references/catalog-<area>.md and
<path>/references/apis-by-language.md first. Then read the component's code (start from the inventory lines below).

Inventory lines for this component:
<paste inventory.md rows for the component>

For every catalog ID that applies, produce a candidate with:
- id, title, severity_if_true, catalog_ref
- locations: [{file, line, excerpt (max 3 lines, redact secrets)}]
- trace: step-by-step origin of the key / nonce / error path / input that makes the flaw exploitable, with file:line per step
- precondition_status: "present" | "absent" | "unknown (why)"
- proposed_test: one of the recipes in references/verification-tests.md, adapted to this code
Also list candidates you investigated and closed, with the reason.
Do not write exploit code. Do not report a pattern without attempting the trace.
Output JSON only.
```

## Verifier agent prompt (template)

```
You are an independent verifier. You receive candidate findings about <repo> but not the reasoning behind them.
For each finding:
1. Re-derive the data-flow trace from the code yourself. If it does not hold, mark Closed with the reason.
2. If it holds, run the proposed property test (adapt it; use the project's test runner; use scripts/ in
   <skill path>). Record the command and output verbatim (redact secrets).
3. Assign: Confirmed (trace + test), Probable (trace, test not possible: say why), Needs review (trace incomplete: say what is missing), Closed.
4. Check the cited CWE/standard against references/standards-status.md; flag anything marked "verify".
Be adversarial toward the finding: your job is to break it. Output JSON with the same schema plus
verification_status, verification_evidence, and notes.
```

## Orchestrator duties

- Run inventory and Semgrep yourself; distribute rows.
- Deduplicate candidates across agents (same root cause in shared code).
- Reconcile disagreements between sweep and verifier by reading the code yourself; never average them.
- Keep a `closed.md` of dismissed candidates — it goes in the report.
- Enforce rule 10 (no secrets in anything written): run `scripts/leak_scan.py <target> <outputs>` over every agent's output before including it.

## When not to parallelise

Small targets (< ~30 crypto-relevant files), a single PR, or a design document: do it yourself end-to-end, but still run the verification phase as a distinct pass — re-read each finding as if you had not written it, and run the tests.
