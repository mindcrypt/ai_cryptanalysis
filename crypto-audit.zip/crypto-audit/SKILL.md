---
name: crypto-audit
description: "Audit cryptography in source code, configs and docs. Use for any crypto security review, pentest, PR review or code audit touching encryption, hashing, keys, TLS, JWT, RSA/ECC/PQC."
---

# Crypto Audit

Audit how a codebase *uses* cryptography and find implementation, configuration and composition flaws. The target is applied cryptography: wrong primitives, bad defaults, nonce/IV handling, missing authentication, weak randomness, padding and signature oracles, key management, TLS/JWT configuration, asymmetric parameter validation and post-quantum (PQC) integration. The output is an evidence-backed answer, not a list of regex hits.

Why this matters: Lazar et al. found that 83% of cryptographic CVEs are misuse of libraries inside applications, not bugs in the libraries. Most of the value of an audit is in tracing how keys, nonces and error paths flow through *application* code, which is exactly where pattern-matching tools are weakest and an agent that reads code is strongest.

## When to use

Use this skill for: "review the crypto in this repo", "is this encryption implementation secure", "audit our JWT/TLS/key handling", "check this PR that touches encryption", "does this code have a padding oracle", "compare the spec with what the code does", "is our PQC/hybrid key exchange done right", and any pentest or secure-code-review scoped around cryptography. Also use it when a general code review stumbles on `Cipher`, `AES`, `RSA`, `HMAC`, `jwt`, `ssl`, `random` or key material — switch into this workflow for that part.

Not for: theoretical cryptanalysis of correctly implemented primitives (AES, SHA-2, ML-KEM are not "attackable" by auditing), writing exploit code, or breaking ciphertext you don't own.

## Size the job first

The same method runs at four sizes. Pick one before doing anything else, because the most common way this skill disappoints is by answering a quick question with a forty-page audit.

| The person asked for | Do | Deliver |
|---|---|---|
| **A quick verdict** — one PR, one file, a snippet, "is this safe to merge?" | Read the code and its pinned dependencies. Run the inventory only if there is more than a handful of files. Trace the two or three things that matter. One or two tests where behaviour depends on a library version or runtime. | The verdict in the first sentence. Then findings as a short list: severity, confidence, `file:line`, one sentence of why, the fix as code. About a page. No template, no appendices. Offer the fuller write-up instead of producing it. |
| **A full audit** — a repo, a service, "review before we ship" | All five phases below. | The full report from `templates/report.md`. |
| **A focused review** — one component, or a design document with a small implementation, written up for someone else to read | The five phases at small scale: the claims table, the traces, the design questions of Phase 2, and tests only where behaviour depends on a library version or the runtime. Fixes are corrected lines, not a rebuilt module. | Two to four pages with the report template's sections: summary, document-vs-code table, full blocks for High and above, one table for the rest, what the document leaves unspecified. |
| **A design review** — a document only | Extract the claims, answer the design questions of Phase 2 for each construction, check the answers against the catalogs, list what the document leaves unspecified. | Design-level findings with proposed wording. There is nothing to test. |

When in doubt, do the smaller one and say what the next size up would add.

## Operating rules

These rules exist because the failure mode of an LLM auditor is a fluent, plausible report that is wrong in both directions: inventing findings from surface patterns, and missing the real bug because it never traced the data flow.

1. **Every finding needs evidence.** File, line, and the data-flow trace that makes it exploitable (where the key/nonce/error comes from, where it goes). A `grep` hit is a *candidate*, not a finding.
2. **Classify confidence explicitly:** `Confirmed` (traced, and tested where behaviour is in question), `Probable` (traced, not tested, or trace incomplete), `Needs review` (pattern seen, could not trace). Never upgrade a candidate without doing the trace.
3. **Trace before you judge.** For nonces/IVs: generation → storage → scope (per key? per process? per replica?) → persistence across restarts. For keys: origin → derivation → every place the key is used (one key in two modes or two primitives is its own finding, S-27) → storage → rotation. For error paths: does any observable difference (message, status, timing) depend on padding/MAC/signature validity? For anything that returns an error: is the error checked, or does a failure fall through as success (T-02)?
4. **Verify with code, not by eye.** Counting iterations, computing key sizes, checking whether a nonce is 96 bits, checking a modulus or exponent: run it. Never claim a test passed or failed without having run it.
5. **What a library does by default is a hypothesis until you run it on the version the project pins.** Defaults change between releases, and so do the catalogs' own claims about them. Measured while building this skill: an HS256 token signed with an empty key is accepted by PyJWT 2.8.0 and rejected by 2.15.0; PyJWT 1.7.1 rejects an `alg: none` token in every form tried, although "old PyJWT accepts none" is widely repeated; OpenSSL builds with implicit rejection return a random plaintext instead of an error for bad PKCS#1 v1.5 padding; Node accepts a 4-byte GCM tag unless `authTagLength` is set. Each of these changed a finding. A finding that hinges on library behaviour is `Probable` until tested on the pinned version (see Phase 4).
6. **No exploit code.** Confirmation is a property test whose failure is the evidence: tamper a ciphertext and expect rejection; submit `r=s=0` and expect rejection; compare two error responses. Do not write padding-oracle decryptors, Bleichenbacher solvers, plaintext- or key-recovery tooling, or token forgers aimed at anything but the project's own test harness. A test may call the project's own functions with inputs any outsider has (a public key, a tampered ciphertext) and assert that they are rejected; that is not an exploit. The report proves the condition exists without handing over the weapon.
7. **Name false positives you dismissed.** The report lists candidates that were investigated and closed, with the reason. This makes the next audit faster and keeps the auditor honest.
8. **Severity follows the threat model.** Default assumes a remote attacker. Say which assumption each severity depends on ("Critical if the attacker can submit ciphertexts; Medium if only trusted services can").
9. **Date the standards.** NIST/BSI/IETF guidance changes. `references/standards-status.md` carries the date it was last verified; if an item there is marked "verify", check it before citing it in a client-facing report. Without web access, cite it as "per the snapshot of <date>, not re-verified".
10. **Keep secrets out of everything you write.** Report the *presence* of a hard-coded key (file, line, a prefix like `AKIA…` or `-----BEGIN`), never its value. This covers the report, test files, script output you attach and messages to the person. Tests read secrets from the target at run time instead of copying them. Before handing anything over, run `scripts/leak_scan.py <target> <outputs>`; it must come back clean.

## Workflow (full audit)

Skipping triage and verification is how audits produce 40 "high severity" findings that are all ECB-in-a-test-fixture. Skipping the report until the end is how audits run out of time with nothing to hand over: start the report file as soon as triage is done and fill it in as verification proceeds.

### Phase 0 — Scope and setup

- Confirm the target: a repo path, a PR diff, a set of files, a design doc, or a combination.
- Settle the threat model (ask, or decide and state it if the person is away): who can submit ciphertexts/tokens, who sees error messages, is there physical access, is this FIPS/BSI-constrained, is PQC migration in scope.
- If there is documentation (design doc, security spec, README claims), read it *first* and extract every cryptographic claim: "AES-256-GCM with random 96-bit nonces", "passwords hashed with bcrypt", "TLS 1.2+", "keys rotated quarterly". These become hypotheses to check against code. Spec-vs-code mismatches are among the highest-value findings.
- Note the pinned dependency versions (`requirements.txt`, `package-lock.json`, `go.sum`, `pom.xml`, `Cargo.lock`, `*.csproj`). You will need them in Phase 4.

### Phase 1 — Inventory

```bash
python3 scripts/crypto_inventory.py <path> --out inventory.json --md inventory.md
bash scripts/run_semgrep.sh <path> semgrep.json        # if semgrep is available (pip install semgrep)
```

The inventory walks the tree, identifies crypto API usage per language (Python, Java/Kotlin, JS/TS, Go, C/C++, C#, Rust, PHP, Ruby, plus nginx/Apache/OpenSSL/SSH/Kubernetes/.env config), tags each hit with a catalog ID (`S-03`, `C-01`, …), marks test/fixture paths, and lists the cryptographic claims found in documentation. Read `inventory.md` and build the map: which components do crypto, with which primitives, through which libraries, and where it is concentrated.

Both tools are *candidate generators* tuned for recall. Expect most hits to be closed in triage.

### Phase 2 — Sweep (catalog-driven)

Read the code the inventory pointed at, with the matching catalog *entries* open. The catalogs are about 100 KB together: do not read them end to end. Open `references/catalog-index.md` (one line per entry, with file and line number), then read only the entries whose IDs the inventory and Semgrep reported, plus the entries of the priority list below that fit the primitives present. Which file holds what:

| Area present in inventory | Read |
|---|---|
| Symmetric encryption, modes, IV/nonce, AEAD, MAC, hashing, KDF, RNG, key reuse | `references/catalog-symmetric.md` |
| RSA, DH, ElGamal, ECDSA/EdDSA/ECDH, signatures, certificates | `references/catalog-asymmetric.md` |
| ML-KEM, ML-DSA, SLH-DSA, hybrids (X25519MLKEM768), LMS/XMSS | `references/catalog-pqc.md` |
| TLS config, JWT/JOSE, key storage, ASN.1/PEM parsing, HPKE, who can create a valid message, unchecked errors, timing | `references/catalog-config.md` |
| Any language-specific API question ("is this default ECB?") | `references/apis-by-language.md` |

Each entry says what to look for, what to trace, how to confirm, the common false positives and what to cite. Work in this order (frequency × impact in real audits):

1. Nonce/IV reuse in AEAD and CTR (S-06/07/09/10)
2. Certificate/hostname validation disabled (C-01)
3. Signature and token verification that is lax, algorithm-confused or fail-open, and formats anyone can forge because nothing authenticates the sender (A-06, A-21, A-22, C-02–C-05, C-11, T-02)
4. Unauthenticated encryption and bad MAC composition (S-05, S-16–S-20)
5. One key used in more than one mode, primitive or protocol (S-27, S-17)
6. Non-cryptographic RNG feeding keys/IVs/tokens (S-14, S-15)
7. Keys in the repository, derived from strings, or defaulting to empty/placeholder values (C-07, S-02, C-04)
8. Fast hashes for passwords (S-25)
9. RSA PKCS#1 v1.5 decryption / Marvin (A-04)
10. Missing validation of asymmetric inputs (A-15, A-18, P-03)
11. Timing side channels visible in application code (T-01, S-18)
12. Obsolete algorithms and sizes (S-01, A-01, C-06)

The IDs the tools report are a floor, not the list. Tools see calls; they cannot see how the pieces are composed, and the most serious findings are often composition flaws in code where every call is individually correct. So for every construction, also answer these **design questions** (and read the entries they point to):

1. Who is able to create something the receiver accepts? Is there any secret or signature an outsider does not have? (C-11, A-17)
2. What exactly does the MAC, tag or signature cover — IV, headers, recipient list, version, algorithm identifiers? (S-17, S-20)
3. What does the sender of a bad message learn from the failure: which check failed, how long it took? (S-16, S-22, A-04)
4. What stops an older or weaker variant being replayed or selected (versioning, downgrade, rollback)?
5. Where does every key, nonce and random value come from, and what happens when it is missing or repeats? (S-07, S-09, S-14, C-04)
6. Which keys serve more than one purpose? (S-27, A-12)
7. What does the documentation leave for the implementer to guess?

Then one pass *across* findings: do two individually modest issues combine (a zero-IV CBC path and an AEAD on the same key; a committed private key and a verifier that trusts it; a discarded error and a nil cipher)? No pattern rule finds combinations.

### Phase 3 — Triage

Most candidates die here, and that is correct. Close a candidate when:
- It is in test code, fixtures, examples or vendored dependencies with no production path (but note it: test code that teaches ECB gets copied).
- The dangerous value is nominal (`RSA/ECB/OAEPWithSHA-256AndMGF1Padding` — the "ECB" is a JCA naming quirk).
- The trace shows the precondition is absent (nonce from a CSPRNG per message and the key rotates well under 2^32 messages; no attacker-controlled ciphertext reaches the decryptor).
- The data is not security-relevant (MD5 for a cache key, `Math.random` for a UI animation).

Keep a candidate when the trace shows the precondition is present, or when you cannot complete the trace (then it is `Needs review`, with a note on what is missing).

Now create the report file with the findings table and the traces you already have. Give each surviving finding its ID here and keep it: tests and attachments are named after IDs, and renumbering at report time breaks the cross-references.

### Phase 4 — Verification

Spend verification effort where it changes the answer.

**Reading settles it — no test needed.** A hard-coded key, `verify=False`, `random.choice` building a token, `sha256(secret + data)`, a 1024-bit key, `ssl_protocols TLSv1`: the code is the evidence. Mark these `Confirmed` with the trace and move on. (For keys and certificates, `scripts/key_analyzer.py` is the reading.)

**Behaviour is in question — test it.** Whether nonces actually repeat across calls, tenants or restarts; what the pinned library accepts (JWT algorithms, empty keys, short tags, off-curve points); whether two error paths are distinguishable; whether a comparison leaks timing; whether a default is what the catalog says. Write a short property test against the project's real code path (recipes in `references/verification-tests.md`), and use:
- `scripts/nonce_audit.py` on collected nonces/IVs (duplicates, length, structure).
- `scripts/jwt_inspect.py` on sample tokens (alg, `kid`/`jku`/`jwk`, missing `exp`/`aud`).
- `scripts/timing_check.py` to demonstrate a large timing difference (early-exit loop, work done only on one path). For `==`/`memcmp` on a secret the code is the finding; do not use a quiet measurement to clear it.

**Test on the versions the project pins, not the ones that happen to be installed.** Install the pinned versions into an isolated directory and point the test at it; never change the project's or the system's packages in place:

```bash
pip install --target "$SCRATCH/pinned" 'PyJWT==1.7.1'      # then: PYTHONPATH="$SCRATCH/pinned" pytest tests/crypto
npm ci --prefix "$SCRATCH/pinned-js"                        # with the project's package-lock.json copied in
```

State in the evidence which version each test ran on. If the pinned version cannot be installed (offline, the person asked for no network, private registry), leave the finding `Probable` and give the exact command that would confirm it. If the project pins nothing (no lockfile, no `go.mod`) or pins a range, one run on whatever is installed can hide a finding: test on the installed version and on an older release the project could resolve to, especially across a behaviour change the catalog mentions; name each version, and report the missing pin as its own finding. More practicalities in recipe T0 of `references/verification-tests.md`.

**Code with no callers in the audited tree** (helpers, libraries): the flaw can be `Confirmed` while reachability is unknown. Say once that severity assumes each function is used for what its name says, and give conditional severities ("High; Critical if untrusted users can obtain the output").

Order: Critical and High first. Stop when further tests would not change a severity or a confidence level.

**With sub-agents available and a large target:** split Phases 2–3 by component, then give Phase 4 to a *separate* verifier that receives the finding text and the repo but not the sweeper's reasoning. A verifier that has not seen the argument is much better at noticing the argument is wrong. Prompts in `references/agentic-workflow.md`. On a small target, do it yourself but re-read each finding as if someone else wrote it.

### Phase 5 — Report

Use `templates/report.md` and `templates/finding.md`. Write in the language the person is using; keep attack names, API identifiers and standard names in English. Order findings by severity, then confidence. Include:

- Executive summary: what was audited, what was found, the three things to fix first.
- Scope, threat model, what was *not* covered, library versions tested.
- Spec-vs-code table when documentation existed, with four possible statuses: matches; matches but the claim itself is unsound; diverges; not verifiable. Plus the list of what the documentation leaves unspecified.
- **Critical and High findings: one full block each** — trace, a few lines of evidence, impact, remediation as corrected code. One finding per root cause, listing every affected location (five clients with validation disabled are one finding).
- **Medium, Low and Informational findings: one table row each** — location, what is wrong, the fix. Promote a row to a full block only when the fix is not obvious.
- Investigated and closed (one line each).
- Evidence by reference: name the attached test or script output; do not paste logs, the inventory, rubric text or catalog prose into the report.

Length follows the number of serious findings. A target of a few hundred lines with a dozen serious findings is a report of roughly 400–600 lines, and a focused review of one small component is 150–250; a report three times that size is repeating itself and will not be read. Severity rubric and wording: `references/severity-and-reporting.md`.

Remediation is the corrected lines in the project's own library, run against the same property test when that takes minutes. Describe a redesign in a few lines and offer it; do not build and test a replacement module unless asked.

The report is for the client: no mention of this skill, its catalog IDs or its scripts. Name each flaw class in plain words with its CWE, and give re-run instructions that work with the attached tests alone.

Before delivering: run `scripts/leak_scan.py <target> <report and attachments>`. Deliver the report as a document the person will keep, and attach the tests so the fixes can be regression-checked.

## Bundled scripts

Python 3, standard library plus `cryptography` (`pip install cryptography`). `--help` on each. Paths are relative to this skill's folder (the directory containing `SKILL.md`); use absolute paths when running from the target repo.

| Script | Purpose |
|---|---|
| `scripts/crypto_inventory.py` | Multi-language crypto usage inventory with catalog tags and documentation claims. JSON + Markdown. Secret literals are masked in its output. |
| `scripts/run_semgrep.sh` + `scripts/semgrep/*.yaml` | Semgrep rules for Python, Java/Kotlin, JS/TS, Go, C#, C/C++, tagged with catalog IDs. Runs offline in seconds. |
| `scripts/key_analyzer.py` | PEM/DER/JWK/SSH keys and certificates: size, exponent, curve, signature algorithm, private key matching a public key in the tree, shared moduli, batch-GCD, ROCA fingerprint, Wiener and Fermat checks (`--fermat 10000`), repeated ECDSA `r`. |
| `scripts/nonce_audit.py` | Nonce/IV sample analysis: duplicates, length, zero values, counter structure, per-byte entropy. Exit code 1 on duplicates. |
| `scripts/jwt_inspect.py` | JWT/JWS/JWE header and claim inspection. Never verifies with a guessed secret. |
| `scripts/timing_check.py` | Timing comparison of a function or command over two input classes, in repeated rounds; reports a leak only when it is consistent and above a minimum effect size. For showing large differences, not for clearing code. |
| `scripts/leak_scan.py` | Checks that the report, tests and attached output do not reproduce the target's keys, tokens or passwords. |
| `scripts/build_index.py` | Regenerates `references/catalog-index.md` after a catalog is edited. |

## Reference index

- `references/catalog-index.md` — one line per catalog entry and per test recipe, with file and line; start here.
- `references/catalog-symmetric.md` — S-01…S-27: algorithms, modes, IV/nonce, RNG, AEAD composition, oracles, hash/MAC/KDF, key reuse across modes.
- `references/catalog-asymmetric.md` — A-01…A-26: RSA, ElGamal, DH, ECC, EdDSA, signatures.
- `references/catalog-pqc.md` — P-01…P-09: ML-KEM/ML-DSA/SLH-DSA/FN-DSA/HQC, hybrids, stateful hash signatures, migration checklist.
- `references/catalog-config.md` — C-01…C-11, T-01, T-02: TLS, JWT/JOSE, key management, parsing, HPKE, unauthenticated public-key encryption, timing, unchecked errors.
- `references/apis-by-language.md` — dangerous defaults and correct APIs per language and config format.
- `references/standards-status.md` — dated snapshot of NIST/BSI/IETF status and deprecation timelines.
- `references/verification-tests.md` — property-test recipes per finding class.
- `references/severity-and-reporting.md` — severity rubric, confidence levels, wording.
- `references/agentic-workflow.md` — parallel sweep and independent verifier prompts.

## Two short examples

**Quick verdict.** "Is this cookie helper OK?" — thirty lines of Node that encrypt a session cookie.
Read it and `package-lock.json`. Three things matter. The IV is `crypto.randomBytes(12)` per call: fine, closed. The key is `process.env.COOKIE_KEY || "dev-key"`: a deployment without the variable encrypts with a public key (C-04). The decrypt path takes the tag from the cookie and calls `createDecipheriv("aes-256-gcm", key, iv)` with no `authTagLength`: test on the project's Node version whether a 4-byte tag is accepted (S-08). Answer, in under a page: "Not yet. High, Confirmed: fallback key at `cookie.js:7` — throw at start-up when the variable is missing. Medium, Confirmed on Node 22: a cookie with a tag truncated to 4 bytes decrypts — pass `{ authTagLength: 16 }`. The IV handling is correct." Attach the one test. Offer a wider review instead of producing it.

**Full audit.** "Review the crypto in our Go ingestion service before the pen test."
1. Inventory: `chacha20poly1305.New` in `seal/seal.go`, HMAC webhook verification in `hooks/verify.go`, a `tls.Config`, key loaded from KMS in `main.go`. The design doc claims "nonces never repeat" and "keys rotated monthly".
2. Sweep, reading only the entries the inventory named (S-09, S-10, S-18, C-06, C-08): the nonce is a 4-byte instance id followed by an 8-byte counter kept in memory; the instance id comes from an environment variable that defaults to 0. The webhook MAC is compared with `bytes.Equal`. The key is fetched once at start-up and nothing rotates it.
3. Triage: `tls.Config{MinVersion: tls.VersionTLS12}` is closed. The nonce, the comparison and the rotation claim survive.
4. Verify: a test that seals one message, restarts the sealer and seals again shows the same nonce twice (S-09/S-10, Critical, Confirmed on the module's pinned dependencies). The comparison and the missing rotation are settled by reading. A cross-check finds nothing that combines.
5. Report: spec-vs-code table (both claims diverge), one full block for the Critical finding, two table rows for the rest, one closed candidate, the test attached, leak scan clean. About two pages.
