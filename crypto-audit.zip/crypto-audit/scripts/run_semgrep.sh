#!/usr/bin/env bash
# run_semgrep.sh — run the bundled crypto-audit Semgrep rules over a target.
#
# Usage: bash run_semgrep.sh <target-path> [output.json] [--sarif]
#   Prints a compact table (rule, catalog id, location) and writes full JSON (default: semgrep-crypto.json).
#   Offline: metrics and the version check are disabled and no rule registry is contacted.
#   Install semgrep if missing: pip install semgrep   (or: brew install semgrep)
set -euo pipefail
TARGET="${1:?target path required}"
OUT="${2:-semgrep-crypto.json}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RULES="$HERE/semgrep"

if ! command -v semgrep >/dev/null 2>&1; then
  echo "semgrep not found. Install with: pip install semgrep" >&2
  exit 2
fi

export SEMGREP_SEND_METRICS=off
CONFIGS=()
for f in "$RULES"/*.yaml; do CONFIGS+=(--config "$f"); done

SARIF=""
if [[ "${3:-}" == "--sarif" ]]; then SARIF="--sarif"; fi

semgrep scan --metrics=off --disable-version-check --no-git-ignore --quiet "${CONFIGS[@]}" --json -o "$OUT" "$TARGET" || true
if [[ -n "$SARIF" ]]; then
  semgrep scan --metrics=off --disable-version-check --no-git-ignore --quiet "${CONFIGS[@]}" --sarif -o "${OUT%.json}.sarif" "$TARGET" || true
fi

python3 - "$OUT" "$TARGET" <<'EOF'
import json, sys, os
out, target = sys.argv[1], os.path.abspath(sys.argv[2])
d = json.load(open(out))
errs = d.get("errors", [])
res = d.get("results", [])
print(f"semgrep: {len(res)} candidate(s), {len(errs)} error(s) -> {out}")
for e in errs[:5]:
    print("  error:", str(e.get("message", e))[:200].replace("\n", " "))
rows = []
for r in res:
    cid = r["check_id"].split(".")[-1]
    cat = (r.get("extra", {}).get("metadata", {}) or {}).get("catalog", "")
    sev = r.get("extra", {}).get("severity", "")
    path = os.path.relpath(r["path"], target) if r["path"].startswith(target) else r["path"]
    rows.append((sev, str(cat), cid, f"{path}:{r['start']['line']}"))
order = {"ERROR": 0, "WARNING": 1, "INFO": 2}
for sev, cat, cid, loc in sorted(rows, key=lambda x: (order.get(x[0], 9), x[3])):
    print(f"  {sev:7} {cat:14} {cid:34} {loc}")
print("Remember: these are candidates. Trace and confirm per references/catalog-*.md before reporting.")
EOF
