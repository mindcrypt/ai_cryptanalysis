#!/usr/bin/env python3
"""
nonce_audit.py — Analyse a sample of nonces / IVs / salts / tokens collected from a system.

Input: a text file with one value per line (hex, base64, or base64url; blank lines and '#' comments ignored),
or --from-json FILE --field name to pull a field out of a JSON array of objects.

Reports:
  * count, distinct values, DUPLICATES (with first/second line numbers)   -> S-06/S-07/S-09/S-10 confirmation
  * length distribution (bytes) and whether it matches the expected AEAD nonce size (--expect-bytes)
  * all-zero / low-Hamming-weight values
  * sequential/counter structure: values that are consecutive integers (big- or little-endian), and the
    fraction of values that differ from their predecessor by a small delta
  * byte-position entropy (positions that are constant across the sample => fixed-field + counter layout,
    which is fine for deterministic construction but means the counter must be persistent per key)
  * shared-prefix detection (e.g., instance id prefix)
  * birthday-bound estimate for random nonces of the observed length

Output is JSON on stdout (also written to --json FILE when given). Exit code 1 if duplicates are found
(so it can gate a test), else 0. Values are printed in hex: do not feed it secrets, only nonces/IVs/salts.

Usage:
  python3 nonce_audit.py nonces.txt [--expect-bytes 12] [--json out.json]
"""
from __future__ import annotations
import argparse, base64, json, math, re, sys
from collections import Counter

HEX_RX = re.compile(r"^[0-9a-fA-F]+$")
B64_RX = re.compile(r"^[A-Za-z0-9+/]+={0,2}$")
B64U_RX = re.compile(r"^[A-Za-z0-9_-]+={0,2}$")

def decode(v: str) -> bytes | None:
    v = v.strip()
    if not v:
        return None
    if v.startswith("0x"):
        v = v[2:]
    if HEX_RX.match(v) and len(v) % 2 == 0:
        return bytes.fromhex(v)
    try:
        if B64_RX.match(v):
            return base64.b64decode(v + "=" * (-len(v) % 4))
        if B64U_RX.match(v):
            return base64.urlsafe_b64decode(v + "=" * (-len(v) % 4))
    except Exception:
        pass
    return v.encode()

def shannon_entropy(counter: Counter, total: int) -> float:
    return -sum((c / total) * math.log2(c / total) for c in counter.values()) if total else 0.0

def analyse(values: list[bytes], expect_bytes: int | None, linenos: list[int] | None = None) -> dict:
    n = len(values)
    res: dict = {"count": n}
    if n == 0:
        res["error"] = "no values parsed"
        return res
    # duplicates
    first_seen: dict[bytes, int] = {}
    dups = []
    occurrences: dict[bytes, list[int]] = {}
    for idx, v in enumerate(values):
        where = linenos[idx] if linenos else idx + 1
        occurrences.setdefault(v, []).append(where)
        if v not in first_seen:
            first_seen[v] = where
    for v, where in occurrences.items():
        if len(where) > 1:
            dups.append({"value_hex": v.hex(), "times": len(where), "lines": where[:20]})
    res["distinct"] = len(first_seen)
    res["duplicates"] = dups[:50]
    res["duplicate_count"] = len(dups)                      # number of distinct values that repeat
    res["duplicates_truncated"] = len(dups) > 50
    res["repeated_values_total"] = sum(d["times"] - 1 for d in dups)
    res["line_numbers_are"] = "file line numbers" if linenos else "1-based position in the input list"
    # lengths
    lens = Counter(len(v) for v in values)
    res["lengths_bytes"] = dict(sorted(lens.items()))
    if expect_bytes is not None:
        res["unexpected_length_count"] = sum(c for l, c in lens.items() if l != expect_bytes)
    # zero / low weight
    res["all_zero_count"] = sum(1 for v in values if not any(v))
    res["low_hamming_weight_count"] = sum(1 for v in values if 0 < sum(bin(b).count("1") for b in v) <= max(2, len(v)))
    # per-position entropy for the dominant length
    L = max(lens, key=lens.get)
    same_len = [v for v in values if len(v) == L]
    pos_entropy = []
    constant_positions = []
    for i in range(L):
        c = Counter(v[i] for v in same_len)
        h = shannon_entropy(c, len(same_len))
        pos_entropy.append(abs(round(h, 2)))
        if len(c) == 1 and len(same_len) > 3:
            constant_positions.append(i)
    res["dominant_length"] = L
    res["byte_position_entropy_bits"] = pos_entropy
    res["constant_byte_positions"] = constant_positions
    res["mean_position_entropy_bits"] = round(sum(pos_entropy) / L, 2) if L else 0
    # shared prefix
    if len(same_len) > 1:
        pre = 0
        while pre < L and all(v[pre] == same_len[0][pre] for v in same_len):
            pre += 1
        res["shared_prefix_bytes"] = pre
    # sequential structure (keep input order)
    def ints(endian):
        return [int.from_bytes(v, endian) for v in same_len]
    seq = {}
    for endian in ("big", "little"):
        xs = ints(endian)
        deltas = [b - a for a, b in zip(xs, xs[1:])]
        if deltas:
            small = sum(1 for d in deltas if 0 < d <= 16)
            seq[endian] = {"consecutive_fraction": round(sum(1 for d in deltas if d == 1) / len(deltas), 3),
                           "small_positive_delta_fraction": round(small / len(deltas), 3),
                           "monotonic_increasing": all(d > 0 for d in deltas)}
    res["sequential_structure"] = seq
    # random-nonce birthday estimate
    bits = L * 8
    res["birthday_estimate"] = {
        "nonce_bits": bits,
        "p_collision_at_sample_size": f"{(n * (n - 1) / 2) / (2 ** bits):.3e}" if bits < 1024 else "n/a",
        "messages_for_p_2e-32": f"2^{(bits - 1 - 32) / 2:.0f}" if bits > 33 else "n/a",
        "nist_sp800_38d_random_iv_limit_per_key": "2^32 invocations" if bits == 96 else "n/a (96-bit GCM rule)",
    }
    # verdicts
    verdicts = []
    if dups:
        verdicts.append(f"DUPLICATE nonces found ({len(dups)}): under one key this is S-06/S-07/S-10 (Critical for AEAD/CTR).")
    if res["all_zero_count"]:
        verdicts.append(f"{res['all_zero_count']} all-zero value(s): static/zero IV candidate (S-04/S-07).")
    if expect_bytes is not None and res.get("unexpected_length_count"):
        verdicts.append(f"{res['unexpected_length_count']} value(s) are not {expect_bytes} bytes (S-08 if GCM).")
    if constant_positions and len(constant_positions) >= L // 2:
        verdicts.append(f"{len(constant_positions)} of {L} byte positions are constant: fixed-field + counter layout. Fine if the counter persists per key across restarts/instances (S-09); otherwise reuse is likely.")
    mono = any(s.get("monotonic_increasing") for s in seq.values())
    if mono and n > 5:
        verdicts.append("Values are monotonically increasing in input order: counter-based nonce. Verify persistence and uniqueness across processes (S-09).")
    if not dups and res["mean_position_entropy_bits"] > 6.5 and not constant_positions:
        verdicts.append("Looks random with high per-byte entropy; no duplicates in sample. " + ("For an AEAD/CTR nonce, still enforce per-key message limits (S-08/S-09)." if L == 12 else "For a CBC IV, unpredictability per message is the requirement (S-04); for a salt, uniqueness per secret."))
    if not verdicts:
        verdicts.append("No obvious structure detected; sample may be too small to conclude.")
    res["verdicts"] = verdicts
    return res

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file", nargs="?")
    ap.add_argument("--from-json", metavar="FILE")
    ap.add_argument("--field", default="nonce")
    ap.add_argument("--expect-bytes", type=int)
    ap.add_argument("--json", metavar="OUT")
    a = ap.parse_args(argv)
    values: list[bytes] = []
    linenos: list[int] | None = None
    if a.from_json:
        arr = json.load(open(a.from_json))
        for o in arr:
            v = o.get(a.field) if isinstance(o, dict) else None
            if v is not None:
                d = decode(str(v))
                if d is not None:
                    values.append(d)
    elif a.file:
        linenos = []
        for n, line in enumerate(open(a.file, "r", encoding="utf-8", errors="ignore"), 1):
            line = line.split("#", 1)[0].strip()
            if not line:
                continue
            d = decode(line)
            if d is not None:
                values.append(d); linenos.append(n)
    else:
        ap.error("give a file or --from-json")
    res = analyse(values, a.expect_bytes, linenos)
    if a.json:
        json.dump(res, open(a.json, "w"), indent=2)
    print(json.dumps(res, indent=2))
    return 1 if res.get("duplicate_count") else 0

if __name__ == "__main__":
    sys.exit(main())
