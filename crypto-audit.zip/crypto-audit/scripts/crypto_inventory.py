#!/usr/bin/env python3
"""
crypto_inventory.py — Multi-language inventory of cryptographic API usage with catalog tags.

Walks a source tree, finds crypto-relevant lines (primitives, libraries, config directives,
key material markers), and tags each hit with:
  - category   : what kind of thing it is (cipher, mode, hash, kdf, rng, rsa, ecc, tls, jwt, key-material, pqc, config)
  - catalog    : catalog IDs (S-03, C-01, ...) when the pattern maps to a known flaw class (candidate, not finding)
  - severity_if_true : the catalog severity if the candidate turns out real
  - test_path  : True when the file looks like test/fixture/example code

It is deliberately recall-oriented. Everything it prints is a CANDIDATE for Phase 2/3 triage.

Usage:
  python3 crypto_inventory.py <path> [--out inventory.json] [--md inventory.md] [--flagged] [--quiet]
    (default)  candidates with a catalog tag, documentation claims, and untagged crypto usage
    --flagged  only lines with a catalog tag
    --exclude DIR[,DIR]   extra directory names to skip

Exit code 0 always (it's an inventory, not a gate).
"""
from __future__ import annotations
import argparse, json, os, re, sys
from collections import Counter, defaultdict
from dataclasses import dataclass, asdict, field

SKIP_DIRS = {".git", ".hg", ".svn", "node_modules", "vendor", "third_party", "thirdparty", "dist", "build",
             "target", ".venv", "venv", "__pycache__", ".tox", ".mypy_cache", ".idea", ".vscode", "bower_components",
             ".gradle", "Pods", "DerivedData", ".next", ".nuxt", "coverage", "site-packages"}
TEST_HINT = re.compile(r"(^|/)(tests?|spec|specs|__tests__|testdata|fixtures?|examples?|samples?|mocks?|e2e|bench(mark)?s?)(/|$)|_test\.(py|go|rb|js|ts)$|\.test\.(js|ts|jsx|tsx)$|\.spec\.(js|ts|rb)$|Tests?\.(java|kt|cs|swift)$", re.I)

EXT_LANG = {
    ".py": "python", ".pyi": "python",
    ".java": "java", ".kt": "kotlin", ".kts": "kotlin", ".scala": "scala", ".groovy": "groovy",
    ".js": "javascript", ".mjs": "javascript", ".cjs": "javascript", ".jsx": "javascript",
    ".ts": "typescript", ".tsx": "typescript",
    ".go": "go",
    ".c": "c", ".h": "c", ".cc": "cpp", ".cpp": "cpp", ".cxx": "cpp", ".hpp": "cpp", ".hh": "cpp", ".m": "objc", ".mm": "objc",
    ".cs": "csharp", ".vb": "vbnet",
    ".rs": "rust",
    ".php": "php",
    ".rb": "ruby",
    ".swift": "swift",
    ".pl": "perl", ".pm": "perl",
    ".ex": "elixir", ".exs": "elixir", ".erl": "erlang",
    ".dart": "dart",
    ".sh": "shell", ".bash": "shell", ".zsh": "shell",
    ".conf": "config", ".cnf": "config", ".cfg": "config", ".ini": "config", ".toml": "config",
    ".yaml": "config", ".yml": "config", ".json": "config", ".xml": "config", ".properties": "config",
    ".env": "config", ".tf": "config", ".hcl": "config", ".plist": "config",
    ".md": "doc", ".rst": "doc", ".txt": "doc", ".adoc": "doc",
}
CONFIG_BASENAMES = {"nginx.conf", "httpd.conf", "ssl.conf", "sshd_config", "ssh_config", "openssl.cnf", "haproxy.cfg",
                    "java.security", "Dockerfile", "docker-compose.yml", "docker-compose.yaml", ".env", "web.config",
                    "application.properties", "application.yml", "application.yaml", "settings.py", "config.py",
                    "network_security_config.xml", "Info.plist", "Caddyfile", "traefik.yml", "envoy.yaml"}
KEY_FILE_EXT = {".pem", ".key", ".p12", ".pfx", ".jks", ".keystore", ".der", ".crt", ".cer", ".pub", ".ppk", ".asc", ".gpg", ".jwk"}

@dataclass
class Rule:
    name: str
    pattern: str
    category: str
    catalog: list[str] = field(default_factory=list)
    severity: str = ""
    langs: tuple = ()          # empty = any
    note: str = ""
    flags: int = 0
    file_requires: str = ""    # regex that must match somewhere in the file
    file_excludes: str = ""    # regex that must not match anywhere in the file
    fn: object = None          # optional post-filter: fn(line, window_text) -> bool (window = this line + 3 before)
    _rx: re.Pattern | None = None
    def rx(self) -> re.Pattern:
        if self._rx is None:
            self._rx = re.compile(self.pattern, self.flags)
        return self._rx

SECRETISH = {"mac", "macs", "hmac", "tag", "tags", "sig", "sigs", "signature", "signatures", "digest", "checksum", "hash", "hashed",
             "token", "tokens", "secret", "secrets", "apikey", "otp", "totp", "password", "passwd", "pwd", "passphrase", "pin", "csrf", "nonce"}
_IDENT_RX = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
_CAMEL_RX = re.compile(r"[A-Z]+(?![a-z])|[A-Z]?[a-z]+|\d+")
_LITERAL_RX = re.compile(r"^(None|null|nil|undefined|NULL|true|false|True|False|-?\d[\w.]*|b?(['\"]).*\2|len\(.*|.*\.length|.*\.size\(\)|typeof .*|EOF)$")
_OPERAND_L = re.compile(r"([\w.\]\[\"']+(?:\([^()]*\))?(?:\.\w+\([^()]*\))?)\s*$")
_OPERAND_R = re.compile(r"^\s*([\w.\]\[\"'!-]+(?:\([^()]*\))?(?:\.\w+\([^()]*\))?)")
_CMP_OP = re.compile(r"(===|!==|==|!=)")
_CMP_FN = re.compile(r"(Arrays\.equals|bytes\.Equal|bytes\.Compare|\bmemcmp|\bstrn?cmp|\bstrcasecmp|\.SequenceEqual|\.equals|\.Equals|\.compareTo|\.equalsIgnoreCase)\s*\(")
_BARE_RETURN_CMP = re.compile(r"^\s*return\s+[\w.]+\s*(===?|!==?)\s*[\w.]+\s*;?\s*\}?\s*$")

def looks_secret(text: str) -> bool:
    for ident in _IDENT_RX.findall(text):
        for part in ident.split("_"):
            for seg in _CAMEL_RX.findall(part):
                if seg.lower() in SECRETISH:
                    return True
    return False

def secret_compare(line: str, window: str) -> bool:
    """Operator or function comparison where an operand, or the enclosing function, looks secret-derived."""
    code = line.split("//", 1)[0] if "://" not in line else line
    if _CMP_FN.search(code):
        return looks_secret(window)
    for m in _CMP_OP.finditer(code):
        left = _OPERAND_L.search(code[:m.start()]); right = _OPERAND_R.search(code[m.end():])
        if not left or not right:
            continue
        l, r = left.group(1).strip(), right.group(1).strip()
        if _LITERAL_RX.match(l) or _LITERAL_RX.match(r):
            continue
        if looks_secret(l) or looks_secret(r):
            return True
    if _BARE_RETURN_CMP.match(code):
        return looks_secret(window.replace(line, ""))
    return False

R = Rule
I = re.I
RULES: list[Rule] = [
    # ---------- Key material / secrets ----------
    R("pem-private-key", r"-----BEGIN (RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY-----", "key-material", ["C-07"], "Critical", note="Private key block present"),
    R("aws-access-key", r"\b(AKIA|ASIA)[0-9A-Z]{16}\b", "key-material", ["C-07"], "Critical"),
    R("generic-secret-assign", r"(\b[\w.]*(SECRET|PASSWORD|PASSWD|PASSPHRASE|PRIVATE_?KEY|MASTER_?KEY|SIGNING_?KEY|ENCRYPTION_?KEY|ENC_?KEY|AES_?KEY|HMAC_?KEY|API_?KEY|JWT_?KEY|secret_key_base)\w*['\"]?\s*[:=]\s*|\b(KEY|SECRET|key|secret)\s*(:\s*[\w\[\]<>]+\s*)?=\s*)(b?['\"][^'\"]{6,}['\"]|(bytes\.fromhex|bytearray\.fromhex|unhexlify|b64decode|base64\.\w+|Buffer\.from|hex::decode|hex!|Convert\.FromBase64String|Base64\.getDecoder\(\)\.decode|hex\.DecodeString|Hex\.decode\w*|Encoding\.\w+\.GetBytes)\s*\(\s*b?['\"][^'\"]{6,}['\"])", "key-material", ["C-07", "C-04", "S-02"], "Critical", note="Key or secret literal assigned in code/config", flags=I),
    R("env-secret-value", r"^\s*(export\s+)?[A-Z0-9_]*(SECRET|PASSWORD|PASSWD|PRIVATE_KEY|API_KEY|ENCRYPTION_KEY|MASTER_KEY|SIGNING_KEY|TOKEN)[A-Z0-9_]*\s*=\s*[^\s'\"#$<{][^\s#]{5,}", "key-material", ["C-07", "C-04"], "Critical", langs=("config", "shell"), note="Secret value in an env/config file"),
    R("slack-github-stripe-token", r"\b(xox[baprs]-[0-9A-Za-z-]{10,}|ghp_[0-9A-Za-z]{36}|gh[ousr]_[0-9A-Za-z]{36}|sk_live_[0-9a-zA-Z]{20,})\b", "key-material", ["C-07"], "Critical"),
    R("string-key-literal", r"(SecretKeySpec\s*\(\s*\"|new\s+SecretKeySpec\s*\(\s*\"[^\"]*\"\.getBytes|aes\.Key\s*=\s*Encoding\.|AES\.new\s*\(\s*b?['\"]|createCipheriv\s*\([^,]+,\s*['\"][^'\"]{8,}['\"]|aes\.NewCipher\s*\(\s*\[\]byte\s*\(\s*\")", "cipher", ["S-02", "C-07"], "High", note="Key built from a string literal"),

    # ---------- Obsolete algorithms ----------
    R("des-3des", r"(\b(DESede|TripleDES|3DES|DES3|TDEA|desede)\b|des-ede3|des_ede3|EVP_des_|\"DES\"|'DES'|\bDES\.Create|\bDES\.new\b|crypto/des|MCRYPT_3DES|MCRYPT_DES|des\.New(TripleDES)?Cipher)", "cipher", ["S-01"], "Medium/High", flags=I),
    R("rc4-rc2-blowfish", r"\b(RC4|ARCFOUR|ARC4|RC2|Blowfish|EVP_rc4|EVP_bf_|crypto/rc4|x/crypto/blowfish|MCRYPT_BLOWFISH|CAST5|IDEA\b)", "cipher", ["S-01"], "Medium/High", flags=I),
    R("md5-sha1-usage", r"\b(MD5|SHA-?1|sha1|md5|HmacSHA1|SHA1withRSA|MD5withRSA|EVP_md5|EVP_sha1|crypto/md5|crypto/sha1|Digest::MD5|Digest::SHA1|hashlib\.md5|hashlib\.sha1|createHash\(\s*['\"](md5|sha1)['\"])\b", "hash", ["S-24", "S-23"], "Medium/High", note="Context decides: signature/integrity/password = finding; cache/etag = no", flags=I),
    R("crc-as-integrity", r"\b(crc32|crc16|adler32|zlib\.crc32|CRC32)\b.*\b(integrity|checksum|verify|signature|auth)", "hash", ["S-24"], "Medium", flags=I),

    # ---------- Modes ----------
    R("java-cipher-aes-bare", r"Cipher\.getInstance\(\s*\"(AES|DES|DESede|Blowfish|RC2)\"\s*\)", "mode", ["S-03"], "Medium/High", note="JCA bare 'AES' = AES/ECB/PKCS5Padding"),
    R("java-cipher-rsa-bare", r"Cipher\.getInstance\(\s*\"RSA\"\s*\)", "rsa", ["A-04"], "High", note="JCA bare 'RSA' = PKCS#1 v1.5"),
    R("ecb-mode", r"(/ECB/|MODE_ECB|modes\.ECB|CipherMode\.ECB|EVP_aes_\d+_ecb|aes-\d+-ecb|\"ecb\"|'ecb'|MCRYPT_MODE_ECB|AES_encrypt\s*\(|AES_decrypt\s*\(|\bECB\b)", "mode", ["S-03"], "Medium/High", note="RSA/ECB/OAEP is nominal (FP)"),
    R("cbc-mode", r"(/CBC/|MODE_CBC|modes\.CBC|CipherMode\.CBC|EVP_aes_\d+_cbc|aes-\d+-cbc|NewCBCEncrypter|NewCBCDecrypter|AES-CBC|MCRYPT_MODE_CBC|\bcbc\b)", "mode", ["S-05", "S-22"], "High", note="CBC: is a MAC verified before decryption (EtM)? how do padding errors surface? where does the IV come from (S-04)?", flags=I),
    R("ctr-ofb-cfb", r"(/CTR/|/OFB/|/CFB/|MODE_CTR|MODE_OFB|MODE_CFB|modes\.CTR|modes\.OFB|modes\.CFB|NewCTR\(|NewOFB\(|NewCFB|aes-\d+-ctr|AES-CTR|CipherMode\.CFB|CipherMode\.OFB)", "mode", ["S-05", "S-06"], "High", note="Stream modes: integrity + nonce uniqueness"),
    R("xts-mode", r"(/XTS|modes\.XTS|xts\.NewCipher|aes-\d+-xts|XTS-AES)", "mode", ["S-12"], "Medium", flags=I),
    R("gcm-mode", r"(/GCM/|MODE_GCM|modes\.GCM|AESGCM|AesGcm|NewGCM\b|NewGCMWith|aes-\d+-gcm|AES-GCM|EVP_aes_\d+_gcm|GCMParameterSpec|Aes\d+Gcm|AES_GCM|\bGCM\b)", "aead", ["S-07", "S-08", "S-09"], "Critical", note="Trace nonce origin/scope; tag length; per-key limits"),
    R("gcm-short-tag", r"(GCMParameterSpec\s*\(\s*(32|64|96|104|112|120)\b|NewGCMWithTagSize\s*\(|tagLength\s*:\s*(32|64|96|104|112|120)\b|tagSizeInBytes\s*:\s*(4|8|12|13|14|15)\b|authTagLength\s*:\s*(4|8|12|13|14|15)\b|tag_length\s*=\s*(4|6|8|10|12|14)\b)", "aead", ["S-08"], "Medium", note="Tag < 128 bits (S-11 if the mode is CCM). Go accepts 12-16 bytes only (others error: T-02); SunJCE accepts 96-128 bits only"),
    R("gcm-nonstd-nonce", r"NewGCMWithNonceSize\s*\([^,]+,\s*(?!12\b)\d+", "aead", ["S-08"], "Medium"),
    R("chacha", r"(ChaCha20|chacha20|XChaCha20|Poly1305|crypto_aead_chacha20poly1305|crypto_secretbox|secretbox)", "aead", ["S-10"], "Critical", note="Nonce uniqueness; raw ChaCha20 without Poly1305?"),
    R("ccm-mode", r"(AESCCM|/CCM/|aes-\d+-ccm|MODE_CCM|EVP_aes_\d+_ccm|EVP_CTRL_CCM_SET_TAG)", "aead", ["S-11"], "Medium"),
    R("siv-mode", r"(AESSIV|AESGCMSIV|AES-GCM-SIV|MODE_SIV|aes-gcm-siv|gcm_siv)", "aead", ["S-13", "S-21"], "Low/Medium", flags=I),
    R("zero-or-static-iv", r"(var\s+\w*(nonce|iv|Nonce|IV)\w*\s*=\s*make\(\[\]byte|\b\w*(IV|iv|Iv|NONCE|nonce|Nonce)\w*\s*=\s*new\s+byte\s*\[\s*\d+\s*\]|IvParameterSpec\s*\(\s*new\s+byte\s*\[\s*\d+\s*\]\s*\)|iv\s*=\s*b?['\"][^'\"]{8,}['\"]|IV\s*=\s*new\s+byte\s*\[\s*16\s*\]|iv\s*:=\s*make\(\[\]byte,\s*\d+\)|nonce\s*:=\s*make\(\[\]byte,\s*\d+\)|nonce\s*=\s*b?['\"][^'\"]{6,}['\"]|\.iv\s*=\s*['\"]|b['\"]\\x00['\"]\s*\*\s*(12|16)|bytes\(\s*(12|16)\s*\)|\[0u8;\s*(12|16)\]|Buffer\.alloc\(\s*(12|16)\s*\)|new\s+byte\[(12|16)\]\s*;)", "iv", ["S-04", "S-06", "S-07"], "High", note="Static/zero IV or nonce candidate — trace whether it is filled from a CSPRNG before use"),
    R("iv-equals-key", r"\b(iv|IV|nonce)\s*=\s*(key|KEY|secret|aesKey|aes_key)\b", "iv", ["S-04"], "High"),
    R("node-createCipher-deprecated", r"crypto\.createCipher\s*\(|\bcreateCipher\s*\(|createDecipher\s*\(", "mode", ["S-04", "S-25"], "High", note="Deprecated: MD5-derived key, fixed IV", langs=("javascript", "typescript")),
    R("cryptojs-passphrase", r"CryptoJS\.AES\.(encrypt|decrypt)\s*\([^,]+,\s*['\"]", "cipher", ["S-05", "S-25"], "High", note="CryptoJS passphrase mode: EVP_BytesToKey(MD5), CBC, no MAC"),

    # ---------- RNG ----------
    R("py-random", r"\brandom\.(random|randint|randrange|choice|choices|getrandbits|bytes|uniform|shuffle|sample)\s*\(", "rng", ["S-14"], "High", langs=("python",), note="Only a finding if it feeds keys/IVs/tokens/salts"),
    R("py-random-seed", r"\brandom\.seed\s*\(", "rng", ["S-15"], "High", langs=("python",)),
    R("java-util-random", r"\b(new\s+java\.util\.Random\s*\(|new\s+Random\s*\(|Math\.random\s*\(|ThreadLocalRandom\.current)", "rng", ["S-14"], "High", langs=("java", "kotlin", "scala", "groovy")),
    R("java-securerandom-seeded", r"(new\s+SecureRandom\s*\(\s*[^)\s][^)]*\)|SecureRandom\.getInstance\(\s*\"SHA1PRNG\"|\.setSeed\s*\()", "rng", ["S-15"], "High", langs=("java", "kotlin", "scala")),
    R("js-math-random", r"\bMath\.random\s*\(", "rng", ["S-14"], "High", langs=("javascript", "typescript", "dart")),
    R("go-math-rand", r"\"math/rand(/v2)?\"|\bmath\.rand\b|\brand\.(Intn|Int63|Int31|Int|Uint32|Uint64|Read|Seed|New|Perm|Shuffle|Float64)\b", "rng", ["S-14"], "High", langs=("go",), file_requires=r"\"math/rand", note="math/rand is not a CSPRNG (only a finding if it feeds keys/IVs/tokens)"),
    R("c-rand", r"(\b(rand|random|srand|srandom|rand_r|drand48|lrand48|srand48)\s*\(|\b(mt19937|mt19937_64|default_random_engine|minstd_rand|ranlux\d+)\b)", "rng", ["S-14", "S-15"], "High", langs=("c", "cpp", "objc")),
    R("c-srand-time", r"srand\s*\(\s*\(?\s*(unsigned\s*)?\)?\s*time\s*\(", "rng", ["S-15"], "High", langs=("c", "cpp")),
    R("csharp-random", r"\bnew\s+Random\s*\(|\bGuid\.NewGuid\(\)\.ToString\(\)\s*(;|\))", "rng", ["S-14"], "High", langs=("csharp", "vbnet"), note="Guid as secret token?"),
    R("rust-weak-rng", r"\b(SmallRng|seed_from_u64|StdRng::from_seed|fastrand::|Xorshift|Pcg32)\b", "rng", ["S-14", "S-15"], "High", langs=("rust",)),
    R("php-weak-rng", r"\b(rand|mt_rand|uniqid|lcg_value|str_shuffle|array_rand|mt_srand|srand)\s*\(", "rng", ["S-14"], "High", langs=("php",)),
    R("ruby-weak-rng", r"\b(rand\s*\(|Random\.new|Random\.rand|\.shuffle\b)", "rng", ["S-14"], "High", langs=("ruby",)),
    R("rand-bytes-unchecked", r"RAND_bytes\s*\([^;]*\)\s*;", "rng", ["S-14"], "Medium", langs=("c", "cpp"), note="Return value must be checked (== 1)"),
    R("csprng-ok", r"\b(SecureRandom|secrets\.(token_bytes|token_hex|token_urlsafe|choice|randbelow)|os\.urandom|crypto\.randomBytes|crypto\.randomUUID|getRandomValues|crypto/rand|RandomNumberGenerator|OsRng|thread_rng|getrandom|arc4random|RAND_bytes|randombytes_buf|random_bytes|random_int|SecureRandom\.(hex|bytes|uuid|random_bytes)|BCryptGenRandom)\b", "rng", [], "", note="CSPRNG use (good) — for inventory"),

    # ---------- Hash / MAC / KDF / passwords ----------
    R("hmac-usage", r"\b(hmac|HMAC|Hmac|createHmac|hash_hmac|Mac\.getInstance|HMACSHA\d+|hmac\.New)\b", "mac", [], ""),
    R("hash-of-secret-concat", r"(sha256|sha1|md5|sha512|SHA256|SHA1|MD5)\s*\(\s*\(?\s*\w*(secret|SECRET|Secret|api_?key|signing_?key|hmac_?key|token)\w*\s*(\+|\.|,|\|\||&)", "mac", ["S-23"], "High", note="H(secret||data) — length extension (a salt+password hash is S-25, not this)"),
    R("non-constant-compare", r"(hmac\.compare_digest|timingSafeEqual|MessageDigest\.isEqual|hmac\.Equal|ConstantTimeCompare|CRYPTO_memcmp|FixedTimeEquals|hash_equals|secure_compare|fixed_length_secure_compare|ConstantTimeEq|sodium_memcmp)", "compare", [], "", note="Constant-time compare present (good) — inventory"),
    R("suspicious-compare", r"(===|!==|==|!=|Arrays\.equals|bytes\.Equal|bytes\.Compare|\bmemcmp|\bstrn?cmp|\bstrcasecmp|\.SequenceEqual|\.equals|\.Equals|\.compareTo|\.equalsIgnoreCase)", "compare", ["S-18", "T-01"], "Medium/High", note="Comparison of a MAC/signature/hash/token/password that is probably not constant-time", fn=secret_compare),
    R("password-fast-hash", r"(sha256|sha1|md5|sha512|SHA256|SHA1|MD5|SHA512|Sha256|hashlib\.\w+)\s*\([^)]*(password|passwd|pwd|pass\b)", "kdf", ["S-25"], "High", note="Fast hash on a password", flags=I),
    R("pbkdf2-low-iterations", r"(PBKDF2|pbkdf2|Pbkdf2|PBEKeySpec|Rfc2898DeriveBytes|PKCS5_PBKDF2_HMAC)\w*\s*\([^;)]*?\b(1|10|100|1000|2000|4096|5000|10000|20000|50000|65536|100000)\b", "kdf", ["S-25"], "High", note="PBKDF2 iterations look low (<600k for SHA-256)"),
    R("rfc2898-legacy-ctor", r"new\s+Rfc2898DeriveBytes\s*\(\s*[^,]+,\s*[^,)]+\s*\)", "kdf", ["S-25"], "High", langs=("csharp",), note="Legacy ctor: SHA-1, 1000 iterations"),
    R("bcrypt-low-cost", r"(gensalt\s*\(\s*(rounds\s*=\s*)?([4-9])\s*\)|GenerateFromPassword\s*\([^,]+,\s*([4-9])\s*\)|bcrypt::hash\s*\([^,]+,\s*([4-9])\s*\)|cost\s*[:=]>?\s*([4-9])\b|BCrypt\.(hashpw|gensalt)\s*\([^)]*?\b([4-9])\b)", "kdf", ["S-25"], "High", note="bcrypt cost < 10"),
    R("argon2-low-memory", r"(memory_cost|m_cost|memoryCost|MemorySize|memory)\s*[=:]\s*(\d{1,4})\b", "kdf", ["S-25"], "Medium", note="Argon2 memory < 19456 KiB? (check units)"),
    R("kdf-good", r"\b(argon2|Argon2|scrypt|Scrypt|bcrypt|BCrypt|PASSWORD_ARGON2ID|PASSWORD_BCRYPT|password_hash)\b", "kdf", [], "", note="Password KDF present — check parameters"),
    R("hkdf", r"\b(HKDF|hkdf|HKDFExpand|HKDF-Expand|HKDF-Extract|hkdf\.New|hkdf\.Expand)\b", "kdf", ["S-26"], "Medium", note="Check info/salt distinct per purpose"),

    # ---------- RSA ----------
    R("rsa-no-padding", r"(RSA/ECB/NoPadding|RSA_NO_PADDING|OPENSSL_NO_PADDING|RSAEncryptionPadding\.Pkcs1\b.*false|encrypt\([^)]*['\"]RAW['\"]|pow\s*\(\s*\w+\s*,\s*e\s*,\s*n\s*\))", "rsa", ["A-02"], "High"),
    R("rsa-pkcs1v15-decrypt", r"(RSA/ECB/PKCS1Padding|PKCS1v15\(\)|RSA_PKCS1_PADDING|OPENSSL_PKCS1_PADDING|RSAEncryptionPadding\.Pkcs1\b|Pkcs1v15Encrypt|DecryptPKCS1v15|RSAES-PKCS1-V1_5|RSA1_5|rsa-1_5|PKCS1Padding)", "rsa", ["A-04"], "High", note="RSA PKCS#1 v1.5 encryption padding in use (this line may be the encrypt side): the oracle risk is wherever the matching decrypt happens"),
    R("rsa-oaep-sha1-default", r"OAEPWithSHA-256AndMGF1Padding\"\s*\)(?![^;]*OAEPParameterSpec)", "rsa", ["A-05"], "Low", note="JCA: MGF1 defaults to SHA-1 unless OAEPParameterSpec is set (interop, not a break)"),
    R("rsa-small-key", r"(initialize\s*\(\s*(512|768|1024)\b|key_size\s*=\s*(512|768|1024)\b|genrsa\s+(512|768|1024)\b|RSA\.Create\s*\(\s*(512|768|1024)\s*\)|GenerateKey\s*\([^,]+,\s*(512|768|1024)\s*\)|generate\s*\(\s*(512|768|1024)\s*\)|rsa:(512|768|1024)\b|modulusLength\s*:\s*(512|768|1024)\b|\bbits\s*[:=]\s*(512|768|1024)\b)", "rsa", ["A-01"], "High"),
    R("rsa-small-e", r"(public_exponent\s*=\s*3\b|BigInteger\.valueOf\s*\(\s*3\s*\)|publicExponent\s*:\s*new\s+Uint8Array\(\[\s*3\s*\]\)|\bRSA_3\b|-3\b.*genrsa|exponent\s*[:=]\s*3\b)", "rsa", ["A-03"], "Medium"),
    R("rsa-blinding-off", r"(RSA_blinding_off|RSA_FLAG_NO_BLINDING)", "rsa", ["A-11"], "High"),
    R("rsa-public-decrypt-manual-verify", r"(RSA_public_decrypt|rsa\.VerifyPKCS1v15\s*\(|public_decrypt\s*\()", "rsa", ["A-06"], "Critical", note="Manual PKCS#1 v1.5 verification? Check full EM compare"),
    R("evp-verifyfinal-bool", r"if\s*\(\s*!?\s*EVP_(Digest)?VerifyFinal(_ex)?\s*\(", "rsa", ["A-06"], "High", langs=("c", "cpp"), note="Returns -1 on error; must compare == 1"),
    R("rsa-pss-salt-zero", r"(salt_length\s*=\s*0\b|saltLength\s*:\s*0\b|PSSParameterSpec\s*\([^)]*,\s*0\s*,|SaltLength\s*=\s*0\b)", "rsa", ["A-07"], "Low"),

    # ---------- DH / ECC ----------
    R("dh-small-params", r"(DHParameterSpec|dhparam|DH_generate_parameters|generate_parameters\s*\(\s*generator\s*=\s*2\s*,\s*key_size\s*=\s*(512|768|1024)|ephemeralDHKeySize\s*=\s*(512|768|1024))", "dh", ["A-14", "A-15"], "High", note="Check prime size ≥2048 (BSI 3000) and RFC 7919 group"),
    R("dh-compute-raw", r"(DH_compute_key\s*\(|big\.Int\)\.Exp\s*\(|\.Exp\(\s*\w+,\s*\w+,\s*p\s*\)|\.modPow\s*\()", "dh", ["A-15", "A-17"], "High", note="Public-value validation present?"),
    R("ecdh-point-unchecked", r"(EC_POINT_oct2point|oct2point|ECPublicKeySpec\s*\(\s*new\s+ECPoint|EllipticCurvePublicNumbers\s*\(|elliptic\.Unmarshal|decodePoint\s*\(|\.setPublicKey\s*\(\s*peer|crypto_scalarmult\s*\()", "ecc", ["A-18", "A-24"], "Critical", note="Static key? Is on-curve/subgroup check performed?"),
    R("ecdsa-sign", r"(ECDSA|ecdsa|SHA256withECDSA|secp256k1|P-256|prime256v1|secp256r1|secp384r1|P-384|secp521r1|P-521|ES256|ES384|ES512)\b", "ecc", ["A-19", "A-21", "A-20"], "Critical", note="Nonce source (RFC 6979?), r/s range checks, library version"),
    R("ed25519", r"\b(Ed25519|ed25519|EdDSA|Ed448|crypto_sign|nacl\.sign|SigningKey|ExpandedSecretKey)\b", "ecc", ["A-23"], "Medium", note="Separate pk argument to sign()? Strict verification?"),
    R("x25519", r"\b(X25519|x25519|Curve25519|curve25519|crypto_scalarmult|ECDH-ES)\b", "ecc", ["A-24", "A-18"], "Medium", note="All-zero output check; JWE ECDH-ES epk validation"),
    R("weak-curve", r"\b(secp112|secp128|secp160|secp192|prime192v1|P-192|sect\d+|B-163|K-163|brainpoolP160|brainpoolP192|secp224|P-224)\b", "ecc", ["A-25"], "Medium"),
    R("explicit-curve-params", r"(explicitCurve|ECParameters\s*::=|EC_GROUP_new_curve_GFp|explicit_parameters|ECCurve\.CreateFromValue|CurveType\.EXPLICIT)", "ecc", ["A-22"], "Critical"),
    R("ecdsa-k-manual", r"\b(k\s*=\s*random|nonce\s*=\s*random|k\s*=\s*rand|k\s*=\s*secrets|k\s*=\s*int\.from_bytes\(os\.urandom)", "ecc", ["A-19"], "Critical", note="Hand-rolled ECDSA nonce"),

    # ---------- PQC ----------
    R("pqc-prestandard-ids", r"\b(kyber512|kyber768|kyber1024|Kyber|dilithium2|dilithium3|dilithium5|Dilithium|falcon-?512|falcon-?1024|Falcon|sphincs|SPHINCS|hqc-?\d+|X25519Kyber768Draft00|0x6399|pqcrypto-kyber|pqcrypto-dilithium|OQS_KEM_alg_kyber|OQS_SIG_alg_dilithium)\b", "pqc", ["P-01", "P-02"], "Medium/High", note="Round-3 / pre-standard identifier"),
    R("pqc-final-ids", r"\b(ML-?KEM-?(512|768|1024)|ML-?DSA-?(44|65|87)|SLH-?DSA|FN-?DSA|X25519MLKEM768|SecP256r1MLKEM768|SecP384r1MLKEM1024|mlkem|MLKEM|ml_kem|MLDSA|ml_dsa|crypto/mlkem|0x11EC|0x11ec)\b", "pqc", ["P-03", "P-04", "P-08"], "Medium", note="FIPS 203/204 use: input checks, implicit rejection, combiner order"),
    R("stateful-hbs", r"\b(LMS|HSS|XMSS|XMSS\^?MT|lms_|xmss_|hss_|SP800-208|sp800_208)\b", "pqc", ["P-07"], "Critical", note="Stateful signatures: index persistence"),
    R("hybrid-xor-combine", r"(shared\w*\s*\^=?\s*\w*shared|ss1\s*\^\s*ss2|secret\w*\s*\^\s*\w*secret|xor\s*\(\s*\w*(kem|mlkem|x25519)\w*,)", "pqc", ["P-08"], "High", note="XOR combiner for hybrid secrets"),

    # ---------- TLS / certificate validation ----------
    R("py-verify-false", r"(verify\s*=\s*False|_create_unverified_context|check_hostname\s*=\s*False|CERT_NONE|disable_warnings\s*\(\s*InsecureRequestWarning)", "tls", ["C-01"], "Critical", langs=("python",)),
    R("java-trust-all", r"(checkServerTrusted\s*\([^)]*\)\s*(throws\s+\w+\s*)?\{\s*\}|ALLOW_ALL_HOSTNAME_VERIFIER|hostnameVerifier\s*\(\s*\([^)]*\)\s*->\s*true|verify\s*\([^)]*\)\s*\{\s*return\s+true|TrustAllCerts|trustAllCerts|X509TrustManager\s*\(\s*\)\s*\{)", "tls", ["C-01"], "Critical", langs=("java", "kotlin", "scala", "groovy")),
    R("node-reject-unauth", r"(rejectUnauthorized\s*:\s*false|NODE_TLS_REJECT_UNAUTHORIZED\s*=?\s*['\"]?0|checkServerIdentity\s*:\s*\(\s*\)\s*=>|checkServerIdentity\s*:\s*function\s*\(\s*\)\s*\{\s*\})", "tls", ["C-01"], "Critical", langs=("javascript", "typescript", "config", "shell")),
    R("go-insecure-skip", r"InsecureSkipVerify\s*:\s*true", "tls", ["C-01"], "Critical", langs=("go",)),
    R("c-verify-none", r"(SSL_VERIFY_NONE|CURLOPT_SSL_VERIFYPEER\s*,\s*0|CURLOPT_SSL_VERIFYHOST\s*,\s*0|MBEDTLS_SSL_VERIFY_NONE|MBEDTLS_SSL_VERIFY_OPTIONAL|WOLFSSL_VERIFY_NONE)", "tls", ["C-01"], "Critical"),
    R("csharp-cert-callback-true", r"(ServerCertificateCustomValidationCallback\s*=\s*\([^)]*\)\s*=>\s*true|ServerCertificateValidationCallback\s*\+?=\s*\([^)]*\)\s*=>\s*true|DangerousAcceptAnyServerCertificateValidator|RemoteCertificateValidationCallback\s*\(\s*\([^)]*\)\s*=>\s*true)", "tls", ["C-01"], "Critical", langs=("csharp",)),
    R("rust-danger-certs", r"(danger_accept_invalid_certs\s*\(\s*true|danger_accept_invalid_hostnames\s*\(\s*true|NoCertificateVerification|dangerous\(\)\.set_certificate_verifier)", "tls", ["C-01"], "Critical", langs=("rust",)),
    R("php-ruby-verify-off", r"(CURLOPT_SSL_VERIFYPEER\s*=>\s*false|CURLOPT_SSL_VERIFYHOST\s*=>\s*(false|0)|['\"]verify_peer['\"]\s*=>\s*false|verify_mode\s*=\s*OpenSSL::SSL::VERIFY_NONE|verify:\s*false)", "tls", ["C-01"], "Critical", langs=("php", "ruby", "config")),
    R("android-ios-ats", r"(cleartextTrafficPermitted\s*=\s*\"true\"|<certificates\s+src=\"user\"|NSAllowsArbitraryLoads|usesCleartextTraffic\s*=\s*\"true\")", "tls", ["C-01"], "High"),
    R("tls-old-versions", r"(SSLContext\.getInstance\(\s*\"(SSL|SSLv3|TLSv1|TLSv1\.1)\"\s*\)|ssl_protocols[^;\n]*\bTLSv1(\.1)?\b(?![.\d])|SSLProtocol[^\n]*\b(all|TLSv1(\.1)?)\b(?![.\d])|PROTOCOL_TLSv1\b(?!_)|PROTOCOL_TLSv1_1\b|PROTOCOL_SSLv\d|SSLv3|TLSv1_method|TLSv1_1_method|SslProtocols\.(Tls|Tls11|Ssl3)\b(?!2|3)|SecurityProtocolType\.(Tls|Tls11|Ssl3)\b(?!2|3)|MinVersion\s*:\s*tls\.VersionTLS1[01]\b|VersionSSL30|minVersion\s*:\s*['\"]TLSv1(\.1)?['\"]|TLS1_VERSION\b|TLS1_1_VERSION\b|ssl-min-ver\s+TLSv1(\.1)?\b(?![.\d])|MinProtocol\s*=\s*TLSv1(\.1)?\b(?![.\d])|tls-min-version\s*=\s*VersionTLS1[01]|TLSv1\.0)", "tls", ["C-06"], "Medium/High"),
    R("tls-weak-suites", r"(ssl_ciphers|SSLCipherSuite|CipherSuites|ciphers|CipherString|cipher_list|set_ciphers|cipherSuites)[^\n]*\b(RC4|3DES|DES-CBC3|NULL|EXPORT|EXP-|aNULL|eNULL|MD5|ADH|AECDH|kRSA|DES\b|SEED|CAMELLIA128-SHA\b|ALL\b|DEFAULT@SECLEVEL=0|TLS_RSA_WITH)", "tls", ["C-06"], "Medium/High", flags=I),
    R("ssh-weak", r"(Ciphers[^\n]*\b(3des-cbc|arcfour|aes\d+-cbc|blowfish-cbc|cast128-cbc)\b|MACs[^\n]*\b(hmac-md5|hmac-sha1\b|umac-64\b)|KexAlgorithms[^\n]*\b(diffie-hellman-group1-sha1|diffie-hellman-group14-sha1|diffie-hellman-group-exchange-sha1)\b|HostKeyAlgorithms[^\n]*\bssh-dss\b)", "tls", ["C-06", "A-14"], "Medium/High"),
    R("ssl-env-override", r"(NODE_TLS_REJECT_UNAUTHORIZED|PYTHONHTTPSVERIFY\s*=\s*0|GIT_SSL_NO_VERIFY|CURL_INSECURE|SSL_VERIFY\s*=\s*false)", "tls", ["C-01"], "High"),

    # ---------- JWT / JOSE ----------
    R("jwt-decode-noverify", r"(jwt\.decode\s*\([^)]*verify\s*=\s*False|verify_signature['\"]?\s*:\s*False|jwt\.decode\s*\(\s*[^,)]+\s*\)(?!\.)|jsonwebtoken\.decode|\bjwt\.decode\s*\(\s*token\s*\)|JWT\.decode\s*\([^)]*,\s*false|ParseUnverified|dangerous_insecure_decode|insecure_disable_signature_validation|RequireSignedTokens\s*=\s*false|Jwts\.parser\(\)[^;]*\.parse\s*\(|JWT\.decode\s*\(\s*\w+\s*\)\s*;)", "jwt", ["C-02"], "Critical", note="Decode without verification / unsigned accepted"),
    R("jwt-alg-none", r"(['\"]alg['\"]\s*:\s*['\"]none['\"]|algorithms\s*=\s*\[[^\]]*['\"]none['\"]|Algorithm\.none|alg=none|\bnone\b.*\balgorithms?\b)", "jwt", ["C-02"], "Critical", flags=I),
    R("jwt-mixed-algs", r"algorithms\s*[=:]\s*\[[^\]]*(HS\d{3})[^\]]*(RS\d{3}|ES\d{3}|PS\d{3}|EdDSA)[^\]]*\]|algorithms\s*[=:]\s*\[[^\]]*(RS\d{3}|ES\d{3}|PS\d{3}|EdDSA)[^\]]*(HS\d{3})[^\]]*\]", "jwt", ["C-03"], "Critical", note="HMAC and asymmetric algs allowed with one key"),
    R("jwt-decode-no-algs", r"jwt\.decode\s*\(\s*[^,]+,\s*[^,)]+\s*\)", "jwt", ["C-02", "C-03"], "High", langs=("python",), note="No algorithms allow-list: PyJWT 1.x trusts the algorithm named in the token (confusion candidate), PyJWT 2.x raises — test on the pinned version"),
    R("jwt-verify-no-algs", r"jwt\.verify\s*\(\s*[^,]+,\s*[^,)]+\s*\)", "jwt", ["C-03"], "High", langs=("javascript", "typescript"), note="jsonwebtoken: set algorithms"),
    R("jwt-header-keys", r"(header\s*\[\s*['\"](kid|jku|x5u|jwk)['\"]\s*\]|\.header\.(kid|jku|x5u|jwk)\b|getHeader\(\)\.get\(\s*\"(kid|jku|x5u|jwk)\"|\bjku\b|\bx5u\b)", "jwt", ["C-05"], "High", note="kid/jku/x5u/jwk used in key resolution — injection/SSRF/self-signed?"),
    R("jwt-validation-off", r"(ValidateAudience\s*=\s*false|ValidateIssuer\s*=\s*false|ValidateLifetime\s*=\s*false|RequireExpirationTime\s*=\s*false|verify_aud['\"]?\s*:\s*False|verify_exp['\"]?\s*:\s*False|ignoreExpiration\s*:\s*true|validate_exp\s*=\s*false|verify_iat['\"]?\s*:\s*False|verify_aud\s*:\s*false)", "jwt", ["C-05"], "High"),
    R("jwt-usage", r"\b(jsonwebtoken|PyJWT|python-jose|jose4j|jjwt|Jwts\.|com\.auth0\.jwt|golang-jwt|jwt-go|firebase/php-jwt|ruby-jwt|JwtSecurityTokenHandler|jwt\.(encode|sign|verify|decode)|jwtVerify|SignJWT)\b", "jwt", [], "", note="JWT library in use — inventory"),

    # ---------- Fail-open: defaulted secrets, discarded errors ----------
    R("secret-default-fallback", r"((os\.environ\.get|os\.getenv|getenv|env\.get|config\.get|settings\.get|getOrDefault|getProperty|ENV\.fetch|\benv)\s*\(\s*['\"][^'\"]*(SECRET|KEY|TOKEN|PASSW|SALT|PEPPER)[^'\"]*['\"]\s*,\s*b?['\"]|process\.env\.\w*(SECRET|KEY|TOKEN|PASSW|SALT)\w*\s*(\|\||\?\?)\s*['\"`]|ENV\[['\"][^'\"]*(SECRET|KEY|TOKEN|PASSW)[^'\"]*['\"]\]\s*\|\|\s*['\"]|getenv\(\s*['\"][^'\"]*(SECRET|KEY|TOKEN|PASSW)[^'\"]*['\"]\s*\)\s*\?:\s*['\"])", "key-material", ["C-04"], "Critical", note="Secret read with a literal fallback: unset variable => empty/public key (fail-open)", flags=I),
    R("go-discarded-crypto-error", r",\s*_\s*:?=\s*(aes\.NewCipher|des\.New\w*Cipher|cipher\.New\w+|chacha20poly1305\.New\w*|rsa\.\w+|ecdsa\.\w+|ecdh\.\w+|ed25519\.GenerateKey|x509\.\w+|hkdf\.\w+|tls\.LoadX509KeyPair|pem\.Decode)\s*\(", "error-handling", ["T-02"], "Medium/High", langs=("go",), note="Error from a crypto call discarded: a nil cipher panics on first use, or a failure passes as success"),
    R("go-rand-read-unchecked", r"(^\s*(rand\.Read|io\.ReadFull\(rand\.Reader)\s*\(?|,\s*_\s*:?=\s*(rand\.Read|rand\.Int|rand\.Prime|io\.ReadFull)\s*\()", "error-handling", ["T-02"], "High", langs=("go",), file_requires=r"\"crypto/rand\"", note="crypto/rand error not checked: on failure the buffer is not random"),
    R("c-final-unchecked", r"^\s*(EVP_DecryptFinal(_ex)?|EVP_CipherFinal(_ex)?|EVP_(Digest)?VerifyFinal(_ex)?|EVP_DigestVerify|EVP_PKEY_verify|EVP_PKEY_derive|X509_verify_cert|RAND_priv_bytes)\s*\(", "error-handling", ["T-02", "S-19"], "High", langs=("c", "cpp", "objc"), note="Return value of a verifying/finalising call not used"),
    R("swallowed-crypto-exception", r"catch\s*\(\s*[^)]*(GeneralSecurityException|BadPaddingException|AEADBadTagException|InvalidKeyException|SignatureException|CryptographicException|IllegalBlockSizeException)[^)]*\)\s*\{\s*(return\b[^;]*;|\}|//)", "error-handling", ["T-02", "S-22"], "Medium/High", note="Crypto exception swallowed or turned into a return value on the same line — check what the caller receives"),

    # ---------- Misc / generic ----------
    R("openssl-legacy-provider", r"(OSSL_PROVIDER_load\s*\([^,]*,\s*\"legacy\"|-provider\s+legacy|legacy_sect|activate\s*=\s*1\s*#\s*legacy)", "config", ["S-01"], "Medium"),
    R("java-security-disabled-algs", r"jdk\.(tls|certpath|jar)\.disabledAlgorithms\s*=", "config", ["C-06"], "Medium", note="Check nothing weak was re-enabled"),
    R("seclevel-zero", r"SECLEVEL=0|SECLEVEL=1\b", "config", ["C-06"], "Medium/High"),
    R("crypto-lib-import", r"\b(from\s+cryptography|import\s+cryptography|Crypto\.Cipher|Cryptodome|javax\.crypto|java\.security|org\.bouncycastle|crypto/aes|crypto/cipher|crypto/rsa|crypto/ecdsa|crypto/ed25519|crypto/ecdh|x/crypto|require\(\s*['\"]crypto['\"]\)|from\s+['\"]crypto['\"]|System\.Security\.Cryptography|openssl/evp\.h|openssl/rsa\.h|openssl/ec\.h|sodium\.h|mbedtls/|wolfssl/|ring::|aes_gcm::|rsa::|ed25519_dalek|x25519_dalek|chacha20poly1305::|OpenSSL::Cipher|OpenSSL::PKey|openssl_encrypt|sodium_crypto|libsodium|tink|Tink|nacl|tweetnacl|node-forge|crypto-js|CryptoJS|@noble/|elliptic\b|jsrsasign|pycryptodome|pynacl|liboqs|oqs\b|pqcrypto)\b", "library", [], "", note="Crypto library import — inventory"),
    R("key-wrap", r"\b(AESWrap|AES-KW|aes_wrap|KeyWrap|RFC3394|kwp|KWP)\b", "cipher", [], "", note="Key wrapping (good) — inventory"),
    R("hpke", r"\b(HPKE|hpke|DHKEM|SetupBaseS|SetupBaseR|sealed_box|crypto_box_seal)\b", "aead", ["C-10"], "Medium"),
    R("asn1-manual", r"\b(asn1\.|ASN1_|pyasn1|parse_der|parseDER|der_decode|BERDecode|asn1js|asn1crypto)\b", "parsing", ["C-09"], "High", note="Custom ASN.1 handling"),
    R("kms-usage", r"\b(kms\.(Encrypt|Decrypt|GenerateDataKey|generate_data_key|encrypt|decrypt)|KeyManagementServiceClient|SecretManagerServiceClient|secretsmanager|AWS::KMS|aws_kms_key|google_kms|azure\.keyvault|KeyVaultClient|Vault\.|vault\.read|hvac\.)\b", "key-mgmt", [], "", note="KMS/secret manager usage (good) — inventory"),
]

CATEGORY_ORDER = ["key-material", "aead", "mode", "cipher", "iv", "rng", "kdf", "mac", "hash", "compare", "error-handling", "rsa", "dh", "ecc", "pqc", "tls", "jwt", "parsing", "config", "key-mgmt", "library", "doc-claim"]

# Documentation files: capture cryptographic *claims* for the spec-vs-code comparison (no catalog tag).
DOC_CLAIM_RX = re.compile(
    r"\b(AES|GCM|CBC|CTR|ChaCha|Poly1305|RSA|ECDSA|EdDSA|Ed25519|X25519|ECDH|Diffie|DH|HMAC|MAC|SHA-?\d+|MD5|bcrypt|scrypt|Argon2|PBKDF2|HKDF|"
    r"TLS\s*1\.\d|TLS|mTLS|JWT|JWE|JWS|ES256|RS256|HS256|PS256|nonces?|IVs?|salts?|keys?|\d{2,4}-bit|key rotation|rotated|KMS|HSM|FIPS|ML-KEM|ML-DSA|Kyber|Dilithium|"
    r"post-quantum|PQC|encrypt(ed|ion|s)?|decrypt(ed|ion|s)?|sign(ed|ature|atures|ing|s)?|verif(y|ies|ied|ication)|certificates?|pinning|u?random|generated|wrapped|unwraps?|"
    r"integrity|authenticat(ed|ion|es)|hash(ed|es)?|passwords?|tokens?|PKCS)\b", re.I)

IMPORT_LINE_RX = re.compile(r"^\s*(import\s|from\s+\S+\s+import|#include|require\(|const\s+\w+\s*=\s*require\(|use\s+[\w:]+;|using\s+[\w.]+;|@import)")
# rules whose hit on an import line is still a useful candidate (the import itself is the smell)
IMPORT_SIGNIFICANT = {"go-math-rand", "des-3des", "rc4-rc2-blowfish", "pqc-prestandard-ids", "pqc-final-ids", "stateful-hbs", "md5-sha1-usage"}

SEV_RANK = {"Critical": 0, "High": 1, "Medium/High": 2, "Medium": 3, "Low/Medium": 4, "Low": 5, "": 9}

@dataclass
class Hit:
    file: str
    line: int
    lang: str
    rule: str
    category: str
    catalog: list[str]
    severity_if_true: str
    test_path: bool
    note: str
    excerpt: str

SECRET_NAME = r"[\w.\-]*(?:SECRET|PASSWORD|PASSWD|PASSPHRASE|TOKEN|API_?KEY|PRIVATE_?KEY|MASTER_?KEY|SIGNING_?KEY|ENCRYPTION_?KEY|AES_?KEY|HMAC_?KEY|\bKEY\b|_KEY\b|secret_key_base)[\w.\-]*"
_ASSIGN_RX = re.compile(r"(" + SECRET_NAME + r"['\"]?\s*[:=]\s*b?)(['\"])([^'\"]*)\2", re.I)
_DEFAULT_RX = re.compile(r"((?:get|getenv|getOrDefault|getProperty|fetch|env)\s*\(\s*['\"]" + SECRET_NAME + r"['\"]\s*,\s*b?)(['\"])([^'\"]*)\2", re.I)
_OR_RX = re.compile(r"(" + SECRET_NAME + r"[\]\)'\"]*\s*(?:\|\||\?\?|\?:|\bor\b)\s*)(['\"`])([^'\"`]*)\2", re.I)
_ENVLINE_RX = re.compile(r"^(\s*(?:export\s+)?" + SECRET_NAME + r"\s*=\s*)([^\s'\"#][^\s#]*)", re.I)

def _mask(m: re.Match) -> str:
    return f"{m.group(1)}{m.group(2)}{'' if m.group(3) == '' else '[redacted]'}{m.group(2)}"

def redact(s: str, lang: str = "") -> str:
    """Never echo key material or secret literals into the inventory; keep whether a literal is empty."""
    s = re.sub(r"-----BEGIN[^-]*PRIVATE KEY-----.*", "-----BEGIN PRIVATE KEY----- [redacted]", s)
    # long base64/hex-looking literals are probably key material or tokens
    s = re.sub(r"(['\"])([A-Za-z0-9+/=_\-]{32,}|[0-9a-fA-F]{32,})\1", r"\1[redacted]\1", s)
    s = re.sub(r"\b(AKIA|ASIA)[0-9A-Z]{16}\b", r"\1[redacted]", s)
    s = re.sub(r"\b(xox[baprs]-)[0-9A-Za-z-]{10,}", r"\1[redacted]", s)
    s = re.sub(r"\b(ghp_|gh[ousr]_|sk_live_)[0-9A-Za-z]{20,}", r"\1[redacted]", s)
    for rx in (_DEFAULT_RX, _ASSIGN_RX, _OR_RX):
        s = rx.sub(_mask, s)
    if lang in ("config", "shell") and "[redacted]" not in s:
        s = _ENVLINE_RX.sub(lambda m: m.group(1) + "[redacted]", s)
    return s

def lang_for(path: str) -> str | None:
    base = os.path.basename(path)
    if base in CONFIG_BASENAMES:
        return "config" if not base.endswith(".py") else "python"
    ext = os.path.splitext(base)[1].lower()
    if ext in KEY_FILE_EXT:
        return "keyfile"
    if base.startswith(".env"):
        return "config"
    return EXT_LANG.get(ext)

def scan_file(path: str, rel: str, max_bytes: int) -> list[Hit]:
    lang = lang_for(path)
    if lang is None:
        return []
    hits: list[Hit] = []
    is_test = bool(TEST_HINT.search(rel))
    if lang == "keyfile":
        head = b""
        try:
            with open(path, "rb") as f:
                head = f.read(4096)
        except OSError:
            pass
        if b"PRIVATE KEY" in head:
            hits.append(Hit(rel, 1, lang, "pem-private-key", "key-material", ["C-07"], "Critical", is_test,
                            "Private key file in tree — rotate if live; check history", "-----BEGIN PRIVATE KEY----- [redacted]"))
        elif b"PUBLIC KEY" in head or b"CERTIFICATE" in head:
            hits.append(Hit(rel, 0, lang, "key-file", "key-material", [], "", is_test,
                            "Public key / certificate (run key_analyzer.py on it)", "[public material]"))
        else:
            hits.append(Hit(rel, 0, lang, "key-file", "key-material", ["C-07"], "Medium", is_test,
                            "Binary key container (.p12/.jks/.der…) — check contents and whether it is live", "[binary file]"))
        return hits
    try:
        if os.path.getsize(path) > max_bytes:
            return []
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except OSError:
        return []
    if lang == "doc":
        for i, line in enumerate(lines, 1):
            s = line.rstrip("\n")
            if DOC_CLAIM_RX.search(s) and len(s.strip()) > 12 and not s.lstrip().startswith("#"):   # headings are titles, not claims
                hits.append(Hit(rel, i, lang, "doc-claim", "doc-claim", [], "", is_test,
                                "Documentation claim — verify against code (spec-vs-code table)", redact(s.strip(), lang)[:240]))
        return hits
    text = "".join(lines)
    rules = [r for r in RULES if (not r.langs or lang in r.langs)
             and (not r.file_requires or re.search(r.file_requires, text))
             and (not r.file_excludes or not re.search(r.file_excludes, text))]
    in_docstring = False
    for i, line in enumerate(lines, 1):
        s = line.rstrip("\n")
        if len(s) > 2000:
            s = s[:2000]
        stripped = s.lstrip()
        if lang == "python":
            quotes = stripped.count('"""') + stripped.count("'''")
            if in_docstring:
                if quotes % 2 == 1:
                    in_docstring = False
                continue
            if quotes % 2 == 1:
                in_docstring = True
                continue
            if stripped.startswith("#"):
                continue
        if lang in ("java", "kotlin", "javascript", "typescript", "go", "c", "cpp", "csharp", "rust", "php", "swift", "scala", "dart") and (stripped.startswith("//") or stripped.startswith("*") or stripped.startswith("/*")):
            continue
        is_import = bool(IMPORT_LINE_RX.match(s))
        for r in rules:
            if r.rx().search(s) and (r.fn is None or r.fn(s, "".join(lines[max(0, i - 4):i]))):
                catalog, sev, note = list(r.catalog), r.severity, r.note
                if is_import and r.name not in IMPORT_SIGNIFICANT:
                    catalog, sev, note = [], "", (note + " (import)").strip()
                    cat = "library"
                else:
                    cat = r.category
                hits.append(Hit(rel, i, lang, r.name, cat, catalog, sev, is_test, note, redact(s.strip(), lang)[:240]))
    return hits

def walk(root: str, extra_skip: set[str], max_bytes: int) -> list[Hit]:
    hits: list[Hit] = []
    skip = SKIP_DIRS | extra_skip
    if os.path.isfile(root):
        return scan_file(root, os.path.basename(root), max_bytes)
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in skip and not d.startswith(".git")]
        for fn in filenames:
            p = os.path.join(dirpath, fn)
            rel = os.path.relpath(p, root)
            hits.extend(scan_file(p, rel, max_bytes))
    return hits

def summarize(hits: list[Hit]) -> dict:
    langs = Counter(h.lang for h in hits)
    cats = Counter(h.category for h in hits)
    catalog = Counter(c for h in hits for c in h.catalog)
    libs = Counter(h.excerpt.split()[0] if h.rule == "crypto-lib-import" else None for h in hits)
    libs.pop(None, None)
    flagged = [h for h in hits if h.catalog]
    by_file = defaultdict(list)
    for h in flagged:
        by_file[h.file].append(h)
    hot = sorted(by_file.items(), key=lambda kv: (-len(kv[1]), kv[0]))[:25]
    return {
        "total_hits": len(hits),
        "flagged_candidates": len(flagged),
        "flagged_in_test_paths": sum(1 for h in flagged if h.test_path),
        "languages": dict(langs.most_common()),
        "categories": dict(cats.most_common()),
        "catalog_ids": dict(catalog.most_common()),
        "hot_files": [{"file": f, "candidates": len(v)} for f, v in hot],
    }

def to_markdown(hits: list[Hit], summary: dict, root: str, flagged_only: bool) -> str:
    out = []
    out.append(f"# Crypto inventory — `{os.path.basename(root.rstrip(os.sep)) or root}`\n")
    out.append(f"- Files/lines with crypto-relevant usage: **{summary['total_hits']}**")
    out.append(f"- Candidates with a catalog tag: **{summary['flagged_candidates']}** ({summary['flagged_in_test_paths']} in test/fixture paths)")
    out.append(f"- Languages: " + ", ".join(f"{k} ({v})" for k, v in summary["languages"].items()))
    out.append(f"- Categories: " + ", ".join(f"{k} ({v})" for k, v in summary["categories"].items()))
    out.append("")
    out.append("## Candidate classes (catalog IDs, by count)\n")
    out.append("| Catalog ID | Candidates |\n|---|---|")
    for k, v in summary["catalog_ids"].items():
        out.append(f"| {k} | {v} |")
    out.append("\n## Hot files (most candidates)\n")
    out.append("| File | Candidates |\n|---|---|")
    for h in summary["hot_files"]:
        out.append(f"| `{h['file']}` | {h['candidates']} |")
    out.append("\n## Candidates (triage these — a hit is not a finding)\n")
    out.append("Sorted by severity-if-true, then file. `T` = test/fixture path.\n")
    out.append("| Sev (if true) | Catalog | T | Location | Rule | Excerpt | Note |\n|---|---|---|---|---|---|---|")
    flagged = sorted((h for h in hits if h.catalog), key=lambda h: (SEV_RANK.get(h.severity_if_true, 9), h.test_path, h.file, h.line))
    for h in flagged:
        ex = h.excerpt.replace("|", "\\|")
        out.append(f"| {h.severity_if_true} | {', '.join(h.catalog)} | {'T' if h.test_path else ''} | `{h.file}:{h.line}` | {h.rule} | `{ex[:110]}` | {h.note} |")
    claims = [h for h in hits if h.category == "doc-claim"]
    if claims:
        out.append("\n## Documentation claims (build the spec-vs-code table from these)\n")
        out.append("| Location | Claim |\n|---|---|")
        for h in claims:
            out.append(f"| `{h.file}:{h.line}` | {h.excerpt.replace('|', '\\|')[:160]} |")
    if not flagged_only:
        out.append("\n## Other crypto usage (inventory, no tag)\n")
        out.append("| Category | Location | Rule | Excerpt |\n|---|---|---|---|")
        rest = sorted((h for h in hits if not h.catalog and h.category != "doc-claim"), key=lambda h: (CATEGORY_ORDER.index(h.category) if h.category in CATEGORY_ORDER else 99, h.file, h.line))
        for h in rest:
            ex = h.excerpt.replace("|", "\\|")
            out.append(f"| {h.category} | `{h.file}:{h.line}` | {h.rule} | `{ex[:110]}` |")
    out.append("")
    return "\n".join(out)

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("path")
    ap.add_argument("--out", help="JSON output path")
    ap.add_argument("--md", help="Markdown output path")
    ap.add_argument("--flagged", action="store_true", help="only emit lines with a catalog tag")
    ap.add_argument("--exclude", default="", help="comma-separated extra directory names to skip")
    ap.add_argument("--max-bytes", type=int, default=2_000_000, help="skip files larger than this")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args(argv)
    root = os.path.abspath(a.path)
    if not os.path.exists(root):
        print(f"path not found: {root}", file=sys.stderr); return 2
    extra = {x.strip() for x in a.exclude.split(",") if x.strip()}
    hits = walk(root, extra, a.max_bytes)
    summary = summarize(hits)
    data = {"root": os.path.basename(root.rstrip(os.sep)) or root, "summary": summary, "hits": [asdict(h) for h in hits if (h.catalog or not a.flagged)]}
    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    md = to_markdown(hits, summary, root, a.flagged)
    if a.md:
        with open(a.md, "w", encoding="utf-8") as f:
            f.write(md)
    if not a.quiet:
        print(md if not (a.out or a.md) else
              f"inventory: {summary['total_hits']} hits, {summary['flagged_candidates']} candidates "
              f"({summary['flagged_in_test_paths']} in test paths); catalog ids: {summary['catalog_ids']}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
