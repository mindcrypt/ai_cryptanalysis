#!/usr/bin/env python3
"""
jwt_inspect.py — Inspect JWT/JWS/JWE tokens for dangerous settings WITHOUT verifying or cracking them.

Reads tokens from arguments, a file (one per line), or stdin. Reports, per token:
  header: alg (none / HS* / RS* / ES* / PS* / EdDSA / JWE algs), typ, kid, jku, x5u, jwk, x5c, crit, zip
  claims: exp / nbf / iat presence and sanity, aud, iss, sub, scope-ish fields, lifetime length
  structure: JWS compact (3 parts) vs JWE compact (5 parts) vs JSON serialization
  flags mapped to catalog IDs (C-02 alg none, C-03 HMAC with public-key context, C-04 key length hints,
  C-05 kid/jku/x5u/jwk, missing exp/aud, RSA1_5 in JWE (A-04), weak alg (HS256 vs ES256 policy), etc.)

It never attempts to verify with guessed keys, never brute-forces secrets, and never prints token bytes
(tokens are referred to as #1, #2, …; claim values other than sub/iss/aud/scope/role are masked). Use the T17 recipes for that
kind of acceptance testing against the real verifier.

Usage:
  python3 jwt_inspect.py <token> [<token>...]
  python3 jwt_inspect.py --file tokens.txt [--json out.json] [--expect-alg ES256] [--expect-aud api]
"""
from __future__ import annotations
import argparse, base64, json, re, sys, time

def b64u_decode(s: str) -> bytes:
    s = s.strip()
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))

def parse(token: str) -> dict:
    token = token.strip()
    out: dict = {"length": len(token), "flags": [], "notes": []}
    if token.startswith("{"):
        try:
            j = json.loads(token)
        except Exception as e:
            out["error"] = f"invalid JSON serialization: {e}"; return out
        out["serialization"] = "json"
        if "signatures" in j:
            out["flags"].append("C-05 JWS JSON serialization with multiple signatures — verifier must require ALL expected signatures, not any")
        if "ciphertext" in j:
            out["type"] = "JWE"
        hdr = j.get("protected")
        if hdr:
            try:
                out["header"] = json.loads(b64u_decode(hdr))
            except Exception:
                pass
        return _flag(out)
    parts = token.split(".")
    out["serialization"] = "compact"
    if len(parts) == 5:
        out["type"] = "JWE"
    elif len(parts) == 3:
        out["type"] = "JWS"
    else:
        out["error"] = f"unexpected number of parts: {len(parts)}"; return out
    try:
        out["header"] = json.loads(b64u_decode(parts[0]))
    except Exception as e:
        out["error"] = f"header not decodable: {e}"; return out
    if out["type"] == "JWS":
        try:
            out["claims"] = json.loads(b64u_decode(parts[1]))
        except Exception:
            out["claims"] = None
            out["notes"].append("payload is not JSON (nested JWT or opaque payload?)")
        out["signature_len_bytes"] = len(b64u_decode(parts[2])) if parts[2] else 0
        if parts[2] == "":
            out["flags"].append("C-02 EMPTY signature part")
    return _flag(out)

def _flag(out: dict) -> dict:
    h = out.get("header") or {}
    c = out.get("claims") or {}
    alg = str(h.get("alg", ""))
    out["alg"] = alg
    if alg.lower() == "none" or alg == "":
        out["flags"].append(f"C-02 alg={alg!r} — unsigned token; verifier must reject")
    if alg.startswith("HS"):
        out["notes"].append("HMAC alg: shared secret must be ≥32 random bytes (C-04); if the verifier also holds an RSA/EC public key, test for RS→HS confusion (C-03)")
    if alg in ("RSA1_5",):
        out["flags"].append("A-04 JWE alg RSA1_5 (PKCS#1 v1.5) — Bleichenbacher surface; use RSA-OAEP-256 or ECDH-ES")
    if alg in ("RS256", "RS384", "RS512") :
        out["notes"].append("RSA PKCS#1 v1.5 signature: fine if verifier is strict (A-06); PS*/ES*/EdDSA preferred")
    if alg.startswith("ECDH-ES"):
        out["notes"].append("ECDH-ES: verifier must validate 'epk' point (A-18)")
    enc = h.get("enc")
    if enc and enc.startswith("A") and "CBC" in enc:
        out["notes"].append(f"JWE enc={enc}: CBC+HMAC construction — ok if tag checked first; check padding error handling (S-22)")
    for k in ("jku", "x5u"):
        if k in h:
            out["flags"].append(f"C-05 header '{k}' present ({str(h[k])[:60]}) — key fetched from a URL; verifier must allow-list")
    if "jwk" in h:
        out["flags"].append("C-05 header 'jwk' embeds a key — verifier must NOT trust it")
    if "x5c" in h:
        out["notes"].append("x5c present — verifier must validate the chain against a trusted root, not just use the leaf key")
    if "kid" in h:
        kid = str(h["kid"])
        if re.search(r"[./\\'\"; ]|\.\.", kid):
            out["flags"].append(f"C-05 kid contains path/quote characters ({kid[:40]!r}) — injection test needed")
        else:
            out["notes"].append(f"kid={kid[:40]!r} — ensure strict lookup in a configured key set")
    if h.get("crit"):
        out["notes"].append(f"crit={h['crit']} — verifier must understand all listed headers")
    if h.get("zip"):
        out["notes"].append("zip header — decompression bomb / CRIME-style considerations")
    typ = h.get("typ")
    if out.get("type") == "JWS" and typ not in ("JWT", "at+jwt", "id_token+jwt", "secevent+jwt", "logout+jwt", "dpop+jwt", None):
        out["notes"].append(f"typ={typ!r} — verifier should check typ to prevent cross-purpose use (RFC 9068 'at+jwt' for access tokens)")
    if out.get("type") == "JWS" and typ is None:
        out["notes"].append("no typ header — consider requiring one (C-05 token-type confusion)")
    if isinstance(c, dict):
        now = int(time.time())
        if "exp" not in c:
            out["flags"].append("C-05 no 'exp' claim — token never expires")
        else:
            try:
                exp = int(c["exp"])
                if exp < now:
                    out["notes"].append("token is expired (fine for a sample)")
                iat = int(c.get("iat", exp))
                life = exp - iat
                if life > 7 * 86400:
                    out["flags"].append(f"C-05 lifetime {life // 86400} days — long-lived token")
            except Exception:
                out["flags"].append("exp is not an integer")
        if "aud" not in c:
            out["flags"].append("C-05 no 'aud' claim — token can be replayed to other audiences")
        if "iss" not in c:
            out["notes"].append("no 'iss' claim")
        if "nbf" in c and "exp" in c:
            try:
                if int(c["nbf"]) > int(c["exp"]):
                    out["flags"].append("nbf > exp")
            except Exception:
                pass
        sensitive = [k for k in c if re.search(r"pass|secret|ssn|card|token|key", k, re.I)]
        if sensitive:
            out["flags"].append(f"sensitive-looking claims in a signed-but-not-encrypted JWS: {sensitive}")
        out["claims_summary"] = {k: (str(v)[:40] if k in ("sub", "iss", "aud", "scope", "role", "roles", "email", "typ") else "…") for k, v in c.items()}
    if out.get("type") == "JWS" and alg.startswith("HS") and out.get("signature_len_bytes") not in (None, 32, 48, 64):
        out["flags"].append(f"signature length {out.get('signature_len_bytes')} inconsistent with {alg}")
    return out

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("tokens", nargs="*")
    ap.add_argument("--file")
    ap.add_argument("--json")
    ap.add_argument("--expect-alg", help="policy algorithm (e.g. ES256); other algs are flagged")
    ap.add_argument("--expect-aud")
    a = ap.parse_args(argv)
    toks = list(a.tokens)
    if a.file:
        toks += [l.strip() for l in open(a.file) if l.strip() and not l.startswith("#")]
    if not toks and not sys.stdin.isatty():
        toks += [l.strip() for l in sys.stdin if l.strip()]
    if not toks:
        ap.error("no tokens given")
    results = []
    for t in toks:
        r = parse(t)
        if a.expect_alg and r.get("alg") and r["alg"] != a.expect_alg:
            r["flags"].append(f"alg {r['alg']} differs from policy {a.expect_alg} (C-03: verifier must pin the algorithm)")
        if a.expect_aud and isinstance(r.get("claims"), dict):
            aud = r["claims"].get("aud")
            if aud != a.expect_aud and not (isinstance(aud, list) and a.expect_aud in aud):
                r["flags"].append(f"aud {aud!r} != expected {a.expect_aud!r}")
        results.append(r)
    if a.json:
        json.dump(results, open(a.json, "w"), indent=2)
    for n, r in enumerate(results, 1):
        print(f"== token #{n} ({r['length']} chars)  type={r.get('type')} alg={r.get('alg')} ser={r.get('serialization')}")
        if r.get("error"):
            print("   error:", r["error"])
        hdr = {k: (str(v)[:60]) for k, v in (r.get("header") or {}).items()}
        print("   header:", hdr)
        if r.get("claims_summary"):
            print("   claims:", r["claims_summary"])
        for f in r["flags"]:
            print("   FLAG:", f)
        for n in r["notes"]:
            print("   note:", n)
    return 0

if __name__ == "__main__":
    sys.exit(main())
