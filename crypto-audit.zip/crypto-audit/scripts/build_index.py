#!/usr/bin/env python3
"""
build_index.py — regenerate references/catalog-index.md from the catalog files.

The index has one line per catalog entry (ID, title, file, first line, length) so that an auditor can open
exactly the entries a target needs instead of reading ~150 KB of catalogs. Run it after editing any
references/catalog-*.md:   python3 scripts/build_index.py
"""
import os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
REF = os.path.join(HERE, "..", "references")
FILES = ["catalog-symmetric.md", "catalog-asymmetric.md", "catalog-pqc.md", "catalog-config.md"]
HEAD = re.compile(r"^(#{2,3}) ([SAPCT]-\d{2})\s+(.*)$")   # e.g. "## S-07 AES-GCM nonce reuse", "### A-04 ..."

def main() -> int:
    rows = []
    for fn in FILES:
        lines = open(os.path.join(REF, fn), encoding="utf-8").read().split("\n")
        heads = [(i, HEAD.match(l)) for i, l in enumerate(lines, 1)]
        heads = [(i, m) for i, m in heads if m]
        section_starts = [i for i, l in enumerate(lines, 1) if l.startswith("## ") or l.startswith("### ") or l.strip() == "---"]
        for k, (i, m) in enumerate(heads):
            nxt = min([j for j in section_starts if j > i], default=len(lines) + 1)
            rows.append((m.group(2), m.group(3).strip(), fn, i, nxt - i))
    out = ["# Catalog index", "",
           "One line per entry. Open only the entries you need: `Read` the file at the given line for the given number of lines,",
           "or `Grep` for the heading (pattern `^#{2,3} S-07`). Regenerate with `python3 scripts/build_index.py` after editing a catalog.", "",
           "| ID | Entry | File | Line | Lines |", "|---|---|---|---|---|"]
    for id_, title, fn, line, n in rows:
        out.append(f"| {id_} | {title} | `{fn}` | {line} | {n} |")
    # test recipes: headings of the form "## T7 — ..." (code fences contain "# ..." comment lines, so match the dash form only)
    vt = open(os.path.join(REF, "verification-tests.md"), encoding="utf-8").read().split("\n")
    recipe = re.compile(r"^## (T\d+) — (.*)$")
    starts = [(i, recipe.match(l)) for i, l in enumerate(vt, 1)]
    starts = [(i, m) for i, m in starts if m]
    out += ["", "## Test recipes (`verification-tests.md`)", "", "| Recipe | What it tests | Line | Lines |", "|---|---|---|---|"]
    for k, (i, m) in enumerate(starts):
        nxt = starts[k + 1][0] if k + 1 < len(starts) else len(vt) + 1
        out.append(f"| {m.group(1)} | {m.group(2).strip()} | {i} | {nxt - i} |")
    out.append("")
    open(os.path.join(REF, "catalog-index.md"), "w", encoding="utf-8").write("\n".join(out))
    print(f"catalog-index.md: {len(rows)} catalog entries, {len(starts)} test recipes")
    return 0

if __name__ == "__main__":
    sys.exit(main())
