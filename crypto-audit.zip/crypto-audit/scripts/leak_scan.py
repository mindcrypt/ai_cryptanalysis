#!/usr/bin/env python3
"""
leak_scan.py — check that audit deliverables do not reproduce the target's secrets.

The audit reads keys, tokens and passwords in the target; the report, the tests and the attached script
output must not carry them out again (SKILL.md rule 10). This script collects the secret-looking values
from the target at run time and searches the deliverables for them. No secret is stored in this file and
none is printed: a hit shows where the value came from and where it reappeared, with the value masked.

What counts as a secret in the target:
  * string literals assigned to, defaulted for, or OR-ed with a secret-like name (KEY, SECRET, TOKEN, PASSWORD, ...),
    including values in .env-style files
  * long hex / base64 literals (>= 24 characters)
  * the base64 body lines of PEM private keys
  * well-known token formats (AWS access key ids, GitHub / Slack / Stripe tokens) and complete JWTs

Values of 12 characters or more are "strong" needles: a hit makes the exit code 1.
Values of 8-11 characters ("changeme", "dev-secret") are "short" needles: hits are listed as warnings,
because short strings also occur innocently; pass --strict to fail on them too.

Usage:
  python3 leak_scan.py <target-dir> <deliverable-file-or-dir>... [--strict] [--json out.json]

Tips that keep the scan clean: read secrets from the target at test run time instead of copying them into
test files; run pytest with --assert=plain so failing assertions do not print operand values; attach
script output only after scanning it.
"""
from __future__ import annotations
import argparse, json, os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import crypto_inventory as ci  # noqa: E402  (same folder)

LOCKFILES = {"package-lock.json", "yarn.lock", "pnpm-lock.yaml", "go.sum", "Cargo.lock", "poetry.lock", "Pipfile.lock", "composer.lock", "Gemfile.lock"}
LONG_LITERAL = re.compile(r"(['\"`])([A-Za-z0-9+/=_\-]{24,})\1")
WRAPPED = re.compile(r"(?:fromhex|unhexlify|b64decode|Buffer\.from|DecodeString|GetBytes|decode\w*)\s*\(\s*b?(['\"])([^'\"]{8,})\1")
TOKENS = re.compile(r"\b((?:AKIA|ASIA)[0-9A-Z]{16}|xox[baprs]-[0-9A-Za-z-]{10,}|gh[pousr]_[0-9A-Za-z]{36}|sk_live_[0-9a-zA-Z]{20,}|eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]*)")
PEM_BEGIN = re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")
PEM_END = re.compile(r"-----END [A-Z ]*PRIVATE KEY-----")
SECRET_LINE = re.compile(ci.SECRET_NAME, re.I)

def mask(v: str) -> str:
    return f"{v[:3]}…({len(v)} chars)"

def collect(target: str, min_len: int) -> dict[str, str]:
    """value -> 'file:line' of first sighting in the target"""
    needles: dict[str, str] = {}
    def add(v: str, where: str):
        v = v.strip()
        if len(v) >= min_len and len(set(v)) >= 4 and v not in needles:
            needles[v] = where
    for dirpath, dirnames, filenames in os.walk(target):
        dirnames[:] = [d for d in dirnames if d not in ci.SKIP_DIRS]
        for fn in filenames:
            if fn in LOCKFILES:
                continue
            p = os.path.join(dirpath, fn); rel = os.path.relpath(p, target)
            try:
                if os.path.getsize(p) > 2_000_000:
                    continue
                lines = open(p, "r", encoding="utf-8", errors="ignore").read().split("\n")
            except OSError:
                continue
            in_pem = False
            is_config = ci.lang_for(p) in ("config", "shell")
            for n, line in enumerate(lines, 1):
                where = f"{rel}:{n}"
                if PEM_BEGIN.search(line):
                    in_pem = True; continue
                if PEM_END.search(line):
                    in_pem = False; continue
                if in_pem:
                    body = line.strip()
                    if len(body) >= 40:
                        add(body, where)
                    continue
                for m in TOKENS.finditer(line):
                    add(m.group(1), where)
                for m in LONG_LITERAL.finditer(line):
                    add(m.group(2), where)
                if SECRET_LINE.search(line):
                    for rx in (ci._ASSIGN_RX, ci._DEFAULT_RX, ci._OR_RX):
                        for m in rx.finditer(line):
                            add(m.group(3), where)
                    if is_config:
                        m = ci._ENVLINE_RX.match(line)
                        if m and "(" not in m.group(2):
                            add(m.group(2).strip("'\""), where)
                    for m in WRAPPED.finditer(line):
                        add(m.group(2), where)
    return needles

def deliverable_files(paths: list[str]) -> list[str]:
    out = []
    for p in paths:
        if os.path.isfile(p):
            out.append(p)
        else:
            for d, dn, fns in os.walk(p):
                dn[:] = [x for x in dn if x not in {".git", "node_modules", "__pycache__", ".pytest_cache"}]
                out.extend(os.path.join(d, f) for f in fns)
    return out

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("target")
    ap.add_argument("deliverables", nargs="+")
    ap.add_argument("--strict", action="store_true", help="short needles (8-11 chars) also fail the scan")
    ap.add_argument("--json")
    a = ap.parse_args(argv)
    target = os.path.abspath(a.target)
    needles = collect(target, 8)
    strong = {v: w for v, w in needles.items() if len(v) >= 12}
    short = {v: w for v, w in needles.items() if len(v) < 12}
    files = [f for f in deliverable_files(a.deliverables) if not os.path.abspath(f).startswith(target + os.sep)]
    hits = []
    for f in files:
        try:
            if os.path.getsize(f) > 20_000_000:
                continue
            text = open(f, "r", encoding="utf-8", errors="ignore").read()
        except OSError:
            continue
        present = [v for v in needles if v in text]
        if not present:
            continue
        for n, line in enumerate(text.split("\n"), 1):
            for v in present:
                if v in line:
                    hits.append({"deliverable": f, "line": n, "value": mask(v), "from": needles[v], "kind": "strong" if v in strong else "short"})
    s_hits = [h for h in hits if h["kind"] == "strong"]; w_hits = [h for h in hits if h["kind"] == "short"]
    print(f"leak_scan: {len(strong)} strong and {len(short)} short secret value(s) found in the target; {len(files)} deliverable file(s) scanned")
    for h in s_hits:
        print(f"  LEAK   {h['deliverable']}:{h['line']}  reproduces {h['value']} from {h['from']}")
    for h in w_hits:
        print(f"  warn   {h['deliverable']}:{h['line']}  contains short value {h['value']} from {h['from']}")
    if a.json:
        json.dump({"strong_needles": len(strong), "short_needles": len(short), "files": len(files), "hits": hits}, open(a.json, "w"), indent=2)
    failed = bool(s_hits) or (a.strict and bool(w_hits))
    print("RESULT:", "secrets reproduced in deliverables — remove them before handing anything over" if failed else
          ("clean" if not w_hits else "no strong leaks; review the short-value warnings"))
    return 1 if failed else 0

if __name__ == "__main__":
    sys.exit(main())
