#!/usr/bin/env python3
"""
timing_check.py — screening test for input-dependent timing (dudect-style, with repeat rounds).

Two input classes A and B are run in random interleaved order and timed with time.perf_counter_ns().
The measurement is repeated in several independent rounds. Per round: samples above the pooled 90th
percentile are cropped (scheduler noise), then Welch's t and the difference of medians are computed.

A leak is reported only when ALL of these hold, because a single |t| > 4.5 on a difference of a
nanosecond or two is not reproducible on a normal machine:
  * |t| > 4.5 in at least 80% of the rounds,
  * the faster class is the same in every one of those rounds (sign consistency),
  * the median difference is at least the minimum effect size
    (default: the larger of 20 ns and 2% of the median run time; tune with --min-effect-ns / --min-effect-rel).

Three ways to use it:

1) Python function (module is imported with the current directory on sys.path; inputs are Python expressions):
   python3 timing_check.py --module app.auth --func check_mac \
       --input-a 'b"\\xff"+b"\\x00"*31' --input-b 'b"\\x00"*31+b"\\xff"'
   Several arguments: make each input a tuple and add --star  ->  func(*input)
   python3 timing_check.py --module app.auth --func verify_payload --star \
       --input-a '(b"payload", "0"*64)' --input-b '(b"payload", "f"+"0"*63)'

2) Shell command, with {input} replaced by a file name (slow; for CLIs or a curl round-trip):
   python3 timing_check.py --cmd 'curl -s -o /dev/null https://host/api -d @{input}' \
       --file-a bad_padding.bin --file-b bad_mac.bin --n 100 --rounds 3

3) Samples collected elsewhere (nanoseconds, one per line; analysed as a single round):
   python3 timing_check.py --stats a_times.txt b_times.txt

Exit code: 1 leak, 2 inconclusive, 0 no evidence.
This is a screening tool. "No evidence" is not a proof of constant-time behaviour, and for comparison
functions the code itself (==, memcmp, Arrays.equals on a secret) is the finding regardless of what a
noisy measurement shows; use this to demonstrate large differences (early-exit loops, a hash computed
only for existing users, distinct padding/MAC error paths), not to clear code.
"""
from __future__ import annotations
import argparse, importlib, math, os, random, shlex, statistics, subprocess, sys, time

T_THRESHOLD = 4.5

def welch_t(a: list[float], b: list[float]) -> float:
    va, vb = statistics.pvariance(a), statistics.pvariance(b)
    se = math.sqrt(va / len(a) + vb / len(b))
    return (statistics.fmean(a) - statistics.fmean(b)) / se if se > 0 else 0.0

def crop_pair(a: list[float], b: list[float], pct: float = 0.9) -> tuple[list[float], list[float]]:
    pooled = sorted(a + b)
    thr = pooled[max(0, int(len(pooled) * pct) - 1)]
    ca, cb = [x for x in a if x <= thr], [x for x in b if x <= thr]
    return (ca if len(ca) >= 5 else sorted(a)[:5]), (cb if len(cb) >= 5 else sorted(b)[:5])

def round_stats(a: list[float], b: list[float]) -> dict:
    ca, cb = crop_pair(a, b)
    return {"t": welch_t(ca, cb), "raw_t": welch_t(a, b),
            "median_a": statistics.median(a), "median_b": statistics.median(b),
            "diff": statistics.median(a) - statistics.median(b), "n": (len(a), len(b))}

def measure_function(fn, ia, ib, n: int, star: bool) -> tuple[list[float], list[float]]:
    call = (lambda x: fn(*x)) if star else fn
    A, B = [], []
    order = [0] * n + [1] * n
    random.shuffle(order)
    for cls in order:
        x = ia if cls == 0 else ib
        t0 = time.perf_counter_ns(); call(x); dt = time.perf_counter_ns() - t0
        (A if cls == 0 else B).append(dt)
    return A, B

def measure_command(cmd: str, file_a: str, file_b: str, n: int) -> tuple[list[float], list[float]]:
    A, B = [], []
    order = [0] * n + [1] * n
    random.shuffle(order)
    for cls in order:
        argv = shlex.split(cmd.replace("{input}", file_a if cls == 0 else file_b))
        t0 = time.perf_counter_ns()
        subprocess.run(argv, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        (A if cls == 0 else B).append(time.perf_counter_ns() - t0)
    return A, B

def verdict(rounds: list[dict], min_ns: float, min_rel: float) -> int:
    print(f"{'round':>5} {'t (cropped)':>12} {'raw t':>9} {'median A ns':>12} {'median B ns':>12} {'A-B ns':>9}")
    for i, r in enumerate(rounds, 1):
        print(f"{i:>5} {r['t']:>12.2f} {r['raw_t']:>9.2f} {r['median_a']:>12.0f} {r['median_b']:>12.0f} {r['diff']:>9.0f}")
    strong = [r for r in rounds if abs(r["t"]) > T_THRESHOLD]
    signs = {1 if r["t"] > 0 else -1 for r in strong}
    typical = statistics.median([(r["median_a"] + r["median_b"]) / 2 for r in rounds])
    effect = statistics.median([abs(r["diff"]) for r in rounds])
    need = max(min_ns, min_rel * typical)
    enough_rounds = len(strong) >= math.ceil(0.8 * len(rounds))
    print(f"\nrounds with |t| > {T_THRESHOLD}: {len(strong)}/{len(rounds)}; same direction: {'yes' if len(signs) == 1 else 'no' if strong else 'n/a'}; "
          f"median |A-B| = {effect:.0f} ns; minimum effect required = {need:.0f} ns (run time ~{typical:.0f} ns)")
    if len(rounds) == 1:
        print("note: a single round cannot show reproducibility; prefer --rounds 5 or more.")
    if enough_rounds and len(signs) == 1 and effect >= need:
        slower = "A" if next(iter(signs)) > 0 else "B"
        print(f"VERDICT: LEAK — class {slower} is consistently slower by ~{effect:.0f} ns. Timing depends on the input class "
              "(S-18 / T-01 / S-22 / A-04 depending on what the two classes are).")
        return 1
    if enough_rounds and len(signs) == 1:
        print(f"VERDICT: NO PRACTICAL DIFFERENCE — statistically consistent but below the minimum effect size ({effect:.0f} ns < {need:.0f} ns). "
              "Do not report a measured leak; if the code compares a secret with a non-constant-time primitive, the code is the finding.")
        return 0
    if strong:
        print("VERDICT: INCONCLUSIVE — rounds disagree (direction or significance). This is measurement noise until shown otherwise; "
              "raise --n/--rounds, quiet the machine, or rely on code review.")
        return 2
    print("VERDICT: NO EVIDENCE of a timing difference at this sample size (not a proof of constant time).")
    return 0

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--module"); ap.add_argument("--func")
    ap.add_argument("--input-a"); ap.add_argument("--input-b")
    ap.add_argument("--star", action="store_true", help="inputs are tuples: call func(*input)")
    ap.add_argument("--cmd"); ap.add_argument("--file-a"); ap.add_argument("--file-b")
    ap.add_argument("--stats", nargs=2, metavar=("A_TIMES", "B_TIMES"))
    ap.add_argument("--n", type=int, default=5000, help="samples per class per round (default 5000; use ~100 with --cmd)")
    ap.add_argument("--rounds", type=int, default=5)
    ap.add_argument("--min-effect-ns", type=float, default=20.0)
    ap.add_argument("--min-effect-rel", type=float, default=0.02)
    a = ap.parse_args(argv)
    rounds: list[dict] = []
    if a.stats:
        A = [float(x) for x in open(a.stats[0]) if x.strip()]
        B = [float(x) for x in open(a.stats[1]) if x.strip()]
        rounds.append(round_stats(A, B))
    elif a.module and a.func:
        if not (a.input_a and a.input_b):
            ap.error("--input-a and --input-b required")
        sys.path.insert(0, os.getcwd())
        fn = getattr(importlib.import_module(a.module), a.func)
        ia = eval(a.input_a, {"__builtins__": __builtins__})   # noqa: S307 — expressions typed by the auditor
        ib = eval(a.input_b, {"__builtins__": __builtins__})   # noqa: S307
        measure_function(fn, ia, ib, 200, a.star)               # warm-up, discarded
        for _ in range(a.rounds):
            rounds.append(round_stats(*measure_function(fn, ia, ib, a.n, a.star)))
    elif a.cmd:
        if not (a.file_a and a.file_b):
            ap.error("--file-a and --file-b required")
        for _ in range(a.rounds):
            rounds.append(round_stats(*measure_command(a.cmd, a.file_a, a.file_b, a.n)))
    else:
        ap.error("choose --module/--func, --cmd, or --stats")
    return verdict(rounds, a.min_effect_ns, a.min_effect_rel)

if __name__ == "__main__":
    sys.exit(main())
