#!/usr/bin/env python3
"""
key_analyzer.py — Sanity analysis of public keys, private keys (public part only) and certificates.

Reads PEM/DER files, JWK/JWKS JSON, and OpenSSH public keys found under the given paths, and reports:
  * RSA: modulus size, public exponent, duplicate moduli, shared factors across the set (batch GCD),
         ROCA fingerprint (Infineon RSALib), small private exponent (Wiener continued-fraction check),
         close primes (Fermat, bounded iterations).
  * EC:  curve name and whether it is approved/weak; explicit (non-named) parameters.
  * Certificates: signature algorithm (MD5/SHA-1), validity window, SAN presence, CA flag, key usage.
  * Private keys: only reports that the file is a private key and its public parameters. Never prints
    private values. Never factors a key beyond the yes/no checks above.
  * --ecdsa-r FILE: reads signatures (hex DER, or "r,s" decimal/hex per line) and reports repeated r values.

Usage:
  python3 key_analyzer.py <path>... [--gcd] [--roca] [--wiener] [--fermat N] [--json out.json]     (e.g. --fermat 10000)
  python3 key_analyzer.py --ecdsa-r signatures.txt

Requires: cryptography (pip install cryptography).
"""
from __future__ import annotations
import argparse, base64, json, math, os, re, sys
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone

try:
    from cryptography import x509
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import rsa, ec, ed25519, ed448, x25519, x448, dsa, dh
    from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature
except ImportError:
    print("This script needs the 'cryptography' package: pip install cryptography", file=sys.stderr)
    sys.exit(2)

KEY_EXT = {".pem", ".key", ".crt", ".cer", ".der", ".pub", ".jwk", ".jwks", ".json", ".p8", ".pkcs8", ".spki"}
WEAK_CURVES = {"secp112r1", "secp112r2", "secp128r1", "secp128r2", "secp160k1", "secp160r1", "secp160r2",
               "secp192k1", "secp192r1", "prime192v1", "sect113r1", "sect113r2", "sect131r1", "sect131r2",
               "sect163k1", "sect163r1", "sect163r2", "sect193r1", "sect193r2", "brainpoolP160r1", "brainpoolP192r1"}
MARGINAL_CURVES = {"secp224r1", "secp224k1", "brainpoolP224r1", "sect233k1", "sect233r1"}
BINARY_CURVES_RX = re.compile(r"^sect|^B-|^K-")
APPROVED_NIST = {"secp256r1", "secp384r1", "secp521r1"}
FIRST_PRIMES = [p for p in range(2, 168) if all(p % q for q in range(2, int(p ** 0.5) + 1))]  # 2..167 (39 primes)

@dataclass
class KeyInfo:
    file: str
    kind: str                      # certificate | public-key | private-key | jwk | ssh-public | unknown
    algorithm: str = ""
    bits: int = 0
    curve: str = ""
    exponent: int = 0
    modulus_fingerprint: str = ""  # sha256 of n (hex prefix) for de-dup without printing n
    issues: list = field(default_factory=list)
    notes: list = field(default_factory=list)
    cert: dict = field(default_factory=dict)
    _n: int = 0                    # not serialized

def sha256_hex(b: bytes) -> str:
    import hashlib
    return hashlib.sha256(b).hexdigest()

# ---------------- loaders ----------------

def load_objects(path: str) -> list[tuple[str, object]]:
    """Return list of (kind, object) found in a file. Handles PEM bundles, DER, JWK(S), OpenSSH pub."""
    out = []
    try:
        data = open(path, "rb").read()
    except OSError:
        return out
    text = data.decode("utf-8", errors="ignore")
    if "-----BEGIN" in text:
        for m in re.finditer(r"-----BEGIN ([A-Z0-9 ]+)-----.*?-----END \1-----", text, re.S):
            block = m.group(0).encode()
            label = m.group(1)
            try:
                if "CERTIFICATE" in label and "REQUEST" not in label:
                    out.append(("certificate", x509.load_pem_x509_certificate(block)))
                elif "PUBLIC KEY" in label:
                    out.append(("public-key", serialization.load_pem_public_key(block)))
                elif "PRIVATE KEY" in label:
                    if "ENCRYPTED" in label or b"ENCRYPTED" in block[:200]:
                        out.append(("private-key-encrypted", None))
                    else:
                        out.append(("private-key", serialization.load_pem_private_key(block, password=None)))
                elif "CERTIFICATE REQUEST" in label:
                    out.append(("csr", x509.load_pem_x509_csr(block)))
            except Exception as e:  # noqa
                out.append(("unparseable:" + label, str(e)))
        return out
    s = text.strip()
    if s.startswith("{"):
        try:
            j = json.loads(s)
            keys = j.get("keys", [j]) if isinstance(j, dict) else []
            for k in keys:
                if isinstance(k, dict) and "kty" in k:
                    out.append(("jwk", k))
        except Exception:
            pass
        return out
    if s.startswith(("ssh-rsa ", "ssh-ed25519 ", "ecdsa-sha2-")):
        for line in s.splitlines():
            parts = line.split()
            if len(parts) >= 2:
                try:
                    out.append(("ssh-public", serialization.load_ssh_public_key(line.encode())))
                except Exception as e:
                    out.append(("unparseable:ssh", str(e)))
        return out
    # DER attempts
    for kind, fn in (("certificate", x509.load_der_x509_certificate), ("public-key", serialization.load_der_public_key),
                     ("private-key", lambda d: serialization.load_der_private_key(d, password=None))):
        try:
            out.append((kind, fn(data)))
            return out
        except Exception:
            continue
    return out

def b64u(s: str) -> int:
    s = s + "=" * (-len(s) % 4)
    return int.from_bytes(base64.urlsafe_b64decode(s), "big")

# ---------------- RSA checks ----------------

def isqrt(n: int) -> int:
    return math.isqrt(n)

def is_square(n: int) -> bool:
    if n < 0:
        return False
    r = isqrt(n)
    return r * r == n

def wiener_small_d(n: int, e: int) -> bool:
    """Continued-fraction check for d < n^0.25 (Wiener). Returns True if the key is broken. Does not output d."""
    def contfrac(a, b):
        while b:
            q = a // b
            yield q
            a, b = b, a - q * b
    num0, den0, num1, den1 = 1, 0, 0, 1   # convergents h/k
    for q in contfrac(e, n):
        num0, num1 = q * num0 + num1, num0
        den0, den1 = q * den0 + den1, den0
        k, d = num0, den0
        if k == 0 or d == 0:
            continue
        if (e * d - 1) % k != 0:
            continue
        phi = (e * d - 1) // k
        b = n - phi + 1               # p + q
        disc = b * b - 4 * n
        if disc >= 0 and is_square(disc):
            r = isqrt(disc)
            if (b + r) % 2 == 0:
                p = (b + r) // 2
                if p * (n // p) == n and 1 < p < n:
                    return True
        if d.bit_length() > n.bit_length() // 4 + 8:
            break
    return False

def fermat_close_primes(n: int, iterations: int) -> bool:
    """Bounded Fermat factorization: True if p and q are close enough to be found within `iterations` steps."""
    if n % 2 == 0:
        return True
    a = isqrt(n)
    if a * a < n:
        a += 1
    for _ in range(iterations):
        b2 = a * a - n
        if is_square(b2):
            b = isqrt(b2)
            p, q = a - b, a + b
            if p > 1 and q > 1 and p * q == n:
                return True
        a += 1
    return False

def roca_fingerprint(n: int) -> bool:
    """ROCA (CVE-2017-15361) fingerprint: for the first 39 primes, n mod p must lie in the subgroup generated by 65537 mod p."""
    for p in FIRST_PRIMES:
        allowed = set()
        x = 1
        while True:
            allowed.add(x)
            x = (x * 65537) % p
            if x == 1:
                break
        if (n % p) not in allowed:
            return False
    return True

def batch_gcd(mods: list[int]) -> list[int]:
    """Product/remainder tree batch GCD. Returns gcd(n_i, prod_{j!=i} n_j) for each i."""
    if len(mods) < 2:
        return [1] * len(mods)
    # product tree
    tree = [mods[:]]
    while len(tree[-1]) > 1:
        level = tree[-1]
        tree.append([level[i] * level[i + 1] if i + 1 < len(level) else level[i] for i in range(0, len(level), 2)])
    # remainder tree
    rems = [tree[-1][0]]
    for level in reversed(tree[:-1]):
        new = []
        for i, x in enumerate(level):
            new.append(rems[i // 2] % (x * x))
        rems = new
    return [math.gcd(r // n, n) for r, n in zip(rems, mods)]

# ---------------- analysis ----------------

def analyze_public(ki: KeyInfo, pub, opts) -> None:
    if isinstance(pub, rsa.RSAPublicKey):
        nums = pub.public_numbers()
        n, e = nums.n, nums.e
        ki.algorithm, ki.bits, ki.exponent, ki._n = "RSA", pub.key_size, e, n
        ki.modulus_fingerprint = sha256_hex(n.to_bytes((n.bit_length() + 7) // 8, "big"))[:16]
        if ki.bits < 2048:
            ki.issues.append(f"A-01 RSA {ki.bits} bits < 2048 (High)")
        elif ki.bits < 3000:
            ki.notes.append(f"A-01 RSA {ki.bits} bits: NIST-acceptable through 2030, below BSI ≥3000 (Low/Medium)")
        if e < 65537:
            ki.issues.append(f"A-03 small public exponent e={e} (Medium; Critical if combined with lax PKCS#1 v1.5 verification)")
        if e % 2 == 0:
            ki.issues.append("RSA public exponent is even — invalid key")
        if e.bit_length() > 256:
            ki.notes.append("public exponent > 2^256 (outside FIPS 186-5 range)")
        if opts.roca and roca_fingerprint(n):
            ki.issues.append("A-08 ROCA fingerprint positive (Infineon RSALib, CVE-2017-15361) — key is factorable (Critical)")
        if opts.wiener and wiener_small_d(n, e):
            ki.issues.append("A-09 small private exponent (Wiener) — key is broken (Critical)")
        if opts.fermat and fermat_close_primes(n, opts.fermat):
            ki.issues.append(f"A-08 primes too close (Fermat within {opts.fermat} iterations) — key is factorable (Critical)")
    elif isinstance(pub, ec.EllipticCurvePublicKey):
        ki.algorithm, ki.bits, ki.curve = "EC", pub.curve.key_size, pub.curve.name
        if ki.curve in WEAK_CURVES or ki.bits < 224:
            ki.issues.append(f"A-25 weak curve {ki.curve} ({ki.bits} bits) (High)")
        elif ki.curve in MARGINAL_CURVES:
            ki.issues.append(f"A-25 marginal curve {ki.curve} (224 bits; NIST ok to 2030, BSI ≥250) (Medium)")
        elif BINARY_CURVES_RX.match(ki.curve):
            ki.issues.append(f"A-25 binary curve {ki.curve} — deprecated (Medium)")
        elif ki.curve == "secp256k1":
            ki.notes.append("secp256k1 — fine for Bitcoin-compatible contexts, not FIPS-approved")
        elif ki.curve.startswith("brainpool"):
            ki.notes.append("brainpool curve — BSI-recommended, not NIST-approved; check constant-time support")
        elif ki.curve not in APPROVED_NIST:
            ki.notes.append(f"curve {ki.curve} — check approval status")
    elif isinstance(pub, (ed25519.Ed25519PublicKey, ed448.Ed448PublicKey)):
        ki.algorithm = "Ed25519" if isinstance(pub, ed25519.Ed25519PublicKey) else "Ed448"
        ki.bits = 256 if ki.algorithm == "Ed25519" else 448
        ki.notes.append("A-23: check verifier strictness and sign() API (pk derived from sk?)")
    elif isinstance(pub, (x25519.X25519PublicKey, x448.X448PublicKey)):
        ki.algorithm = "X25519" if isinstance(pub, x25519.X25519PublicKey) else "X448"
        ki.notes.append("A-24: ensure all-zero shared-secret check")
    elif isinstance(pub, dsa.DSAPublicKey):
        ki.algorithm, ki.bits = "DSA", pub.key_size
        ki.issues.append("DSA — removed from FIPS 186-5 for new keys (Medium); check nonce generation (A-19)")
    elif isinstance(pub, dh.DHPublicKey):
        ki.algorithm, ki.bits = "DH", pub.key_size
        if ki.bits < 2048:
            ki.issues.append(f"A-14 DH {ki.bits} bits (High)")
    else:
        ki.algorithm = type(pub).__name__

def analyze_cert(ki: KeyInfo, cert: x509.Certificate, opts) -> None:
    ki.kind = "certificate"
    analyze_public(ki, cert.public_key(), opts)
    sig = cert.signature_algorithm_oid._name if hasattr(cert.signature_algorithm_oid, "_name") else str(cert.signature_algorithm_oid)
    ki.cert["signature_algorithm"] = sig
    ki.cert["subject"] = cert.subject.rfc4514_string()
    ki.cert["issuer"] = cert.issuer.rfc4514_string()
    try:
        nb, na = cert.not_valid_before_utc, cert.not_valid_after_utc
    except AttributeError:
        nb, na = cert.not_valid_before.replace(tzinfo=timezone.utc), cert.not_valid_after.replace(tzinfo=timezone.utc)
    ki.cert["not_before"], ki.cert["not_after"] = nb.isoformat(), na.isoformat()
    now = datetime.now(timezone.utc)
    if na < now:
        ki.issues.append("certificate expired (check whether still deployed)")
    if (na - nb).days > 398 and ki.cert["subject"] != ki.cert["issuer"]:
        ki.notes.append(f"validity {(na - nb).days} days > 398 (public CA policy) — fine for private PKI, note it")
    if re.search(r"md5|md2|sha1", sig, re.I):
        ki.issues.append(f"S-24 certificate signed with {sig} (High if used for trust)")
    try:
        san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
        ki.cert["san_count"] = len(san)
    except x509.ExtensionNotFound:
        ki.cert["san_count"] = 0
        if ki.cert["subject"] != ki.cert["issuer"]:
            ki.notes.append("no subjectAltName — modern clients ignore CN (RFC 6125); hostname validation may be broken")
    try:
        bc = cert.extensions.get_extension_for_class(x509.BasicConstraints).value
        ki.cert["is_ca"] = bc.ca
    except x509.ExtensionNotFound:
        ki.cert["is_ca"] = None
    try:
        ku = cert.extensions.get_extension_for_class(x509.KeyUsage).value
        ki.cert["key_usage"] = [k for k in ("digital_signature", "key_encipherment", "key_cert_sign", "key_agreement", "content_commitment") if getattr(ku, k, False)]
    except x509.ExtensionNotFound:
        ki.cert["key_usage"] = []
    if ki.cert["is_ca"] and ki.cert["subject"] == ki.cert["issuer"]:
        ki.notes.append("self-signed CA — fine if it is an intentional root; check it is not accepted as a leaf")

def analyze_jwk(ki: KeyInfo, k: dict, opts) -> None:
    ki.kind = "jwk"
    kty = k.get("kty")
    if "d" in k or "p" in k:
        ki.issues.append("C-07 JWK contains private parameters (Critical if not a test key)")
    if kty == "RSA" and "n" in k and "e" in k:
        try:
            pub = rsa.RSAPublicNumbers(b64u(k["e"]), b64u(k["n"])).public_key()
            analyze_public(ki, pub, opts)
        except Exception as e:
            ki.notes.append(f"could not build RSA key from JWK: {e}")
    elif kty == "EC":
        crv = k.get("crv", "")
        ki.algorithm, ki.curve = "EC", crv
        if crv in ("P-256", "P-384", "P-521"):
            ki.bits = int(crv[2:])
        else:
            ki.notes.append(f"EC curve {crv} — check (A-25)")
    elif kty == "OKP":
        ki.algorithm = k.get("crv", "OKP")
    elif kty == "oct":
        ki.algorithm = "oct (symmetric)"
        if "k" in k:
            kb = len(k["k"] + "=" * (-len(k["k"]) % 4)) * 3 // 4
            ki.bits = kb * 8
            if kb < 32:
                ki.issues.append(f"C-04 symmetric JWK key {kb} bytes < 32 (High/Critical if used with HS256)")
    alg = k.get("alg", "")
    if alg in ("none", "RSA1_5"):
        ki.issues.append(f"JWK alg={alg} (C-02 / A-04)")
    if alg.startswith("HS") and kty != "oct":
        ki.issues.append("C-03 HMAC alg declared on an asymmetric key — confusion hazard")

def scan_paths(paths: list[str], opts) -> list[KeyInfo]:
    infos: list[KeyInfo] = []
    files = []
    for p in paths:
        if os.path.isfile(p):
            files.append(p)
        else:
            for d, dn, fn in os.walk(p):
                dn[:] = [x for x in dn if x not in {".git", "node_modules", "vendor", ".venv", "venv"}]
                for f in fn:
                    if os.path.splitext(f)[1].lower() in KEY_EXT or f.endswith(("id_rsa", "id_ecdsa", "id_ed25519", ".pub")):
                        files.append(os.path.join(d, f))
    for f in files:
        for kind, obj in load_objects(f):
            ki = KeyInfo(file=f, kind=kind)
            try:
                if kind == "certificate":
                    analyze_cert(ki, obj, opts)
                elif kind in ("public-key", "ssh-public"):
                    analyze_public(ki, obj, opts)
                elif kind == "private-key":
                    ki.issues.append("C-07 unencrypted private key file present — confirm it is not a production key (Critical if live)")
                    analyze_public(ki, obj.public_key(), opts)
                elif kind == "private-key-encrypted":
                    ki.notes.append("encrypted private key present — check passphrase handling")
                elif kind == "jwk":
                    analyze_jwk(ki, obj, opts)
                elif kind == "csr":
                    analyze_public(ki, obj.public_key(), opts)
                elif kind.startswith("unparseable"):
                    ki.notes.append(f"unparseable ({kind.split(':',1)[1]}): {str(obj)[:120]}")
            except Exception as e:
                ki.notes.append(f"analysis error: {e}")
            infos.append(ki)
    # cross-key checks
    rsa_items = [ki for ki in infos if ki.algorithm == "RSA" and ki._n]
    seen: dict[str, list[KeyInfo]] = {}
    for ki in rsa_items:
        seen.setdefault(ki.modulus_fingerprint, []).append(ki)
    for fp, group in seen.items():
        pub_files = {k.file for k in group if k.kind != "private-key"}
        priv_files = {k.file for k in group if k.kind == "private-key"}
        # the private half of a public key/certificate that the project uses is sitting in the same tree
        if pub_files and priv_files:
            for ki in group:
                other = sorted(priv_files if ki.kind != "private-key" else pub_files)
                ki.issues.append(("C-07 the matching PRIVATE key for this public key/certificate is in the tree: " if ki.kind != "private-key"
                                  else "C-07 this private key matches a public key/certificate in the tree: ") + ", ".join(other)
                                 + " — whoever can read the repository can sign/decrypt as this key")
        # several public copies or several private copies of one modulus: key shared across purposes/hosts
        if len(pub_files) > 1 or len(priv_files) > 1:
            for ki in group:
                ki.issues.append(f"A-08/A-12 same RSA modulus appears in {len(pub_files | priv_files)} files — shared key across purposes/hosts/environments?")
    if opts.gcd and len(rsa_items) >= 2:
        uniq = {}
        for ki in rsa_items:
            uniq.setdefault(ki._n, ki)
        mods = list(uniq.keys())
        g = batch_gcd(mods)
        for n, gi in zip(mods, g):
            if 1 < gi < n:
                uniq[n].issues.append("A-08 shares a prime factor with another key in the set (batch GCD) — both keys are factorable (Critical)")
    return infos

def ecdsa_r_check(path: str) -> dict:
    rs = []
    for line in open(path, "r", encoding="utf-8", errors="ignore"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            if "," in line:
                a, b = line.split(",", 1)
                r = int(a, 16) if re.fullmatch(r"[0-9a-fA-F]+", a.strip()) and not a.strip().isdigit() else int(a, 0)
                rs.append(r)
            else:
                r, s = decode_dss_signature(bytes.fromhex(line))
                rs.append(r)
        except Exception:
            continue
    from collections import Counter
    c = Counter(rs)
    dup = {hex(r)[:18] + "…": k for r, k in c.items() if k > 1}
    return {"signatures": len(rs), "distinct_r": len(c), "repeated_r": dup,
            "verdict": "A-19 REPEATED r — private key recoverable from the pair (Critical)" if dup else "no repeated r in sample (does not rule out bias; see A-19)"}

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("paths", nargs="*")
    ap.add_argument("--gcd", action="store_true", help="batch-GCD across all RSA moduli found")
    ap.add_argument("--roca", action="store_true", help="ROCA fingerprint test on RSA moduli")
    ap.add_argument("--wiener", action="store_true", help="small-d (Wiener) continued-fraction check")
    ap.add_argument("--fermat", type=int, default=0, metavar="N", help="Fermat close-primes check with N iterations (e.g. 10000)")
    ap.add_argument("--ecdsa-r", metavar="FILE", help="check a file of ECDSA signatures for repeated r")
    ap.add_argument("--json", metavar="OUT")
    a = ap.parse_args(argv)
    if a.ecdsa_r:
        res = ecdsa_r_check(a.ecdsa_r)
        print(json.dumps(res, indent=2))
        if a.json:
            json.dump(res, open(a.json, "w"), indent=2)
        return 0
    if not a.paths:
        ap.error("give at least one path or --ecdsa-r FILE")
    infos = scan_paths(a.paths, a)
    out = []
    for ki in infos:
        d = asdict(ki); d.pop("_n", None); out.append(d)
    if a.json:
        json.dump(out, open(a.json, "w"), indent=2)
    print(f"{len(infos)} key objects analysed\n")
    for ki in infos:
        head = f"{ki.file}  [{ki.kind}] {ki.algorithm}" + (f" {ki.bits}b" if ki.bits else "") + (f" {ki.curve}" if ki.curve else "") + (f" e={ki.exponent}" if ki.exponent else "")
        print(head)
        if ki.cert:
            print(f"    cert: sig={ki.cert.get('signature_algorithm')} subject={ki.cert.get('subject')} valid={ki.cert.get('not_before','?')[:10]}..{ki.cert.get('not_after','?')[:10]} SAN={ki.cert.get('san_count')} CA={ki.cert.get('is_ca')}")
        for i in ki.issues:
            print(f"    ISSUE: {i}")
        for n in ki.notes:
            print(f"    note:  {n}")
    n_issues = sum(len(k.issues) for k in infos)
    rsa_n = len({k._n for k in infos if k.algorithm == "RSA" and k._n})
    def neg(tag):  # how many keys were flagged by a given check
        return sum(1 for k in infos for i in k.issues if tag in i)
    ran = [f"key size/exponent/curve/signature-algorithm on {len(infos)} object(s)",
           f"duplicate and matching-pair moduli on {rsa_n} distinct RSA modulus/moduli"]
    ran.append(f"batch GCD on {rsa_n} moduli: {neg('batch GCD')} with a shared factor" if a.gcd else "batch GCD: not run (--gcd)")
    ran.append(f"ROCA fingerprint: {neg('ROCA')} positive" if a.roca else "ROCA: not run (--roca)")
    ran.append(f"Wiener small-d: {neg('Wiener')} positive" if a.wiener else "Wiener: not run (--wiener)")
    ran.append(f"Fermat close primes ({a.fermat} iterations): {neg('Fermat')} positive" if a.fermat else "Fermat: not run (--fermat N)")
    print("\nchecks run:")
    for r in ran:
        print("  -", r)
    print(f"\n{n_issues} issue(s) flagged; treat as candidates and confirm in context.")
    return 0

if __name__ == "__main__":
    sys.exit(main())
